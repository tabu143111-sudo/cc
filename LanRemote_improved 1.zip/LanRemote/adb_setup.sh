#!/usr/bin/env bash
# Setup for the HOST device (the one that gets controlled). Run from a PC with ADB installed.
# 1. Install the app on the host  2. Enable USB debugging  3. Plug in USB  4. Run this script.
# Re-run it after every reboot of the host (it restarts the native input server).
PKG=com.example.lanremote
DIR="$(cd "$(dirname "$0")" && pwd)"
command -v adb >/dev/null || { echo "adb not found. Install Android platform-tools first."; exit 1; }
adb start-server >/dev/null 2>&1
adb get-state >/dev/null 2>&1 || { echo "No device found. Enable USB debugging and accept the prompt on the phone."; exit 1; }

echo "Granting permissions..."
adb shell pm grant $PKG android.permission.WRITE_SECURE_SETTINGS || { echo "Grant failed. On Xiaomi/Poco also enable 'USB debugging (Security settings)'."; exit 1; }
adb shell pm grant $PKG android.permission.POST_NOTIFICATIONS 2>/dev/null

echo "Enabling media (notification) access..."
adb shell cmd notification allow_listener $PKG/$PKG.MediaListener

echo "Excluding the app from battery optimisation..."
adb shell dumpsys deviceidle whitelist +$PKG >/dev/null 2>&1
adb shell cmd appops set $PKG RUN_IN_BACKGROUND allow >/dev/null 2>&1
echo "Allowing brightness control..."
adb shell cmd appops set $PKG WRITE_SETTINGS allow >/dev/null 2>&1
adb shell cmd appops set $PKG SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1

echo "Starting native mouse + keyboard server..."
adb shell "pkill -f com.example.lanremote.InputServer" >/dev/null 2>&1
adb shell "mkdir -p /sdcard/Android/data/$PKG/files" >/dev/null 2>&1
adb push "$DIR/lanremote_start.sh" /data/local/tmp/lanremote_start.sh >/dev/null
adb shell "nohup sh /data/local/tmp/lanremote_start.sh > /data/local/tmp/lanremote.log 2>&1 &"
sleep 2
adb shell cat /data/local/tmp/lanremote.log

echo "Opening the app (it enables Accessibility by itself)..."
adb shell am start -n $PKG/.MainActivity >/dev/null
echo
echo "Done. Open the app > Host > Start host. The Host screen should show 'Native mouse & keyboard: active'."
