package com.example.lanremote

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Receives stdout / stderr / exit code of a command that [NativeStarter] ran inside Termux. */
class TermuxResult : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val b = i.getBundleExtra("result") ?: return
        NativeStarter.onResult(i.getStringExtra("tag") ?: "", b.getInt("exitCode", -1), b.getString("stdout") ?: "",
            b.getString("stderr") ?: "", b.getString("errmsg"))
    }
}
