package com.example.lanremote

import android.content.Context
import android.content.Intent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

/** A host the controller has connected to before. Remembered across minimising, process death and reboots. */
data class SavedHost(val name: String, val ip: String, val pin: String)

object HostStore {
    private const val KEY = "saved_hosts"
    fun load(ctx: Context): List<SavedHost> = try {
        val a = JSONArray(ctx.getSharedPreferences("s", 0).getString(KEY, "[]"))
        (0 until a.length()).map { a.getJSONObject(it).let { o -> SavedHost(o.getString("n"), o.getString("i"), o.getString("p")) } }
    } catch (_: Exception) { emptyList() }

    private fun write(ctx: Context, l: List<SavedHost>) {
        val a = JSONArray(); l.forEach { a.put(JSONObject().put("n", it.name).put("i", it.ip).put("p", it.pin)) }
        ctx.getSharedPreferences("s", 0).edit().putString(KEY, a.toString()).apply()
    }

    /** Most recent first; the same device (same name or same IP) is only stored once. */
    fun save(ctx: Context, h: SavedHost) = write(ctx, listOf(h) + load(ctx).filter { it.ip != h.ip && it.name != h.name })
    fun forget(ctx: Context, ip: String) = write(ctx, load(ctx).filter { it.ip != ip })
}

/**
 * Process-wide controller state. It lives OUTSIDE the Activity, so rotating, minimising or the system destroying the
 * Activity no longer drops the connection. [ControllerService] keeps the process alive while connected.
 */
object Session {
    var client by mutableStateOf<Client?>(null)
    var mode by mutableStateOf<String?>(null)
    /** Name of the host being re-connected to after the app was restarted (null = nothing in progress). */
    var resuming by mutableStateOf<String?>(null)
    private var resumeTok = 0

    fun attach(ctx: Context, c: Client, name: String) {
        val app = ctx.applicationContext
        client = c; resuming = null
        HostStore.save(app, SavedHost(name, c.host, c.pin))
        app.getSharedPreferences("s", 0).edit().putBoolean("was_connected", true).putString("last_ip", c.host).apply()
        try { app.startForegroundService(Intent(app, ControllerService::class.java)) } catch (_: Exception) {}
    }

    /** The user pressed Disconnect (or the notification's Disconnect). */
    fun disconnect(ctx: Context) {
        val app = ctx.applicationContext
        resumeTok++; resuming = null
        client?.close(); client = null; mode = null
        app.getSharedPreferences("s", 0).edit().putBoolean("was_connected", false).apply()
        try { app.stopService(Intent(app, ControllerService::class.java)) } catch (_: Exception) {}
    }

    /** Cold start after the process was killed while connected: silently reconnect to the last host. */
    fun resume(ctx: Context) {
        val app = ctx.applicationContext
        val p = app.getSharedPreferences("s", 0)
        if (client != null || resuming != null || !p.getBoolean("was_connected", false)) return
        val ip = p.getString("last_ip", null) ?: return
        val h = HostStore.load(app).firstOrNull { it.ip == ip } ?: return
        val tok = ++resumeTok
        resuming = h.name
        val c = Client()
        c.connect(h.ip, h.pin) { ok ->
            if (tok != resumeTok) { c.close(); return@connect }
            resuming = null
            if (ok) attach(app, c, h.name) else mode = "controller"
        }
    }

    fun cancelResume() { resumeTok++; resuming = null; mode = "controller" }
}
