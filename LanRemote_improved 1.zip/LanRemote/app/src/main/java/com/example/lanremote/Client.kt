package com.example.lanremote

import android.graphics.BitmapFactory
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.atomic.AtomicLong
import javax.crypto.spec.SecretKeySpec
import kotlin.math.roundToInt

/**
 * Connection to one host.
 *
 * Unlike the first version this client SURVIVES: when the link breaks (Wi-Fi sleep, app minimised, host restarted,
 * network switch) it keeps retrying in the background with the same host + pairing code until [close] is called.
 * [link] tells the UI what is going on: 0 connecting · 1 connected · 2 reconnecting · 3 closed.
 */
class Client {
    var st by mutableStateOf(PlayState())
    var link by mutableIntStateOf(0)
        private set
    var host = ""; private set
    var pin = ""; private set

    @Volatile private var sock: Socket? = null
    @Volatile private var out: PrintWriter? = null
    @Volatile private var key: SecretKeySpec? = null
    @Volatile private var closed = false
    private val seq = AtomicLong(0)
    private val ex = Executors.newSingleThreadExecutor()
    private fun submit(r: Runnable) { try { ex.execute(r) } catch (_: RejectedExecutionException) {} }
    private fun submit(r: () -> Unit) = submit(Runnable { r() })

    /** One handshake attempt. Returns the reader on success (and switches [sock]/[out]/[key] over), null on any failure. */
    private fun open(): BufferedReader? {
        var s: Socket? = null
        try {
            s = Socket(); s.tcpNoDelay = true; s.keepAlive = true
            s.connect(InetSocketAddress(host, HostService.PORT), 4000); s.soTimeout = 6000
            val o = PrintWriter(s.getOutputStream(), true)
            val rd = BufferedReader(InputStreamReader(s.getInputStream()))
            val saltLine = rd.readLine()
            if (saltLine == null) { s.close(); return null }
            val k = Crypto.key(pin, Base64.decode(saltLine, Base64.NO_WRAP))
            o.println(Crypto.enc(k, JSONObject().put("t", "auth").put("n", seq.incrementAndGet()).toString()))
            val r = rd.readLine()
            if (r == null || !JSONObject(Crypto.dec(k, r)).optBoolean("ok")) { s.close(); return null }
            // the host pushes its state twice a second, so 4 s of silence means the link is dead
            s.soTimeout = 4000
            val old = sock
            key = k; out = o; sock = s
            try { old?.close() } catch (_: Exception) {}
            return rd
        } catch (_: Exception) {
            try { s?.close() } catch (_: Exception) {}
            return null
        }
    }

    /** First connection attempt (result in [cb]); on success the client then keeps itself connected. */
    fun connect(host: String, pin: String, cb: (Boolean) -> Unit) {
        this.host = host; this.pin = pin; link = 0
        Thread {
            val rd = open()
            if (rd == null) { closed = true; link = 3; cb(false); return@Thread }
            link = 1; cb(true)
            readLoop(rd)
        }.apply { isDaemon = true; start() }
    }

    private fun readLoop(first: BufferedReader) {
        var rd: BufferedReader? = first
        var wait = 800L
        while (!closed) {
            if (rd != null) {
                while (!closed) {
                    val l = try { rd.readLine() } catch (_: Exception) { null } ?: break
                    try {
                        val j = JSONObject(Crypto.dec(key!!, l))
                        when (j.optString("t")) { "state" -> onState(j); "apps" -> onApps(j) }
                    } catch (_: Exception) {}
                }
                if (closed) break
                link = 2
                try { sock?.close() } catch (_: Exception) {}
                wait = 800L
            }
            try { Thread.sleep(wait) } catch (_: InterruptedException) {}
            if (closed) break
            rd = open()
            if (rd != null) { link = 1; wait = 800L } else wait = minOf(wait * 3 / 2, 4000L)
        }
    }

    /** Every command first flushes pending typing, so keys such as Enter can never overtake characters typed before them. */
    fun send(t: String, vararg kv: Pair<String, Any>) { flushTyping(); rawSend(t, *kv) }
    private fun rawSend(t: String, vararg kv: Pair<String, Any>) = submit {
        try {
            val j = JSONObject().put("t", t).put("n", seq.incrementAndGet()); kv.forEach { j.put(it.first, it.second) }
            val o = out; val k = key
            if (o != null && k != null) o.println(Crypto.enc(k, j.toString()))
        } catch (_: Exception) {}
    }

    // ---- typing pipeline: edits are merged for 25 ms into ONE "delete N, then insert text" packet ----
    private val tlock = Any()
    private var pDel = 0
    private var pWide = false      // some deleted text was not plain ASCII (Bangla ...): the host must delete by characters, not by key presses
    private val pTxt = StringBuilder()
    private var tScheduled = false
    private val timer = Executors.newSingleThreadScheduledExecutor()
    private fun scheduleFlush() {
        synchronized(tlock) { if (tScheduled) return; tScheduled = true }
        try { timer.schedule(Runnable { flushTyping() }, 25, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (_: Exception) {}
    }
    private fun flushTyping() {
        synchronized(tlock) {
            tScheduled = false
            val d = pDel; val t = pTxt.toString(); val w = pWide; pDel = 0; pWide = false; pTxt.setLength(0)
            // delete + insert travel in ONE packet and are applied in ONE edit on the host: two separate edits could overtake
            // each other (the reason Bangla / IME text came out garbled)
            if (d > 0 && t.isNotEmpty()) rawSend("edit", "d" to d, "s" to t, "w" to w)
            else if (d > 0) rawSend("key", "k" to "backspace", "c" to d, "w" to w)
            else if (t.isNotEmpty()) rawSend("text", "s" to t)
        }
    }
    fun typeBackspace(n: Int, wide: Boolean = false) {
        if (n <= 0) return
        synchronized(tlock) { val k = minOf(n, pTxt.length); pTxt.setLength(pTxt.length - k); pDel += n - k; if (wide && n > k) pWide = true }   // deleting what is still unsent costs nothing
        scheduleFlush()
    }
    fun typeText(s: String) { if (s.isEmpty()) return; synchronized(tlock) { pTxt.append(s) }; scheduleFlush() }
    /** Special key (tab, esc, left, right, up, down, home_line, end_line, del, enter ...), [n] times. */
    fun special(k: String, n: Int = 1) { send("key", "k" to k, "c" to n) }
    /** Ctrl + [ch] on the host (select all, copy, paste ...). */
    fun ctrl(ch: Char) { send("key", "k" to "ctrl", "ch" to ch.lowercaseChar().toString()) }
    // Pointer moves are merged: when the network is slower than the touch events the pending deltas are summed into one
    // packet, so the host cursor never lags behind a queue of tiny packets.
    private var mvx = 0f; private var mvy = 0f; private var mvPending = false
    fun move(dx: Float, dy: Float) {
        synchronized(this) { mvx += dx; mvy += dy; if (mvPending) return; mvPending = true }
        submit {
            var a = 0f; var b = 0f
            synchronized(this) { a = mvx; b = mvy; mvx = 0f; mvy = 0f; mvPending = false }
            if (a != 0f || b != 0f) try {
                val j = JSONObject().put("t", "move").put("n", seq.incrementAndGet()).put("dx", a.toDouble()).put("dy", b.toDouble())
                val o = out; val k = key
                if (o != null && k != null) o.println(Crypto.enc(k, j.toString()))
            } catch (_: Exception) {}
        }
    }
    /** Play/pause state shown immediately after a tap, until the host confirms it. */
    var optPlay by mutableStateOf<Boolean?>(null)
    fun togglePlay() { optPlay = !(optPlay ?: st.playing); send("media", "k" to "play_pause") }
    /** Playback speed the button shows right after a change, before the host confirms it. */
    var speedOv by mutableStateOf<Float?>(null)
    fun setSpeed(v: Float) { speedOv = v; send("speed", "v" to v.toDouble()) }
    /** Volume the bar shows right after a change, before the host reports back. */
    var volOv by mutableStateOf<Float?>(null)
    fun setVol(f: Float) { volOv = f.coerceIn(0f, 1f); send("volset", "f" to f.coerceIn(0f, 1f)) }
    fun nudgeVol(dir: Int) {
        val m = st.max.coerceAtLeast(1)
        setVol((volOv ?: (st.vol.toFloat() / m)) + dir.toFloat() / m)
    }
    /** Brightness the overlay shows right after a swipe, before the host reports back. */
    var briOv by mutableStateOf<Float?>(null)
    private var lastBriSent = -1
    fun briStart() { lastBriSent = -1 }
    fun setBri(f: Float) {
        val v = f.coerceIn(0f, 1f); briOv = v
        val step = (v * 100).roundToInt()
        if (step != lastBriSent) { lastBriSent = step; send("briset", "f" to v) }     // at most one packet per 1 %
    }
    /** Real keyboard backspace on the host: removes [n] characters in front of the caret (or the selection). */
    fun backspace(n: Int = 1) = typeBackspace(n)
    /** Live typing: sends only what changed between [old] and [new] so the host field mirrors the input box. */
    fun liveDiff(old: String, new: String) {
        var p = 0; val m = minOf(old.length, new.length)
        while (p < m && old[p] == new[p]) p++
        typeBackspace(old.length - p, old.substring(p).any { it.code > 126 })
        typeText(new.substring(p))
    }
    /** Apps installed on the host (for the shortcut editor). */
    var apps by mutableStateOf<List<HostApp>>(emptyList())
    fun requestApps() { send("apps") }
    private fun onApps(j: JSONObject) {
        val a = j.optJSONArray("list") ?: return
        apps = (0 until a.length()).map { a.getJSONObject(it).let { o ->
            val b64 = o.optString("i", "")
            val bmp = if (b64.isEmpty()) null else try { Base64.decode(b64, Base64.NO_WRAP).let { b -> BitmapFactory.decodeByteArray(b, 0, b.size) } } catch (_: Exception) { null }
            HostApp(o.getString("p"), o.getString("l"), bmp, b64) } }
    }
    private fun onState(j: JSONObject) {
        val art = if (j.has("art")) j.optString("art").let { if (it.isEmpty()) null else Base64.decode(it, Base64.NO_WRAP).let { b -> BitmapFactory.decodeByteArray(b, 0, b.size) } } else st.art
        st = PlayState(j.optString("title"), j.optString("artist"), j.optBoolean("playing"), j.optLong("pos"), j.optLong("dur"),
            j.optInt("vol"), j.optInt("max", 1), art, System.currentTimeMillis(), j.optDouble("spd", 1.0).toFloat(), j.optBoolean("access", true), j.optInt("ad", 0),
            j.optDouble("bri", -1.0).toFloat(), j.optBoolean("briok", true))
        if (optPlay != null && optPlay == st.playing) optPlay = null
        speedOv?.let { if (kotlin.math.abs(it - st.spd) < 0.02f) speedOv = null }
    }
    fun close() {
        closed = true; link = 3
        flushTyping()
        try { sock?.close() } catch (_: Exception) {}
        try { timer.shutdown() } catch (_: Exception) {}
        try { ex.shutdown() } catch (_: Exception) {}
    }
}
