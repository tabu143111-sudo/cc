package com.example.lanremote

import android.app.*
import android.content.Intent
import android.media.AudioManager
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Base64
import android.content.ComponentName
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock
import android.provider.Settings
import java.io.ByteArrayOutputStream
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.roundToInt
import android.view.KeyEvent
import org.json.JSONObject
import java.io.PrintWriter
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import android.content.Context
import android.graphics.drawable.Icon
import android.net.wifi.WifiManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class HostService : Service() {
    companion object {
        /** Observable by the UI, so the Start/Stop button always shows the real state. */
        var running by mutableStateOf(false)
        /** Number of authenticated controllers right now. */
        var clients by mutableIntStateOf(0)
        var error by mutableStateOf("")
        @Volatile var pin = (10_000_000..99_999_999).random().toString()
        const val PORT = 8765
        const val ACT_STOP = "com.example.lanremote.STOP_HOST"
    }
    private var server: ServerSocket? = null
    private var nsd: NsdManager? = null
    private var reg: NsdManager.RegistrationListener? = null
    private var wifi: WifiManager.WifiLock? = null
    private val conns = java.util.Collections.synchronizedSet(HashSet<Socket>())
    private val authed = java.util.concurrent.atomic.AtomicInteger(0)
    @Volatile private var gen = 0        // every start gets a new generation; threads of an older one exit by themselves
    private val am by lazy { getSystemService(AudioManager::class.java) }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == ACT_STOP) { shutdown(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY }
        pin = i?.getStringExtra("pin") ?: pin
        val ch = "host"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Host", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 2, Intent(this, HostService::class.java).setAction(ACT_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        startForeground(1, Notification.Builder(this, ch).setContentTitle("LAN Remote host running")
            .setContentText("Tap Stop to end remote control").setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop", stop).build())
            .build())
        if (running) return START_NOT_STICKY
        running = true; error = ""
        RemoteAccess.instance?.applyCfg()
        val g = ++gen
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION")
            wifi = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "lanremote:host").apply { setReferenceCounted(false); acquire() }
        } catch (_: Exception) {}
        Thread {   // keeps Accessibility / notification access switched on and the native server connected
            var lastForce = 0L
            var lastNative = -90_000L
            while (running && g == gen) {
                try {
                    NativeInput.connect(this)
                    if (!NativeInput.connected && getSharedPreferences("s", 0).getBoolean("auto_native", false)
                        && !NativeStarter.busy && SystemClock.elapsedRealtime() - lastNative > 90_000) {
                        lastNative = SystemClock.elapsedRealtime(); NativeStarter.start(this)
                    }
                    if (AutoGrant.canWrite(this)) {
                        val dead = RemoteAccess.instance == null
                        val now = SystemClock.elapsedRealtime()
                        AutoGrant.ensure(this, dead && now - lastForce > 20_000)
                        if (dead) lastForce = now
                    }
                    Thread.sleep(3000)
                } catch (_: Exception) {}
            }
        }.start()
        Thread {
            var ss: ServerSocket? = null
            // after a quick Stop -> Start the old socket may linger for a moment: retry the bind a few times
            for (n in 0 until 12) {
                if (g != gen) return@Thread
                try { ss = ServerSocket().apply { reuseAddress = true; bind(InetSocketAddress(PORT)) }; break }
                catch (_: Exception) { try { Thread.sleep(250) } catch (_: Exception) {} }
            }
            if (ss == null) { error = "Port $PORT is busy. Stop the other host first."; shutdown(); stopSelf(); return@Thread }
            if (g != gen) { try { ss.close() } catch (_: Exception) {}; return@Thread }
            server = ss
            registerNsd()
            try {
                while (running && g == gen) {
                    val s = ss.accept()
                    conns.add(s)
                    Thread { serve(s, g) }.start()
                }
            } catch (_: Exception) {}
        }.start()
        return START_NOT_STICKY
    }

    /** Ends everything: stops accepting, drops every connected controller, releases locks. Safe to call twice. */
    private fun shutdown() {
        running = false; gen++
        try { server?.close() } catch (_: Exception) {}
        server = null
        val all = synchronized(conns) { conns.toList() }
        all.forEach { try { it.close() } catch (_: Exception) {} }
        conns.clear(); authed.set(0); clients = 0
        try { reg?.let { nsd?.unregisterService(it) } } catch (_: Exception) {}
        reg = null
        try { wifi?.release() } catch (_: Exception) {}
        wifi = null
        RemoteAccess.instance?.applyCfg()      // host keyboard behaves normally again
        // never leave a mouse button held down on this device
        try { handle(JSONObject().put("t", "up")) } catch (_: Exception) {}
    }

    private fun registerNsd() {
        nsd = getSystemService(NsdManager::class.java)
        reg = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(i: NsdServiceInfo) {}
            override fun onRegistrationFailed(i: NsdServiceInfo, e: Int) {}
            override fun onServiceUnregistered(i: NsdServiceInfo) {}
            override fun onUnregistrationFailed(i: NsdServiceInfo, e: Int) {}
        }
        val info = NsdServiceInfo().apply { serviceName = "Host-${Build.MODEL}"; serviceType = "_lanremote._tcp."; port = PORT }
        nsd?.registerService(info, NsdManager.PROTOCOL_DNS_SD, reg)
    }

    private fun serve(s: Socket, g: Int) {
        val alive = AtomicBoolean(true)
        var counted = false
        try {
            s.use {
                try { it.tcpNoDelay = true; it.keepAlive = true } catch (_: Exception) {}
                val r = it.getInputStream().bufferedReader()
                val w = PrintWriter(it.getOutputStream(), true)
                val salt = Crypto.salt()
                w.println(Base64.encodeToString(salt, Base64.NO_WRAP))
                val key = Crypto.key(pin, salt)
                val a = try { JSONObject(Crypto.dec(key, r.readLine() ?: return)) } catch (e: Exception) { Thread.sleep(1500); return }
                if (a.optString("t") != "auth") return
                var last = a.optLong("n")
                synchronized(w) { w.println(Crypto.enc(key, JSONObject().put("ok", true).toString())) }
                counted = true; clients = authed.incrementAndGet()
                // State is pushed twice a second, and immediately after a media command (poke), so the controller
                // behaves like the native media controls.
                val sem = java.util.concurrent.Semaphore(0)
                val poke = { Thread { try { Thread.sleep(120) } catch (_: Exception) {}; sem.release() }.start() }
                Thread {
                    var lastArt = Int.MIN_VALUE
                    while (alive.get() && running && g == gen) {
                        try {
                            val st = stateJson()
                            val ah = st.optString("art").hashCode()
                            if (st.has("art") && ah == lastArt) st.remove("art") else if (st.has("art")) lastArt = ah
                            synchronized(w) { w.println(Crypto.enc(key, st.toString())) }
                            if (w.checkError()) { try { it.close() } catch (_: Exception) {}; break }   // controller vanished
                        } catch (_: Exception) {}
                        try { sem.tryAcquire(500, java.util.concurrent.TimeUnit.MILLISECONDS); sem.drainPermits() } catch (_: Exception) {}
                    }
                }.start()
                while (running && g == gen) {
                    val l = r.readLine() ?: break
                    try {
                        val j = JSONObject(Crypto.dec(key, l))
                        val n = j.getLong("n"); if (n <= last) continue
                        last = n; handle(j, poke) { o -> synchronized(w) { w.println(Crypto.enc(key, o.toString())) } }
                    } catch (e: javax.crypto.AEADBadTagException) { break } catch (_: Exception) {}
                }
            }
        } catch (_: Exception) {} finally {
            alive.set(false)
            conns.remove(s)
            if (counted) {
                clients = authed.decrementAndGet().coerceAtLeast(0)
                // a controller that vanished while holding the mouse button must not leave it pressed
                try { handle(JSONObject().put("t", "up")) } catch (_: Exception) {}
            }
        }
    }

    @Volatile private var lastA11yEdit = 0L

    /**
     * Typing must be applied in order. Native key events and Accessibility edits are two independent channels, so once
     * text went through Accessibility (Bangla / emoji / ...) the next edits stay on it for a moment instead of overtaking.
     */
    private fun typing(j: JSONObject) {
        val ascii = j.optString("s").all { it.code in 32..126 || it == '\n' }
        val wide = j.optBoolean("w")
        val recent = SystemClock.elapsedRealtime() - lastA11yEdit < 500
        when (j.getString("t")) {
            "edit" -> {
                val d = j.optInt("d")
                if (!recent && !wide && ascii && NativeInput.connected) {
                    val a = d == 0 || NativeInput.forward(JSONObject().put("t", "key").put("k", "backspace").put("c", d))
                    if (a && NativeInput.forward(JSONObject().put("t", "text").put("s", j.optString("s")))) return
                }
                lastA11yEdit = SystemClock.elapsedRealtime(); RemoteAccess.handle(j)
            }
            "text" -> if (!recent && ascii && NativeInput.forward(j)) RemoteAccess.mirror(j)
                      else { if (!ascii) lastA11yEdit = SystemClock.elapsedRealtime(); RemoteAccess.handle(j) }
            else -> {   // backspace
                if (!recent && !wide && NativeInput.forward(j)) RemoteAccess.mirror(j)
                else { lastA11yEdit = SystemClock.elapsedRealtime(); RemoteAccess.handle(j) }
            }
        }
    }

    private fun handle(j: JSONObject, poke: () -> Unit = {}, reply: (JSONObject) -> Unit = {}) {
        val tt = j.getString("t")
        if (tt == "edit" || tt == "text" || (tt == "key" && j.optString("k") == "backspace")) { typing(j); return }
        when (tt) {
            "cfg" -> {
                val p = getSharedPreferences("s", 0).edit()
                when (j.optString("k")) { "autoskip" -> p.putBoolean("auto_skip", j.optBoolean("v", true)); "hostkb" -> p.putBoolean("host_kb", j.optBoolean("v", false)) }
                p.apply(); RemoteAccess.instance?.applyCfg()
            }
            "speed" -> { val v = j.optDouble("v", 1.0).toFloat().coerceIn(0.25f, 4f)
                if (Build.VERSION.SDK_INT >= 29) mc()?.transportControls?.setPlaybackSpeed(v); poke() }
            "media" -> {
                val mcc = mc(); val kk = j.getString("k")
                if (mcc != null && kk in listOf("play_pause", "next", "prev", "stop")) {
                    val t = mcc.transportControls
                    when (kk) {
                        "play_pause" -> if (mcc.playbackState?.state == PlaybackState.STATE_PLAYING) t.pause() else t.play()
                        "next" -> t.skipToNext(); "prev" -> t.skipToPrevious(); else -> t.stop()
                    }
                    poke(); return
                }
                val code = when (j.getString("k")) {
                    "play_pause" -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
                    "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
                    "prev" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                    "stop" -> KeyEvent.KEYCODE_MEDIA_STOP
                    "ff" -> KeyEvent.KEYCODE_MEDIA_FAST_FORWARD
                    "rw" -> KeyEvent.KEYCODE_MEDIA_REWIND
                    else -> return
                }
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
                poke()
            }
            "vol" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, when (j.getString("k")) {
                "up" -> AudioManager.ADJUST_RAISE
                "down" -> AudioManager.ADJUST_LOWER
                else -> AudioManager.ADJUST_TOGGLE_MUTE
            }, AudioManager.FLAG_SHOW_UI)
            "briset" -> setBrightness(j.getDouble("f").toFloat())
            "apps" -> reply(appsJson())
            "launch" -> launchApp(j.getString("p"))
            "url" -> openUrl(j.getString("u"))
            "seek" -> { mc()?.transportControls?.seekTo(j.getLong("ms")); poke() }
            "skip" -> { mc()?.let { c -> c.transportControls.seekTo((pos(c) + j.getLong("ms")).coerceAtLeast(0)) }; poke() }
            "volset" -> am.setStreamVolume(AudioManager.STREAM_MUSIC,
                (j.getDouble("f") * am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)).roundToInt(), 0)
            else -> if (NativeInput.forward(j)) RemoteAccess.mirror(j) else RemoteAccess.handle(j)
        }
    }

    private fun canWriteSettings() = try { Settings.System.canWrite(this) } catch (_: Exception) { false }

    /** Screen brightness 0..1. Uses WRITE_SETTINGS when allowed, else the native (shell) input server. */
    /** The scale of the system brightness setting: 255 on most phones, but e.g. 2047 / 4095 on some Xiaomi / Samsung builds. */
    private val briMax: Int by lazy {
        try {
            val m = getSystemService(android.os.PowerManager::class.java)
            (m.javaClass.getMethod("getMaximumScreenBrightnessSetting").invoke(m) as Int).takeIf { it in 100..65535 } ?: 255
        } catch (_: Throwable) { 255 }
    }
    private var lastMode = 0L

    private fun setBrightness(f: Float) {
        val v = (f.coerceIn(0f, 1f) * briMax).roundToInt().coerceIn(1, briMax)
        try {
            if (canWriteSettings()) {
                val now = SystemClock.elapsedRealtime()
                if (now - lastMode > 3000) {      // switch auto-brightness off, otherwise the system overrides the value
                    lastMode = now
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                }
                if (Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, v)) return
            }
        } catch (_: Exception) {}
        NativeInput.forward(JSONObject().put("t", "bright").put("v", v))     // shell-privileged fallback
    }

    // ---------- shortcuts: app list, launch app, open address ----------
    private fun appsJson(): JSONObject {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(q, 0).map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinctBy { it.first }.sortedBy { it.second.lowercase() }
        val a = org.json.JSONArray()
        list.forEach { a.put(JSONObject().put("p", it.first).put("l", it.second).put("i", iconOf(it.first))) }
        return JSONObject().put("t", "apps").put("list", a)
    }

    private val iconCache = HashMap<String, String>()
    /** The app's launcher icon as a small WebP (base64), cached. */
    private fun iconOf(pkg: String): String = synchronized(iconCache) {
        iconCache.getOrPut(pkg) {
            try {
                val d = packageManager.getApplicationIcon(pkg)
                val s = 72
                val bm = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
                val cv = android.graphics.Canvas(bm)
                d.setBounds(0, 0, s, s); d.draw(cv)
                val o = ByteArrayOutputStream()
                @Suppress("DEPRECATION")
                bm.compress(if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP, 80, o)
                bm.recycle()
                Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
            } catch (_: Throwable) { "" }
        }
    }

    private val pkgRe = Regex("[A-Za-z0-9_.]+")

    /** Native server first (shell may start activities from the background); else a direct start, plus the accessibility service. */
    private fun launchApp(p: String) {
        if (!pkgRe.matches(p)) return
        if (NativeInput.ver >= 3 && NativeInput.forward(JSONObject().put("t", "launch").put("p", p))) return
        try { packageManager.getLaunchIntentForPackage(p)?.let { startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } } catch (_: Exception) {}
        if (!Settings.canDrawOverlays(this)) RemoteAccess.handle(JSONObject().put("t", "launch").put("p", p))
    }

    private fun openUrl(u: String) {
        if (!(u.startsWith("https://") || u.startsWith("http://"))) return
        if (NativeInput.ver >= 3 && NativeInput.forward(JSONObject().put("t", "url").put("u", u))) return
        try { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
        if (!Settings.canDrawOverlays(this)) RemoteAccess.handle(JSONObject().put("t", "url").put("u", u))
    }

    private fun brightnessNow(): Double = try {
        Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS).toDouble() / briMax
    } catch (_: Exception) { -1.0 }

    private val adTitles = setOf("advertisement", "ad", "ads", "advert", "sponsored message", "commercial break")

    @Volatile private var access = true
    private fun mc(): MediaController? = try {
        val l = getSystemService(MediaSessionManager::class.java).getActiveSessions(ComponentName(this, MediaListener::class.java))
        access = true
        l.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: l.firstOrNull()
    } catch (_: SecurityException) { access = false; null } catch (_: Exception) { null }

    private fun pos(c: MediaController): Long {
        val p = c.playbackState ?: return 0
        val v = if (p.state == PlaybackState.STATE_PLAYING)
            p.position + ((SystemClock.elapsedRealtime() - p.lastPositionUpdateTime) * p.playbackSpeed).toLong() else p.position
        return v.coerceAtLeast(0)
    }

    private var artKey = ""
    private var artB64 = ""
    private var artTries = 0

    private fun scaled(bm: android.graphics.Bitmap): String {
        val sc = 640f / maxOf(bm.width, bm.height)
        val b = Bitmap.createScaledBitmap(bm, (bm.width * sc).toInt().coerceAtLeast(1), (bm.height * sc).toInt().coerceAtLeast(1), true)
        val o = ByteArrayOutputStream(); b.compress(Bitmap.CompressFormat.JPEG, 78, o)
        return Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
    }

    /** Thumbnail / cover: bitmap in the session metadata, then its content:// URI, then the player's notification icon. */
    private fun findArt(md: MediaMetadata?, pkg: String): Bitmap? {
        md?.let {
            listOf(MediaMetadata.METADATA_KEY_ART, MediaMetadata.METADATA_KEY_ALBUM_ART, MediaMetadata.METADATA_KEY_DISPLAY_ICON)
                .forEach { k -> it.getBitmap(k)?.let { b -> return b } }
            listOf(MediaMetadata.METADATA_KEY_ART_URI, MediaMetadata.METADATA_KEY_ALBUM_ART_URI, MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)
                .forEach { k ->
                    val u = it.getString(k)
                    if (u != null && (u.startsWith("content:") || u.startsWith("file:"))) try {
                        contentResolver.openInputStream(android.net.Uri.parse(u))?.use { st -> android.graphics.BitmapFactory.decodeStream(st)?.let { b -> return b } }
                    } catch (_: Exception) {}
                }
        }
        return MediaListener.icons[pkg]
    }

    private fun stateJson(): JSONObject {
        val j = JSONObject().put("t", "state")
        j.put("vol", am.getStreamVolume(AudioManager.STREAM_MUSIC)).put("max", am.getStreamMaxVolume(AudioManager.STREAM_MUSIC))
        val c = mc()
        j.put("access", access)
        val ad = RemoteAccess.adState()          // 0 none · 1 ad playing · 2 skip button visible
        j.put("ad", ad)
        j.put("bri", brightnessNow()).put("briok", canWriteSettings() || (NativeInput.connected && NativeInput.ver >= 2))
        if (c == null) return j.put("title", "Nothing playing").put("artist", "").put("playing", false).put("pos", 0).put("dur", 0).put("spd", 1.0).put("art", "")
        val md = c.metadata
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: c.packageName ?: ""
        val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: ""
        // music apps (Spotify, Pandora ...) announce their ads through the media session title
        if (ad == 0 && (title.trim().lowercase() in adTitles || artist.trim().lowercase() in adTitles)) j.put("ad", 1)
        val key = c.packageName + "|" + title + "|" + artist
        if (key != artKey) { artKey = key; artB64 = ""; artTries = 0 }
        // players often attach the thumbnail a moment after the title, so keep looking for a few seconds
        if (artB64.isEmpty() && artTries < 30) { artTries++; findArt(md, c.packageName)?.let { artB64 = scaled(it) } }
        return j.put("title", title).put("artist", artist).put("art", artB64)
            .put("playing", c.playbackState?.state == PlaybackState.STATE_PLAYING)
            .put("pos", pos(c)).put("dur", md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L)
            .put("spd", (c.playbackState?.playbackSpeed ?: 1f).toDouble())
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }
}
