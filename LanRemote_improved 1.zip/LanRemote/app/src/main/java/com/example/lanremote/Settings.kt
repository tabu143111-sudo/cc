package com.example.lanremote

import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** User settings of the controller (left drawer -> Settings). Observable, saved immediately. */
object Cfg {
    private var p: SharedPreferences? = null
    var padSpeed by mutableFloatStateOf(1.6f)       // pointer speed of the touchpad
    var scrollGain by mutableFloatStateOf(1f)       // swipe / scroll sensitivity
    var natural by mutableStateOf(true)             // scroll direction: natural (content follows the fingers) or classic
    var artAlpha by mutableFloatStateOf(0.85f)      // opacity of the media background picture
    var artBlur by mutableFloatStateOf(10f)         // blur radius (dp) of the media background picture
    var autoSkip by mutableStateOf(true)            // host: press "Skip ad" by itself
    var hostKb by mutableStateOf(false)             // host: allow its on-screen keyboard to pop up

    fun load(sp: SharedPreferences) {
        p = sp
        padSpeed = sp.getFloat("speed", 1.6f); scrollGain = sp.getFloat("scroll_gain", 1f); natural = sp.getBoolean("natural", true)
        artAlpha = sp.getFloat("art_alpha", 0.85f); artBlur = sp.getFloat("art_blur", 10f)
        autoSkip = sp.getBoolean("auto_skip", true); hostKb = sp.getBoolean("host_kb", false)
    }
    fun save() {
        p?.edit()?.putFloat("speed", padSpeed)?.putFloat("scroll_gain", scrollGain)?.putBoolean("natural", natural)
            ?.putFloat("art_alpha", artAlpha)?.putFloat("art_blur", artBlur)?.putBoolean("auto_skip", autoSkip)?.putBoolean("host_kb", hostKb)?.apply()
    }
    /** Tells a host which of these settings live on the host. */
    fun pushToHost(c: Client) { c.send("cfg", "k" to "autoskip", "v" to autoSkip); c.send("cfg", "k" to "hostkb", "v" to hostKb) }
}
