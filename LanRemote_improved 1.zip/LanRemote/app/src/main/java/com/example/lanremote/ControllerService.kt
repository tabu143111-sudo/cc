package com.example.lanremote

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.net.wifi.WifiManager
import android.os.IBinder

/**
 * Foreground service that runs while this device is controlling a host. It keeps the process (and therefore the
 * socket + the auto-reconnect loop) alive when the app is minimised, and holds a Wi-Fi lock so Wi-Fi does not nap.
 */
class ControllerService : Service() {
    companion object { const val ACT_DISCONNECT = "com.example.lanremote.DISCONNECT" }
    private var wifi: WifiManager.WifiLock? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == ACT_DISCONNECT) { Session.disconnect(this); stopSelf(); return START_NOT_STICKY }
        val ch = "controller"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Controller", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val stop = PendingIntent.getService(this, 1, Intent(this, ControllerService::class.java).setAction(ACT_DISCONNECT),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val host = Session.client?.host ?: ""
        startForeground(2, Notification.Builder(this, ch).setContentTitle("LAN Remote connected")
            .setContentText(if (host.isEmpty()) "Controlling a host" else "Controlling $host")
            .setSmallIcon(android.R.drawable.ic_media_play).setContentIntent(open).setOngoing(true)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Disconnect", stop).build())
            .build())
        if (wifi == null) try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION")
            wifi = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "lanremote:controller").apply { setReferenceCounted(false); acquire() }
        } catch (_: Exception) {}
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        try { wifi?.release() } catch (_: Exception) {}
        wifi = null
        super.onDestroy()
    }
}
