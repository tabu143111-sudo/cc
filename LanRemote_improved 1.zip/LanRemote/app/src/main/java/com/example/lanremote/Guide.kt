package com.example.lanremote

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val PKG = "com.example.lanremote"
private val Slate = Brush.linearGradient(listOf(Color(0xFF334155), Color(0xFF475569)))

/** Command box with a Copy button. */
@Composable private fun Cmd(text: String) {
    val cb = LocalClipboardManager.current
    val ctx = LocalContext.current
    Column(Modifier.fillMaxWidth().padding(top = 8.dp).clip(RoundedCornerShape(12.dp)).background(Color(0x22000000))
        .border(1.dp, Edge, RoundedCornerShape(12.dp)).padding(12.dp)) {
        SelectionContainer { Text(text, fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = Accent2) }
        Text("Copy", color = Accent, fontWeight = FontWeight.Bold, fontSize = 13.sp,
            modifier = Modifier.padding(top = 8.dp).clip(RoundedCornerShape(8.dp)).clickable {
                cb.setText(AnnotatedString(text)); Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
            }.padding(vertical = 4.dp, horizontal = 2.dp))
    }
}

@Composable private fun StepTitle(n: Int, title: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(28.dp).clip(CircleShape).background(Grad), contentAlignment = Alignment.Center) {
            Text("$n", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White) }
        Spacer(Modifier.width(10.dp))
        Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
    Spacer(Modifier.height(8.dp))
}

@Composable private fun Body(t: String) = Text(t, color = Muted, fontSize = 13.sp, lineHeight = 19.sp)

@Composable private fun Status(label: String, ok: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 3.dp)) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(if (ok) Good else Bad))
        Spacer(Modifier.width(10.dp)); Text(label, fontSize = 14.sp)
    }
}

private const val STEPS = 6
private val TITLES = listOf("Install Termux", "Allow Termux access", "Wireless debugging", "Pair (one time)", "One-tap setup", "Finished")

@Composable private fun Hint(t: String) = Text(t, color = Accent2, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(top = 8.dp))

@Composable fun GuideScreen(onBack: () -> Unit) = Screen {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var step by remember { mutableIntStateOf(appPrefs.getInt("guide_step", 0).coerceIn(0, STEPS - 1)) }
    fun go(n: Int) { step = n.coerceIn(0, STEPS - 1); appPrefs.edit().putInt("guide_step", step).apply() }

    // live status
    var termux by remember { mutableStateOf(false) }
    var allowed by remember { mutableStateOf(false) }
    var wdbg by remember { mutableIntStateOf(-1) }
    var perm by remember { mutableStateOf(false) }
    var acc by remember { mutableStateOf(false) }
    var native by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { while (true) {
        termux = NativeStarter.termuxInstalled(ctx); allowed = NativeStarter.termuxAllowed(ctx); wdbg = NativeStarter.wirelessDebugging(ctx)
        perm = AutoGrant.canWrite(ctx); acc = RemoteAccess.instance != null; native = NativeInput.connected; delay(800) } }

    val ip = remember { hostIp().takeIf { it.contains('.') } ?: "<IP>" }
    var pairPort by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    var connPort by remember { mutableStateOf(appPrefs.getString("adb_port", "") ?: "") }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { allowed = NativeStarter.termuxAllowed(ctx) }
    val busy = NativeStarter.busy

    Header("Setup guide", "Step ${step + 1} of $STEPS · ${TITLES[step]}", onBack)
    LinearProgressIndicator(progress = { (step + 1) / STEPS.toFloat() }, modifier = Modifier.padding(horizontal = 20.dp).fillMaxWidth().height(5.dp).clip(CircleShape),
        color = Accent2, trackColor = Edge)
    Column(Modifier.weight(1f).padding(horizontal = 20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Spacer(Modifier.height(2.dp))
        when (step) {
            0 -> Panel {
                StepTitle(1, "Install Termux on this device")
                Body("This guide is for the device that will be CONTROLLED (the host). Termux is a small terminal app. The setup script runs inside it, " +
                    "so no PC is needed.\n\n1. Install Termux from F-Droid or from GitHub (the Play Store version is outdated and cannot be controlled by other apps).\n" +
                    "2. Open Termux once and run this command, then wait until it finishes:")
                Cmd("pkg update -y && pkg install -y android-tools")
                Spacer(Modifier.height(10.dp))
                GradBtn("Open Termux", brush = Slate) {
                    val i = ctx.packageManager.getLaunchIntentForPackage("com.termux")
                    if (i != null) ctx.startActivity(i) else Toast.makeText(ctx, "Termux is not installed here", Toast.LENGTH_SHORT).show()
                }
                Spacer(Modifier.height(8.dp))
                Status(if (termux) "Termux is installed" else "Termux not found on this device", termux)
            }

            1 -> Panel {
                StepTitle(2, "Let LAN Remote run commands in Termux")
                Body("Two switches are needed so another app may use Termux.\n\nA. In Termux run this command, then CLOSE Termux completely (type exit, swipe it away from recents) and open it again:")
                Cmd("mkdir -p ~/.termux && sed -i '/^allow-external-apps/d' ~/.termux/termux.properties 2>/dev/null; echo 'allow-external-apps = true' >> ~/.termux/termux.properties")
                Spacer(Modifier.height(10.dp))
                GradBtn("Open Termux", brush = Slate) { ctx.packageManager.getLaunchIntentForPackage("com.termux")?.let { ctx.startActivity(it) } }
                Spacer(Modifier.height(14.dp))
                Body("B. Give this app the permission \"Run commands in Termux environment\":")
                Spacer(Modifier.height(8.dp))
                GradBtn(if (allowed) "Permission granted ✔" else "Grant permission") {
                    if (!termux) Toast.makeText(ctx, "Install Termux first (step 1)", Toast.LENGTH_SHORT).show()
                    else if (!allowed) permLauncher.launch(NativeStarter.TERMUX_PERM)
                }
                Hint("If the pop-up does not appear (denied before): tap the button below → Permissions → Additional permissions → \"Run commands in Termux environment\" → Allow.")
                Spacer(Modifier.height(8.dp))
                GradBtn("Open this app's permission settings", brush = Slate) {
                    ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$PKG")))
                }
                Spacer(Modifier.height(14.dp))
                Body("C. Check the link between the two apps:")
                Spacer(Modifier.height(8.dp))
                GradBtn("Test Termux link", brush = Slate) { NativeStarter.testResult = ""; NativeStarter.testTermux(ctx) }
                if (NativeStarter.testResult.isNotEmpty()) Text(NativeStarter.testResult, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp),
                    color = if (NativeStarter.testResult.startsWith("✔")) Good else if (NativeStarter.testResult.startsWith("Testing")) Muted else Bad)
                Spacer(Modifier.height(8.dp))
                Status(if (allowed) "Permission: granted" else "Permission: not granted", allowed)
                Body("\nAlso recommended: Settings → Apps → Termux → Battery → Unrestricted, so Android does not kill it.")
            }

            2 -> Panel {
                StepTitle(3, "Turn on Wireless debugging")
                Body("Open Developer options and switch on Wireless debugging (the device must be connected to Wi-Fi; a hotspot of another phone also works). " +
                    "If Developer options is hidden: Settings → About phone → tap Build number 7 times.\n\nWhen Android asks \"Allow wireless debugging on this network?\" choose Allow.")
                Spacer(Modifier.height(10.dp))
                GradBtn("Open Developer options", brush = Slate) {
                    try { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) }
                    catch (_: Exception) { ctx.startActivity(Intent(Settings.ACTION_DEVICE_INFO_SETTINGS)) } }
                Spacer(Modifier.height(8.dp))
                if (wdbg >= 0) Status(if (wdbg == 1) "Wireless debugging: on" else "Wireless debugging: off", wdbg == 1)
                else Body("Status cannot be read on this phone. Just make sure the switch is on.")
            }

            3 -> Panel {
                StepTitle(4, "Pair Termux with this device (once)")
                Body("Android only trusts adb after a one-time pairing. Both apps must be visible at once, so use split-screen or a floating window " +
                    "(the pairing dialog closes if you leave it).\n\n1. Developer options → Wireless debugging → Pair device with pairing code. Keep that dialog open.\n" +
                    "2. Tap the button to read the pairing port automatically (or type the port shown in the dialog).")
                Spacer(Modifier.height(10.dp))
                GradBtn(if (searching) "Searching… keep the dialog open" else "Detect pairing port", brush = Slate) {
                    if (!searching) { searching = true
                        scope.launch { val p = withContext(Dispatchers.IO) { NativeStarter.discover(ctx, "_adb-tls-pairing._tcp", 20) }
                            searching = false
                            if (p > 0) pairPort = p.toString() else Toast.makeText(ctx, "Not found. Is the pairing dialog open?", Toast.LENGTH_LONG).show() } }
                }
                OutlinedTextField(pairPort, { pairPort = it.filter(Char::isDigit).take(5) }, Modifier.fillMaxWidth().padding(top = 10.dp),
                    label = { Text("Pairing port") }, singleLine = true, shape = RoundedCornerShape(14.dp), colors = tfColors())
                Body("\n3. In Termux run this command, then type the 6-digit code from the dialog:")
                Cmd("adb pair $ip:${pairPort.ifBlank { "PORT" }}")
                Body("\nWait for \"Successfully paired\". Pairing is remembered, so you never repeat this step unless you clear Termux data.")
            }

            4 -> Panel {
                StepTitle(5, "Run the setup script (one tap)")
                Body("This one button asks Termux to: connect to Wireless debugging → grant the app its permanent permissions → switch on Accessibility " +
                    "and notification access by itself → start the native mouse & keyboard server → open this app. After the first success it repeats " +
                    "this automatically whenever the host runs.\n\nKeep Wireless debugging switched on.")
                Spacer(Modifier.height(10.dp))
                GradBtn(if (busy) "Working…" else "▶  Run setup script", brush = if (busy) Slate else Grad) {
                    if (!busy) { NativeStarter.status = ""; NativeStarter.start(ctx) } }
                if (NativeStarter.status.isNotEmpty()) Text(NativeStarter.status, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp),
                    color = if (NativeStarter.status.startsWith("✔")) Good else if (NativeStarter.status.startsWith("✖")) Bad else Accent2)
                if (NativeStarter.log.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp)); Label("OUTPUT FROM TERMUX")
                    Cmd(NativeStarter.log.takeLast(900))
                }
                Spacer(Modifier.height(12.dp))
                Label("OPTIONAL: PORT BY HAND")
                Body("Only needed if the app cannot find the port itself. Type the port shown on the main Wireless debugging screen.")
                OutlinedTextField(connPort, { connPort = it.filter(Char::isDigit).take(5); appPrefs.edit().putString("adb_port", connPort).apply() },
                    Modifier.fillMaxWidth().padding(top = 8.dp), label = { Text("Connect port (optional)") }, singleLine = true,
                    shape = RoundedCornerShape(14.dp), colors = tfColors())
                Spacer(Modifier.height(8.dp))
                Status(if (perm) "Permanent access: granted" else "Permanent access: not yet", perm)
                Status(if (native) "Native mouse & keyboard: running" else "Native mouse & keyboard: not running", native)
            }

            else -> {
                Panel {
                    StepTitle(6, "Finished")
                    Label("STATUS (LIVE)"); Spacer(Modifier.height(6.dp))
                    Status(if (perm) "Permanent access: active" else "Permanent access: not granted yet", perm)
                    Status(if (acc) "Accessibility (fallback mouse & keyboard): on" else "Accessibility: off (turns on by itself once access is granted)", acc)
                    Status(if (native) "Native mouse & keyboard: running" else "Native mouse & keyboard: not running", native)
                    Spacer(Modifier.height(10.dp))
                    Body("Now open Host → Start host on this device, and Controller on the other device. Native input starts by itself each time the host runs. " +
                        "After a reboot just start the host again (keep Wireless debugging on); the guide is not needed again.")
                    Spacer(Modifier.height(10.dp))
                    GradBtn("Run setup script again", brush = Slate) { go(4); NativeStarter.start(ctx) }
                }
                Panel {
                    Label("TROUBLESHOOTING"); Spacer(Modifier.height(6.dp))
                    Body("• Test Termux link fails: redo step 2 (A: restart Termux completely, B: permission).\n" +
                        "• \"could not connect\" / \"not paired\": repeat step 4; the pairing dialog must stay open.\n" +
                        "• Port not found: turn Wireless debugging off and on, or type the port in step 5.\n" +
                        "• Grant refused on Xiaomi/Poco/Redmi/Honor: enable \"USB debugging (Security settings)\" in Developer options.\n" +
                        "• Termux killed in the background: set its battery to Unrestricted.\n" +
                        "• PC instead? Run adb_setup.sh / adb_setup.bat from the project folder.")
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
    Row(Modifier.fillMaxWidth().padding(20.dp, 10.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        GradBtn("‹  Back", Modifier.weight(1f), brush = Slate) { if (step == 0) onBack() else go(step - 1) }
        GradBtn(if (step == STEPS - 1) "Done" else "Next  ›", Modifier.weight(1f)) { if (step == STEPS - 1) onBack() else go(step + 1) }
    }
}
