#!/data/data/com.termux/files/usr/bin/bash
# LAN Remote - one-tap setup. Runs INSIDE Termux on the host device (started by the app, or by hand:
#   bash lanremote_setup.sh <wireless-debugging-port>
# It connects to this device's Wireless debugging, grants the app its permanent permissions (so it can switch on
# Accessibility by itself), starts the native mouse + keyboard server and opens the app.
PKG=com.example.lanremote
PORT="$1"
export PATH="$PATH:/data/data/com.termux/files/usr/bin"

command -v adb >/dev/null 2>&1 || { echo "ERROR: adb is not installed in Termux. Run: pkg install android-tools"; exit 2; }
[ -n "$PORT" ] || { echo "ERROR: no Wireless debugging port was given."; exit 2; }
A="127.0.0.1:$PORT"
SH="adb -s $A shell"

echo "[1/5] Connecting to Wireless debugging ($A)"
adb start-server >/dev/null 2>&1
OUT=$(adb connect "$A" 2>&1); echo "$OUT"
case "$OUT" in
  *"connected to"*) ;;
  *) echo "ERROR: could not connect. Pair first (guide step 4: adb pair IP:PAIRING-PORT) and keep Wireless debugging on."; exit 3 ;;
esac
[ "$($SH echo ok 2>/dev/null | tr -d '\r')" = "ok" ] || { echo "ERROR: this Termux is not paired/authorised yet. Do guide step 4 (adb pair)."; adb disconnect "$A" >/dev/null 2>&1; exit 3; }

echo "[2/5] Granting permanent access to LAN Remote"
$SH pm grant $PKG android.permission.WRITE_SECURE_SETTINGS || { echo "ERROR: grant refused. On Xiaomi/Poco/Redmi/Honor also enable 'USB debugging (Security settings)' in Developer options."; exit 4; }
$SH pm grant $PKG android.permission.POST_NOTIFICATIONS >/dev/null 2>&1
$SH cmd notification allow_listener $PKG/$PKG.MediaListener >/dev/null 2>&1
$SH dumpsys deviceidle whitelist +$PKG >/dev/null 2>&1
for op in WRITE_SETTINGS SYSTEM_ALERT_WINDOW RUN_IN_BACKGROUND; do $SH cmd appops set $PKG $op allow >/dev/null 2>&1; done

echo "[3/5] Starting native mouse + keyboard server"
$SH "pkill -f $PKG.InputServer" >/dev/null 2>&1
$SH "mkdir -p /sdcard/Android/data/$PKG/files" >/dev/null 2>&1
# setsid + nohup: the server must keep running after this script disconnects
$SH "CLASSPATH=\$(pm path $PKG | head -n 1 | cut -d: -f2); export CLASSPATH; if command -v setsid >/dev/null 2>&1; then S=setsid; else S=; fi; \$S nohup app_process /system/bin $PKG.InputServer >/data/local/tmp/lanremote.log 2>&1 &"
sleep 3
$SH cat /data/local/tmp/lanremote.log 2>/dev/null

echo "[4/5] Activating the app"
$SH am start -n $PKG/.MainActivity >/dev/null 2>&1

echo "[5/5] Done"
adb disconnect "$A" >/dev/null 2>&1
exit 0
