# LAN Remote
Open this folder in Android Studio -> Run (or Build > Build APK) -> install on both devices.

Host: start host, set PIN. Controller: pick host from list (or type IP) + PIN.

## Native mouse + keyboard and permanent permissions (ADB)
On the host device: enable USB debugging, connect to the PC, run `adb_setup.bat` (Windows) or `./adb_setup.sh` (Mac/Linux).
- Grants WRITE_SECURE_SETTINGS + notification access and exempts the app from battery optimisation. The app then keeps
  Accessibility and notification access switched on by itself (also after reboot).
- Starts `InputServer` with shell privileges. It injects real mouse and keyboard events (system pointer, hover, scroll wheel,
  hardware key events) – the host behaves as if a physical mouse/keyboard were attached. Re-run the script after a reboot.
- If the server is not running, the app falls back to the Accessibility-based pointer/keyboard.
Manual alternative for permissions only: `adb shell pm grant com.example.lanremote android.permission.WRITE_SECURE_SETTINGS`.

## In-app setup guide (serial, no PC)
Open the app -> **Setup guide**. It is a 6-step wizard (progress bar, Back/Next, live status, copy buttons):
1. Install Termux (F-Droid/GitHub) + `pkg install android-tools`.
2. Allow other apps to use Termux: `allow-external-apps = true` command (then restart Termux), the **Run commands in Termux** permission button (plus a shortcut to the app's permission page if it was denied before), and a **Test Termux link** button that shows Termux's real answer.
3. Turn on Wireless debugging (status shown).
4. Pair once: **Detect pairing port** reads the port from the open pairing dialog, then run the shown `adb pair` command in Termux.
5. **One tap - Run setup script**: the app finds the wireless-debugging port (mDNS), asks Termux to run `assets/lanremote_setup.sh` (also available as `termux_setup.sh <port>`), which connects, grants WRITE_SECURE_SETTINGS (so the app switches Accessibility + notification access on by itself), starts the native mouse/keyboard server and opens the app. Termux's output is shown in the guide. After the first success it repeats automatically whenever the host runs (also after reboot, while Wireless debugging is on).
6. Finished: live status + troubleshooting.

## Connection reliability (v4)
- **Controller keeps its devices**: every host you connect to is saved (name, IP, pairing code) under *Saved devices* (tap to connect, ✕ to forget). If a saved host got a new IP (DHCP) it is found again by name.
- **Minimise-proof**: the connection lives in a process-wide `Session` plus a foreground `ControllerService` (notification with *Disconnect*, Wi-Fi lock). The client reconnects by itself when the link drops (Wi-Fi nap, host restart) and the remote screen shows "Reconnecting...". If Android still kills the app, it silently reconnects to the last host on next launch. Back minimises instead of disconnecting; **Disconnect** ends the session.
- **Stop host really stops**: the service now closes the listening socket AND every connected controller, unregisters mDNS, releases the Wi-Fi lock and frees the mouse button. The button reflects the real state, the notification has a *Stop* action, the host shows how many controllers are connected, and the pairing code is remembered between runs so saved devices keep working.

## Touchpad gestures
1 finger: move, tap = click, double-tap = double click, tap then touch-and-drag = drag/select, **hold still = press-and-hold the left button like a real mouse** (long-press on the host; keep moving = drag; lift = release).
2 fingers: drag = scroll (vertical + horizontal, with momentum), pinch = zoom, **tap = right click**.
3 fingers: swipe up = Recents, down = Home, left = Back, right = App drawer (short swipe, ~1 cm, is enough).
4 fingers: swipe down = Notifications, up = Quick settings, left = Back, right = Recents.
"Natural/Classic" under the pad flips the scroll direction; "?" shows this list in the app.
Drag and horizontal scroll use the native server when it runs; pinch zoom, notifications and quick settings always use Accessibility.

## Controller screen
- Always full screen (status + navigation bars hidden; swipe from the edge to peek). Landscape uses the whole screen:
  touchpad on the left, status + media card (stretches to the full height) + text input on the right.
- Media card: previous / -10 s / play-pause / +10 s / next, seek bar and a volume bar. The expand button opens a full-bleed
  cover-art view (no frame or borders).
- **Skip ad**: while an ad runs on the host (YouTube etc., found through the Accessibility service) a "Skip ad" pill appears;
  it is greyed out ("Ad playing...") until the host shows its Skip button, then tapping it presses that button.
- Smooth cursor: moves are merged on the controller, TCP_NODELAY on both ends, the overlay pointer eases towards its target
  every frame and the native input server injects movement in 8 ms steps.

## Typing, backspace, brightness, ad skipping (latest changes)
- **Live typing**: the input box now behaves like a keyboard of the host. Every character you type (and every deletion) appears
  immediately in the focused field on the host; "LIVE" next to the box switches back to the old type-then-send mode.
  ➤ = Enter (and clears the box). Backspace with an empty box still deletes on the host.
- **Backspace**: hold the ⌫ button to keep deleting (accelerates). Deleting and typing now happen **at the caret** of the host
  field (with the native server through real DEL key events, with Accessibility through the field's selection), not at the end.
- **Media full screen**: drag up/down on the **left half** = host brightness, on the **right half** = host volume (level bar shown).
  Brightness needs either the native server running or WRITE_SETTINGS (adb_setup grants it; or Host screen > Allow brightness control).
- **Skip ad** now scans every on-screen app window and recognises skip buttons of YouTube / YouTube Music, Hotstar, JioCinema,
  SonyLIV, ZEE5, Prime Video, Disney+, Hulu, Peacock, Paramount+, Max, Tubi, Pluto, Twitch, Dailymotion, Vimeo, MX Player,
  Facebook/Instagram/TikTok, Spotify, Pandora, SoundCloud, Deezer, JioSaavn, Gaana, Wynk and more, and inside Chrome, Firefox,
  Edge, Brave, Opera, Samsung Internet, Vivaldi, DuckDuckGo, Kiwi, UC, Yandex, Mi Browser (web pages such as m.youtube.com).
  Ads that the service itself makes unskippable (e.g. Spotify free audio ads) only show "Ad playing...".

## Video full screen + keyboard (v3)
- **⛶ Video** button (media card and media full screen): toggles full screen of the video on the host. It presses the player's
  own full-screen button (YouTube, Hotstar, Prime, Spotify video, ExoPlayer apps, web players in Chrome/Firefox/Edge/Brave/...). If
  the button is hidden it taps the video once to show the controls, and on the YouTube app falls back to the swipe-up gesture.
- **Typing pipeline**: edits are merged for 25 ms into one packet (delete N, then insert text), so fast typing and held keys
  cost one message instead of dozens; Enter/other keys always flush pending text first, so order is guaranteed.
- **Keyboard keys**: while the input box is focused a key row appears: Esc, Tab, arrows, Home, End, Del. Hold = repeat.

## Shortcuts drawer (left side)
Tap **☰ Shortcuts** (top left of the controller) or swipe in from the left edge. Tap a tile to run it ON THE HOST, long-press to edit,
delete or reorder, **+ Add** to create one. Types: **App** (pick from the host's installed apps, or type a package name), **Website**
(opens the address in the host's browser), **Text** (types it, optionally + Enter), **System** (Home, Back, Recents, Notifications, Quick
settings, App drawer, Screenshot, Lock, Power menu) and **Media** (play/pause, next, previous, mute). They are stored on the controller.
App/website launching from the background is done by the native server (re-run adb_setup once; it also grants the overlay permission
Android requires for that), otherwise by the app itself when "Display over other apps" is allowed.

## After updating the app
Re-install on both devices, then **re-run adb_setup / "Start native server"** (the native server keeps running the old code until
restarted). If Skip ad is not detected, switch the Accessibility service off and on once (its flags changed).
Some phones (Xiaomi/HyperOS, OPPO, Samsung) have their own 3-finger system gestures; turn them off in system settings if they cancel touches.

## v1.2 additions
- **App icons**: the host sends each app's icon with the app list; the app picker shows them and app shortcuts keep the real icon (older shortcuts get theirs automatically).
- **Left drawer -> Settings**: pointer speed, swipe/scroll sensitivity, scroll direction (Natural / Classic), media background opacity + blur, host options (auto ad skip, keyboard pop-up).
- **Host keyboard stays hidden** while a controller types (Accessibility soft-keyboard mode), unless "Allow keyboard pop-up" is switched on (Settings drawer or Host screen). It is restored when the host stops.
- **Automatic ad skipping on the host**: every ~0.9 s the host looks for a "Skip ad" button in YouTube, browsers and streaming apps and presses it by itself (switch in Settings / Host screen).
- **Video full screen**: finds the button by id and label (many languages); otherwise taps the real player surface to wake the controls (twice if needed), then falls back to the YouTube swipe gesture.
- **Full-screen media**: double-tap left/right half = back/forward 10 s; playback-speed menu (0.5x-3x; needs a player that accepts speed changes, Android 10+); background opacity/blur from Settings.
- **Typing**: delete + insert is applied as ONE edit on the host and Accessibility edits keep their order (fixes garbled Bangla from Gboard). In live mode the Send button is replaced by a sticky **Ctrl** key (Ctrl+A/C/V/X...). Restart the native server once so it understands Ctrl.
