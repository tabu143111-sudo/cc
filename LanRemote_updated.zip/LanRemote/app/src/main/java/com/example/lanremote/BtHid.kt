package com.example.lanremote

import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.concurrent.Executors

/** Acts as a real Bluetooth HID mouse (Android 9+). The other device just sees a paired mouse. */
@SuppressLint("MissingPermission")
object BtHid {
    var useBt by mutableStateOf(false)
    var connected by mutableStateOf(false)
    var status by mutableStateOf("Bluetooth off")
    private var hid: BluetoothHidDevice? = null
    private var host: BluetoothDevice? = null
    private var adapter: BluetoothAdapter? = null
    private val desc = intArrayOf(0x05,0x01,0x09,0x02,0xA1,0x01,0x09,0x01,0xA1,0x00,0x05,0x09,0x19,0x01,0x29,0x03,
        0x15,0x00,0x25,0x01,0x95,0x03,0x75,0x01,0x81,0x02,0x95,0x01,0x75,0x05,0x81,0x03,0x05,0x01,0x09,0x30,
        0x09,0x31,0x09,0x38,0x15,0x81,0x25,0x7F,0x75,0x08,0x95,0x03,0x81,0x06,0xC0,0xC0).map { it.toByte() }.toByteArray()

    fun start(ctx: Context) {
        if (hid != null) return
        adapter = ctx.getSystemService(BluetoothManager::class.java)?.adapter
        val ad = adapter ?: run { status = "No Bluetooth"; return }
        if (!ad.isEnabled) { status = "Turn Bluetooth on"; return }
        status = "Starting…"
        ad.getProfileProxy(ctx.applicationContext, object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(p: Int, proxy: BluetoothProfile) {
                val h = proxy as BluetoothHidDevice; hid = h
                h.registerApp(BluetoothHidDeviceAppSdpSettings("LAN Remote", "Mouse", "LanRemote", BluetoothHidDevice.SUBCLASS1_MOUSE, desc),
                    null, null, Executors.newSingleThreadExecutor(), object : BluetoothHidDevice.Callback() {
                        override fun onConnectionStateChanged(d: BluetoothDevice, s: Int) {
                            connected = s == BluetoothProfile.STATE_CONNECTED
                            if (connected) host = d
                            status = if (connected) "Connected to ${d.name}" else "Not connected"
                        }
                    })
                status = "Ready – choose host"
            }
            override fun onServiceDisconnected(p: Int) { hid = null; connected = false; status = "Bluetooth service lost" }
        }, BluetoothProfile.HID_DEVICE)
    }

    fun bonded(): List<BluetoothDevice> = adapter?.bondedDevices?.toList() ?: emptyList()
    fun connect(d: BluetoothDevice) { hid?.connect(d) }
    fun send(buttons: Int, dx: Int, dy: Int, wheel: Int) {
        val h = hid ?: return; val d = host ?: return
        h.sendReport(d, 0, byteArrayOf(buttons.toByte(), dx.coerceIn(-127, 127).toByte(), dy.coerceIn(-127, 127).toByte(), wheel.toByte()))
    }
}
