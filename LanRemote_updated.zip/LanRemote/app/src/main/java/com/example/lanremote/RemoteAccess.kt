package com.example.lanremote

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONObject

/** Mouse + keyboard injection. Needs the user to enable it in Accessibility settings. */
class RemoteAccess : AccessibilityService() {
    companion object {
        @Volatile var instance: RemoteAccess? = null
        fun handle(j: JSONObject) { instance?.run(j) }
    }
    private val ui = Handler(Looper.getMainLooper())
    private var x = 0f; private var y = 0f
    private var cursor: PointerView? = null
    private val hideCursor = Runnable { cursor?.visibility = View.GONE }
    private val IDLE_MS = 30_000L
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams

    override fun onServiceConnected() {
        instance = this
        val dm = resources.displayMetrics
        x = dm.widthPixels / 2f; y = dm.heightPixels / 2f
        wm = getSystemService(WindowManager::class.java)
        val pv = PointerView(this); cursor = pv
        lp = WindowManager.LayoutParams(pv.w, pv.h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START }
        place(); wm.addView(cursor, lp); wake()
    }

    private fun place() { lp.x = x.toInt(); lp.y = y.toInt(); if (cursor?.isAttachedToWindow == true) wm.updateViewLayout(cursor, lp) }

    /** Show the pointer and (re)start the 30 s idle timer. */
    private fun wake() {
        cursor?.visibility = View.VISIBLE
        ui.removeCallbacks(hideCursor); ui.postDelayed(hideCursor, IDLE_MS)
    }

    private fun run(j: JSONObject) = ui.post {
        val dm = resources.displayMetrics
        when (j.getString("t")) {
            "move" -> { x = (x + j.getDouble("dx").toFloat()).coerceIn(0f, dm.widthPixels - 1f)
                        y = (y + j.getDouble("dy").toFloat()).coerceIn(0f, dm.heightPixels - 1f); place(); wake() }
            "click" -> { wake(); gesture(x, y, x, y, 50) }
            "rclick" -> { wake(); gesture(x, y, x, y, 700) }
            "scroll" -> { wake(); val d = j.getDouble("dy").toFloat().coerceIn(-400f, 400f)
                          gesture(x, y, x, (y - d * 2).coerceIn(0f, dm.heightPixels - 1f), 250) }
            "fs" -> fullscreen()
            "text" -> edit { it + j.getString("s") }
            "key" -> when (j.getString("k")) {
                "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
                "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
                "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
                "drawer" -> openDrawer()
                "backspace" -> edit { it.dropLast(1) }
                "enter" -> enter()
            }
        }
    }

    /** Opens the app drawer: system "all apps" action on Android 12L+, else Home + swipe up. */
    private fun openDrawer() {
        if (Build.VERSION.SDK_INT >= 32 && performGlobalAction(GLOBAL_ACTION_ACCESSIBILITY_ALL_APPS)) return
        performGlobalAction(GLOBAL_ACTION_HOME)
        ui.postDelayed({
            val dm = resources.displayMetrics
            val cx = dm.widthPixels / 2f
            gesture(cx, dm.heightPixels * 0.92f, cx, dm.heightPixels * 0.35f, 250)
        }, 400)
    }

    private fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long) {
        val p = Path().apply { moveTo(x1, y1); if (x1 != x2 || y1 != y2) lineTo(x2, y2) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, ms)).build(), null, null)
    }

    private fun edit(f: (String) -> String) {
        val n = findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return
        val cur = if (n.isShowingHintText) "" else n.text?.toString() ?: ""
        n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, f(cur)) })
    }

    /** Clicks any on-screen button whose text/description says "full screen" (toggles enter/exit). */
    private fun fullscreen() {
        val root = rootInActiveWindow ?: return
        for (w in listOf("full screen", "fullscreen", "full-screen")) {
            val n = root.findAccessibilityNodeInfosByText(w).firstOrNull() ?: continue
            var t: AccessibilityNodeInfo? = n
            while (t != null && !t.isClickable) t = t.parent
            if (t != null) { t.performAction(AccessibilityNodeInfo.ACTION_CLICK); return }
        }
    }

    private fun enter() {
        val n = findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return
        if (Build.VERSION.SDK_INT >= 30) n.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        else edit { it + "\n" }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: android.content.Intent?): Boolean {
        instance = null
        ui.removeCallbacks(hideCursor)
        try { wm.removeView(cursor) } catch (_: Exception) {}
        return super.onUnbind(i)
    }
}

/** Classic arrow mouse pointer. The tip (hotspot) is the top-left corner of the view. */
class PointerView(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val k = 1.5f * d
    val w = (14 * k).toInt(); val h = (21 * k).toInt()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 1.3f * d; strokeJoin = Paint.Join.ROUND }
    private val path = android.graphics.Path().apply {
        moveTo(1f * k, 1f * k); lineTo(1f * k, 17.5f * k); lineTo(5f * k, 13.5f * k); lineTo(8f * k, 20f * k)
        lineTo(10.5f * k, 19f * k); lineTo(7.5f * k, 12.5f * k); lineTo(13f * k, 12.5f * k); close()
    }
    override fun onDraw(c: Canvas) { c.drawPath(path, fill); c.drawPath(path, line) }
}
