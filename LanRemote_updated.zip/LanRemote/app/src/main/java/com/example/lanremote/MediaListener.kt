package com.example.lanremote

import android.service.notification.NotificationListenerService

/** Empty on purpose: enabling it grants permission to read the active media session (title, art, position). */
class MediaListener : NotificationListenerService()
