# LAN Remote
Open this folder in Android Studio -> Run (or Build > Build APK) -> install on both devices.
Host: start host, set PIN, enable Accessibility (for mouse/keyboard).
Controller: pick host from list (or type IP) + PIN. Home screen = touchpad, L/R, nav buttons, app-drawer button, media controls, text input. Volume buttons on the controller drive the host volume.
