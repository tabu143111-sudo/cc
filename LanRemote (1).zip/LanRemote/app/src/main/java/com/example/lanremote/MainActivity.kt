package com.example.lanremote

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.ActivityInfo
import android.view.KeyEvent
import android.view.WindowManager
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.compose.foundation.text.selection.SelectionContainer
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.util.concurrent.Executors
import kotlin.math.abs
import android.util.Base64
import android.content.SharedPreferences
import android.content.res.Configuration
import java.util.concurrent.atomic.AtomicLong
import javax.crypto.spec.SecretKeySpec
import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlin.math.roundToInt
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.animation.core.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.text.input.TextFieldValue
data class PlayState(val title: String = "Not playing", val artist: String = "", val playing: Boolean = false,
    val pos: Long = 0, val dur: Long = 0, val vol: Int = 0, val max: Int = 1, val art: Bitmap? = null, val at: Long = 0,
    val spd: Float = 1f, val access: Boolean = true,
    /** Ad on the controlled app: 0 none · 1 playing, not skippable yet · 2 "Skip ad" button is on screen. */ val ad: Int = 0,
    /** Host screen brightness 0..1 (-1 unknown) and whether the host may change it. */ val bri: Float = -1f, val briOk: Boolean = true)

class Client {
    var st by mutableStateOf(PlayState())
    private var sock: Socket? = null
    private var out: PrintWriter? = null
    private var key: SecretKeySpec? = null
    private val seq = AtomicLong(0)
    private val ex = Executors.newSingleThreadExecutor()
    fun connect(host: String, pin: String, cb: (Boolean) -> Unit) = ex.execute {
        try {
            val s = Socket(); s.tcpNoDelay = true; s.connect(InetSocketAddress(host, HostService.PORT), 4000); s.soTimeout = 6000; sock = s
            out = PrintWriter(s.getOutputStream(), true)
            val rd = BufferedReader(InputStreamReader(s.getInputStream()))
            key = Crypto.key(pin, Base64.decode(rd.readLine(), Base64.NO_WRAP))
            out!!.println(Crypto.enc(key!!, JSONObject().put("t", "auth").put("n", seq.incrementAndGet()).toString()))
            val r = rd.readLine()
            val ok = r != null && JSONObject(Crypto.dec(key!!, r)).optBoolean("ok")
            if (ok) {
                s.soTimeout = 0
                Thread {
                    try { while (true) { val l = rd.readLine() ?: break
                        val j = JSONObject(Crypto.dec(key!!, l)); when (j.optString("t")) { "state" -> onState(j); "apps" -> onApps(j) } } } catch (_: Exception) {}
                }.start()
            }
            cb(ok)
        } catch (e: Exception) { cb(false) }
    }
    /** Every command first flushes pending typing, so keys such as Enter can never overtake characters typed before them. */
    fun send(t: String, vararg kv: Pair<String, Any>) { flushTyping(); rawSend(t, *kv) }
    private fun rawSend(t: String, vararg kv: Pair<String, Any>) = ex.execute {
        try {
            val j = JSONObject().put("t", t).put("n", seq.incrementAndGet()); kv.forEach { j.put(it.first, it.second) }
            out?.println(Crypto.enc(key!!, j.toString()))
        } catch (_: Exception) {}
    }

    // ---- typing pipeline: edits are merged for 25 ms into ONE "delete N, then insert text" packet ----
    private val tlock = Any()
    private var pDel = 0
    private var pDelUni = false          // the characters being deleted include non-ASCII ones (Bangla etc.)
    private val pTxt = StringBuilder()
    private var tScheduled = false
    private val timer = Executors.newSingleThreadScheduledExecutor()
    private fun scheduleFlush() {
        synchronized(tlock) { if (tScheduled) return; tScheduled = true }
        try { timer.schedule(Runnable { flushTyping() }, 25, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (_: Exception) {}
    }
    private fun flushTyping() {
        synchronized(tlock) {
            tScheduled = false
            val d = pDel; val u = pDelUni; val t = pTxt.toString(); pDel = 0; pDelUni = false; pTxt.setLength(0)
            // "u": the host must delete exactly [c] UTF-16 characters (Accessibility path). A real Backspace key press removes a whole
            // grapheme cluster, which for Bangla conjuncts / vowel signs would delete too much.
            if (d > 0) rawSend("key", "k" to "backspace", "c" to d, "u" to u)
            if (t.isNotEmpty()) rawSend("text", "s" to t)
        }
    }
    fun typeBackspace(n: Int, uni: Boolean = false) {
        if (n <= 0) return
        synchronized(tlock) {
            val k = minOf(n, pTxt.length); pTxt.setLength(pTxt.length - k); pDel += n - k      // deleting what is still unsent costs nothing
            if (uni && n - k > 0) pDelUni = true
        }
        scheduleFlush()
    }
    fun typeText(s: String) { if (s.isEmpty()) return; synchronized(tlock) { pTxt.append(s) }; scheduleFlush() }
    /** Special key (tab, esc, left, right, up, down, home_line, end_line, del, enter ...), [n] times. */
    fun special(k: String, n: Int = 1) { send("key", "k" to k, "c" to n) }
    // Pointer moves are merged: when the network is slower than the touch events the pending deltas are summed into one
    // packet, so the host cursor never lags behind a queue of tiny packets.
    private var mvx = 0f; private var mvy = 0f; private var mvPending = false
    fun move(dx: Float, dy: Float) {
        synchronized(this) { mvx += dx; mvy += dy; if (mvPending) return; mvPending = true }
        ex.execute {
            var a = 0f; var b = 0f
            synchronized(this) { a = mvx; b = mvy; mvx = 0f; mvy = 0f; mvPending = false }
            if (a != 0f || b != 0f) try {
                val j = JSONObject().put("t", "move").put("n", seq.incrementAndGet()).put("dx", a.toDouble()).put("dy", b.toDouble())
                out?.println(Crypto.enc(key!!, j.toString()))
            } catch (_: Exception) {}
        }
    }
    /** Play/pause state shown immediately after a tap, until the host confirms it. */
    var optPlay by mutableStateOf<Boolean?>(null)
    fun togglePlay() { optPlay = !(optPlay ?: st.playing); send("media", "k" to "play_pause") }
    /** Volume the bar shows right after a change, before the host reports back. */
    var volOv by mutableStateOf<Float?>(null)
    fun setVol(f: Float) { volOv = f.coerceIn(0f, 1f); send("volset", "f" to f.coerceIn(0f, 1f)) }
    fun nudgeVol(dir: Int) {
        val m = st.max.coerceAtLeast(1)
        setVol((volOv ?: (st.vol.toFloat() / m)) + dir.toFloat() / m)
    }
    /** Brightness the overlay shows right after a swipe, before the host reports back. */
    var briOv by mutableStateOf<Float?>(null)
    private var lastBriSent = -1
    fun briStart() { lastBriSent = -1 }
    fun setBri(f: Float) {
        val v = f.coerceIn(0f, 1f); briOv = v
        val step = (v * 100).roundToInt()
        if (step != lastBriSent) { lastBriSent = step; send("briset", "f" to v) }     // at most one packet per 1 %
    }
    /** Real keyboard backspace on the host: removes [n] characters in front of the caret (or the selection). */
    fun backspace(n: Int = 1) = typeBackspace(n)
    /** Live typing: sends only what changed between [old] and [new] so the host field mirrors the input box. */
    fun liveDiff(old: String, new: String) {
        var p = 0; val m = minOf(old.length, new.length)
        while (p < m && old[p] == new[p]) p++
        // never cut inside a surrogate pair
        if (p in 1 until m && Character.isHighSurrogate(old[p - 1])) p--
        val gone = old.substring(p)
        typeBackspace(gone.length, gone.any { it.code > 126 })
        typeText(new.substring(p))
    }
    /** Ctrl + [k] on the host (select all, copy, cut, paste, undo, redo ...). */
    fun combo(k: String) { send("combo", "k" to k) }
    /** Playback speed the chip shows right after a choice, until the host reports the real one. */
    var spdOv by mutableStateOf<Float?>(null)
    fun setSpeed(f: Float) { spdOv = f; send("speed", "f" to f) }
    /** Apps installed on the host (for the shortcut editor). */
    var apps by mutableStateOf<List<HostApp>>(emptyList())
    fun requestApps() { send("apps") }
    private fun onApps(j: JSONObject) {
        val a = j.optJSONArray("list") ?: return
        apps = (0 until a.length()).map { a.getJSONObject(it).let { o -> HostApp(o.getString("p"), o.getString("l")) } }
    }
    private fun onState(j: JSONObject) {
        val art = if (j.has("art")) j.optString("art").let { if (it.isEmpty()) null else Base64.decode(it, Base64.NO_WRAP).let { b -> BitmapFactory.decodeByteArray(b, 0, b.size) } } else st.art
        st = PlayState(j.optString("title"), j.optString("artist"), j.optBoolean("playing"), j.optLong("pos"), j.optLong("dur"),
            j.optInt("vol"), j.optInt("max", 1), art, System.currentTimeMillis(), j.optDouble("spd", 1.0).toFloat(), j.optBoolean("access", true), j.optInt("ad", 0),
            j.optDouble("bri", -1.0).toFloat(), j.optBoolean("briok", true))
        if (optPlay != null && optPlay == st.playing) optPlay = null
    }
    fun close() { flushTyping(); try { sock?.close() } catch (_: Exception) {}; timer.shutdown(); ex.shutdown() }
}

// ---------- Theme ----------
object Pal { var dark by mutableStateOf(true) }
lateinit var appPrefs: SharedPreferences
fun setDark(v: Boolean) { Pal.dark = v; appPrefs.edit().putBoolean("dark", v).apply() }
val Bg1 get() = if (Pal.dark) Color(0xFF0A0E1A) else Color(0xFFF4F6FF)
val Bg2 get() = if (Pal.dark) Color(0xFF151B33) else Color(0xFFE6EBFB)
val CardC get() = if (Pal.dark) Color(0xFF1A2140) else Color.White
val Muted get() = if (Pal.dark) Color(0xFF94A3B8) else Color(0xFF64748B)
val Edge get() = if (Pal.dark) Color(0x16FFFFFF) else Color(0x1A0F172A)
val Accent = Color(0xFF7C5CFF); val Accent2 = Color(0xFF22D3EE)
val Good = Color(0xFF34D399); val Bad = Color(0xFFF87171)
val Grad = Brush.linearGradient(listOf(Accent, Accent2))

class MainActivity : ComponentActivity() {
    /** While the remote screen is open the controller's volume buttons drive the host's volume bar. */
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val h = volKeyHandler
        if (h != null && (e.keyCode == KeyEvent.KEYCODE_VOLUME_UP || e.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)) {
            if (e.action == KeyEvent.ACTION_DOWN) h(if (e.keyCode == KeyEvent.KEYCODE_VOLUME_UP) 1 else -1)
            return true
        }
        return super.dispatchKeyEvent(e)
    }
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && immersiveWanted) setImmersive(this, true)
    }
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        // Draw behind the status / navigation bars; every screen pads itself with the safe-drawing insets.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        window.attributes = window.attributes.apply { layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES }
        appPrefs = getSharedPreferences("s", 0)
        AutoGrant.ensure(this)   // no-op unless granted over ADB
        if (appPrefs.getBoolean("auto_native", false) && AutoGrant.canWrite(this)) NativeStarter.start(this)
        Pal.dark = appPrefs.getBoolean("dark", (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES)
        setContent {
            val dark = Pal.dark
            SideEffect {
                WindowCompat.getInsetsController(window, window.decorView).apply { isAppearanceLightStatusBars = !dark; isAppearanceLightNavigationBars = !dark }
            }
            MaterialTheme(colorScheme = if (Pal.dark) darkColorScheme(primary = Accent, background = Bg1, surface = Bg1) else lightColorScheme(primary = Accent, background = Bg1, surface = Bg1)) {
                Surface(Modifier.fillMaxSize(), color = Bg1) { App() }
            }
        }
    }
}

@Composable fun App() {
    var mode by remember { mutableStateOf<String?>(null) }
    var client by remember { mutableStateOf<Client?>(null) }
    val c = client
    when {
        mode == null -> Home { mode = it }
        mode == "guide" -> GuideScreen { mode = null }
        mode == "host" -> HostScreen({ mode = null }, { mode = "guide" })
        c == null -> Connect({ mode = null }) { client = it }
        else -> Remote(c) { c.close(); client = null; mode = null }
    }
}

// ---------- Reusable pieces ----------
@Composable fun Screen(maxW: Dp = 560.dp, content: @Composable ColumnScope.() -> Unit) {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Bg1, Bg2))).safeDrawingPadding(),
        contentAlignment = Alignment.TopCenter) {
        Column(Modifier.widthIn(max = maxW).fillMaxSize(), content = content)
    }
}

@Composable fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxWidth().background(CardC, RoundedCornerShape(20.dp))
        .border(1.dp, Edge, RoundedCornerShape(20.dp)).padding(16.dp), content = content)
}

@Composable fun Label(t: String) = Text(t, fontSize = 11.sp, color = Muted, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)

@Composable fun GradBtn(text: String, modifier: Modifier = Modifier, brush: Brush = Grad, onClick: () -> Unit) {
    val h = LocalHapticFeedback.current
    Box(modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(16.dp)).background(brush)
        .clickable { h.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() },
        contentAlignment = Alignment.Center) {
        Text(text, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
    }
}

@Composable fun RoundBtn(glyph: String, size: Dp, filled: Boolean = false, onClick: () -> Unit) {
    val h = LocalHapticFeedback.current
    Box(Modifier.size(size).clip(CircleShape)
        .then(if (filled) Modifier.background(Grad) else Modifier.background(CardC).border(1.dp, Edge, CircleShape))
        .clickable { h.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() },
        contentAlignment = Alignment.Center) { Text(glyph, fontSize = (size.value * 0.38f).sp, color = if (filled) Color.White else LocalContentColor.current) }
}

@Composable fun Tile(glyph: String, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val h = LocalHapticFeedback.current
    Column(modifier.height(76.dp).clip(RoundedCornerShape(18.dp)).background(CardC)
        .border(1.dp, Edge, RoundedCornerShape(18.dp))
        .clickable { h.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() },
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(glyph, fontSize = 22.sp); Text(label, fontSize = 11.sp, color = Muted)
    }
}

@Composable fun Header(title: String, sub: String, onBack: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(20.dp, 16.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) { RoundBtn("←", 44.dp, onClick = onBack); Spacer(Modifier.width(14.dp)) }
        Column { Text(title, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold); Text(sub, color = Muted, fontSize = 13.sp) }
    }
}

@Composable fun tfColors() = OutlinedTextFieldDefaults.colors(focusedBorderColor = Accent2,
    unfocusedBorderColor = Color(0x33FFFFFF), cursorColor = Accent2, focusedLabelColor = Accent2, unfocusedLabelColor = Muted)

fun localIps(): String = NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }
    .filter { it is Inet4Address && !it.isLoopbackAddress }.joinToString { it.hostAddress ?: "" }.ifEmpty { "not on Wi-Fi" }

// ---------- Home ----------
@Composable fun ModeCard(icon: String, title: String, desc: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(CardC)
        .border(1.dp, Edge, RoundedCornerShape(24.dp)).clickable(onClick = onClick).padding(20.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(60.dp).clip(RoundedCornerShape(18.dp)).background(Grad), contentAlignment = Alignment.Center) {
            Text(icon, fontSize = 28.sp) }
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) { Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text(desc, color = Muted, fontSize = 13.sp) }
        Text("›", fontSize = 30.sp, color = Muted)
    }
}

@Composable fun Home(pick: (String) -> Unit) = Screen { Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
    Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.End) {
        RoundBtn(if (Pal.dark) "☀" else "🌙", 44.dp) { setDark(!Pal.dark) }
    }
    Spacer(Modifier.height(12.dp))
    Column(Modifier.padding(horizontal = 24.dp)) {
        Box(Modifier.size(68.dp).clip(RoundedCornerShape(22.dp)).background(Grad), contentAlignment = Alignment.Center) {
            Text("📡", fontSize = 32.sp) }
        Spacer(Modifier.height(18.dp))
        Text("LAN Remote", fontSize = 36.sp, fontWeight = FontWeight.ExtraBold)
        Text("Media, mouse and keyboard control\nover your Wi-Fi.", color = Muted, fontSize = 15.sp)
    }
    Spacer(Modifier.height(36.dp))
    Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        ModeCard("🎮", "Controller", "Use this device as the remote") { pick("controller") }
        ModeCard("📺", "Host", "Let another device control this one") { pick("host") }
        ModeCard("🛠", "Setup guide", "Grant permissions with Wireless debugging") { pick("guide") }
    }
    Spacer(Modifier.height(28.dp))
    Text("Both devices must be on the same network", color = Muted, fontSize = 12.sp,
        modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 24.dp))
} }

// ---------- Host ----------
@Composable fun HostScreen(onBack: () -> Unit, onGuide: () -> Unit = {}) = Screen {
    val ctx = LocalContext.current
    var pin by remember { mutableStateOf(HostService.pin) }
    var on by remember { mutableStateOf(HostService.running) }
    var acc by remember { mutableStateOf(false) }
    var nlOn by remember { mutableStateOf(false) }
    var auto by remember { mutableStateOf(false) }
    var native by remember { mutableStateOf(false) }
    var wr by remember { mutableStateOf(false) }
    var nver by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) { while (true) { acc = RemoteAccess.instance != null; auto = AutoGrant.canWrite(ctx); native = NativeInput.connected; wr = Settings.System.canWrite(ctx); nver = NativeInput.ver
        nlOn = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners")?.contains(ctx.packageName) == true; delay(1000) } }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    var autoNative by remember { mutableStateOf(appPrefs.getBoolean("auto_native", false)) }
    var nstat by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { while (true) { nstat = NativeStarter.status; delay(700) } }
    val termuxPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) NativeStarter.start(ctx) }
    fun startNative() { if (!NativeStarter.termuxInstalled(ctx)) NativeStarter.status = "Termux is not installed on this device"
        else if (!NativeStarter.termuxAllowed(ctx)) termuxPerm.launch(NativeStarter.TERMUX_PERM) else NativeStarter.start(ctx) }
    val pulse by rememberInfiniteTransition(label = "p").animateFloat(0.3f, 1f,
        infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "a")
    Header("Host", "🔒 Encrypted · this device will be controlled", onBack)
    Column(Modifier.padding(horizontal = 20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(12.dp).clip(CircleShape).background((if (on) Good else Muted).copy(alpha = if (on) pulse else 1f)))
                Spacer(Modifier.width(10.dp))
                Text(if (on) "Host is running" else "Host is stopped", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
            Spacer(Modifier.height(14.dp)); Label("YOUR IP ADDRESS")
            Text(localIps(), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Accent2)
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(pin, { pin = it.filter(Char::isLetterOrDigit).take(16) }, Modifier.fillMaxWidth(),
                label = { Text("Pairing code") }, supportingText = { Text("6–16 letters or digits. Enter the same code on the controller.") }, singleLine = true, shape = RoundedCornerShape(14.dp), colors = tfColors())
        }
        val ip = hostIp()
        if (ip.contains('.')) Panel {
            Label("SCAN TO CONNECT"); Spacer(Modifier.height(10.dp))
            val qr = remember(pin, ip) { qrBitmap("LANREMOTE|$ip|$pin") }
            Image(qr.asImageBitmap(), "QR code", Modifier.size(200.dp).clip(RoundedCornerShape(12.dp)).align(Alignment.CenterHorizontally))
            Text("Open the Controller on the other device and tap Scan QR. The code contains your pairing code, so only show it to people you trust.",
                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
        }
        GradBtn(if (on) "Stop host" else "Start host",
            brush = if (on) Brush.linearGradient(listOf(Color(0xFFEF4444), Color(0xFFF97316))) else Grad) {
            if (!on && pin.length < 6) return@GradBtn
            if (Build.VERSION.SDK_INT >= 33) perm.launch(Manifest.permission.POST_NOTIFICATIONS)
            val i = Intent(ctx, HostService::class.java).putExtra("pin", pin)
            if (on) ctx.stopService(i) else ctx.startForegroundService(i)
            on = !on
        }
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(12.dp).clip(CircleShape).background(if (acc) Good else Bad))
                Spacer(Modifier.width(10.dp))
                Text(if (acc) "Mouse & keyboard: enabled" else "Mouse & keyboard: off", fontWeight = FontWeight.Bold)
            }
            Text("Media and volume work without this. Enable the Accessibility service to allow cursor, taps, scrolling and typing.",
                color = Muted, fontSize = 13.sp, modifier = Modifier.padding(vertical = 10.dp))
            GradBtn("Open Accessibility settings", brush = Brush.linearGradient(listOf(Color(0xFF334155), Color(0xFF475569)))) {
                ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(12.dp).clip(CircleShape).background(if (nlOn) Good else Bad))
                Spacer(Modifier.width(10.dp))
                Text(if (nlOn) "Now-playing info: enabled" else "Now-playing info: off", fontWeight = FontWeight.Bold)
            }
            Text("Lets the controller show the title, artwork and time bar, and seek.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(vertical = 10.dp))
            GradBtn("Open notification access", brush = Brush.linearGradient(listOf(Color(0xFF334155), Color(0xFF475569)))) {
                ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        }
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(12.dp).clip(CircleShape).background(if (native) Good else Bad))
                Spacer(Modifier.width(10.dp))
                Text(if (native) "Native mouse & keyboard: active" else "Native mouse & keyboard: not running", fontWeight = FontWeight.Bold)
            }
            Text("Real system mouse pointer and keyboard input, like a physical mouse/keyboard is plugged in. Start it from a PC with adb_setup " +
                "(re-run after a reboot). Until then the Accessibility fallback is used.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 10.dp)) {
                Text("Start automatically", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                Switch(autoNative, { v -> autoNative = v; appPrefs.edit().putBoolean("auto_native", v).apply(); if (v && !native) startNative() })
            }
            Text("Uses permanent access + Termux on this device (paired once, allow-external-apps=true in Termux). Retries after reboots while the host runs.",
                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
            GradBtn("Start native server now", brush = Brush.linearGradient(listOf(Color(0xFF334155), Color(0xFF475569)))) { startNative() }
            if (nstat.isNotEmpty()) Text(nstat, color = Accent2, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
        }
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(12.dp).clip(CircleShape).background(if (auto) Good else Bad))
                Spacer(Modifier.width(10.dp))
                Text(if (auto) "Permanent access: active" else "Permanent access: needs one ADB command", fontWeight = FontWeight.Bold)
            }
            Text("Connect this device to a PC with USB debugging on and run adb_setup.bat (Windows) or adb_setup.sh (Mac/Linux) from the project folder. " +
                "Or run this single command once:", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(vertical = 10.dp))
            SelectionContainer { Text("adb shell pm grant com.example.lanremote android.permission.WRITE_SECURE_SETTINGS", color = Accent2, fontSize = 12.sp) }
            Text("After that the app turns on and keeps Accessibility (mouse/keyboard) and notification access (media info) by itself, even after a reboot.",
                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 10.dp))
            GradBtn("Open step-by-step setup guide") { onGuide() }
            Spacer(Modifier.height(10.dp))
            if (auto) GradBtn("Re-apply now", brush = Brush.linearGradient(listOf(Color(0xFF334155), Color(0xFF475569)))) { AutoGrant.ensure(ctx, true) }
        }
        Spacer(Modifier.height(12.dp))
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(12.dp).clip(CircleShape).background(if (wr || (native && nver >= 2)) Good else Bad))
                Spacer(Modifier.width(10.dp))
                Text(if (wr || (native && nver >= 2)) "Brightness control: allowed" else "Brightness control: not allowed", fontWeight = FontWeight.Bold)
            }
            Text("Lets the controller change this device's screen brightness (swipe up/down on the left half of the full-screen media view). " +
                (if (native && nver < 2) "The running native server is OUTDATED - restart it (re-run adb_setup) or tap the button below. " else "") +
                "Not needed when the current native server runs. Or run: adb shell appops set com.example.lanremote WRITE_SETTINGS allow",
                color = Muted, fontSize = 13.sp, modifier = Modifier.padding(vertical = 10.dp))
            if (!wr) GradBtn("Allow brightness control") {
                try { ctx.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, android.net.Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
            }
        }
        Panel {
            var autoSkip by remember { mutableStateOf(appPrefs.getBoolean("auto_skip", true)) }
            var hideKb by remember { mutableStateOf(appPrefs.getBoolean("hide_kb", true)) }
            Label("HOST BEHAVIOUR")
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 10.dp)) {
                Text("Skip ads automatically", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                Switch(autoSkip, { v -> autoSkip = v; appPrefs.edit().putBoolean("auto_skip", v).apply() })
            }
            Text("Presses \"Skip ad\" by itself in YouTube, streaming / music apps and browsers as soon as the button appears. Needs the Accessibility service.",
                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 6.dp)) {
                Text("Keep on-screen keyboard hidden", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                Switch(hideKb, { v -> hideKb = v; appPrefs.edit().putBoolean("hide_kb", v).apply() })
            }
            Text("Stops this device's keyboard from popping up while the controller types or clicks into a text field. Turn it off if you want to type on this device.",
                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
        }
        Spacer(Modifier.height(16.dp))
    }
}

// ---------- Connect ----------
@Composable fun Connect(onBack: () -> Unit, onConnected: (Client) -> Unit) = Screen {
    val ctx = LocalContext.current
    val found = remember { mutableStateListOf<Pair<String, String>>() }
    var ip by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    DisposableEffect(Unit) {
        val nsd = ctx.getSystemService(NsdManager::class.java)
        val l = object : NsdManager.DiscoveryListener {
            override fun onServiceFound(s: NsdServiceInfo) {
                nsd.resolveService(s, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(s: NsdServiceInfo, e: Int) {}
                    override fun onServiceResolved(r: NsdServiceInfo) {
                        val h = r.host?.hostAddress ?: return
                        if (found.none { it.second == h }) found.add(r.serviceName to h)
                    }
                })
            }
            override fun onServiceLost(s: NsdServiceInfo) {}
            override fun onDiscoveryStarted(t: String) {}
            override fun onDiscoveryStopped(t: String) {}
            override fun onStartDiscoveryFailed(t: String, e: Int) {}
            override fun onStopDiscoveryFailed(t: String, e: Int) {}
        }
        nsd.discoverServices("_lanremote._tcp.", NsdManager.PROTOCOL_DNS_SD, l)
        onDispose { try { nsd.stopServiceDiscovery(l) } catch (_: Exception) {} }
    }
    fun go(h: String) {
        busy = true; msg = ""
        val c = Client()
        c.connect(h, pin) { ok -> busy = false; if (ok) onConnected(c) else msg = "Couldn't connect. Check the IP, PIN and that the host is started." }
    }
    val scan = rememberLauncherForActivityResult(ScanContract()) { r ->
        r.contents?.split("|")?.let { p -> if (p.size == 3 && p[0] == "LANREMOTE") { pin = p[2]; go(p[1]) } }
    }
    Header("Controller", "🔒 Encrypted · pick a host to control", onBack)
    Column(Modifier.padding(horizontal = 20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        GradBtn("📷  Scan QR code") { scan.launch(ScanOptions().setBeepEnabled(false).setPrompt("Scan the QR shown on the host").setOrientationLocked(false)) }
        Panel {
            OutlinedTextField(pin, { pin = it.filter(Char::isLetterOrDigit).take(16) }, Modifier.fillMaxWidth(),
                label = { Text("Pairing code") }, singleLine = true, shape = RoundedCornerShape(14.dp), colors = tfColors())
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Label("NEARBY HOSTS"); Spacer(Modifier.width(10.dp))
            if (found.isEmpty()) CircularProgressIndicator(Modifier.size(14.dp), color = Accent2, strokeWidth = 2.dp)
        }
        if (found.isEmpty()) Text("Searching your network…", color = Muted, fontSize = 13.sp)
        found.forEach { (n, h) ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(CardC).border(1.dp, Edge, RoundedCornerShape(18.dp))
                .clickable { go(h) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("📺", fontSize = 26.sp); Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) { Text(n, fontWeight = FontWeight.Bold); Text(h, color = Accent2, fontSize = 13.sp) }
                Text("Connect ›", color = Muted)
            }
        }
        Label("OR ENTER IP MANUALLY")
        OutlinedTextField(ip, { ip = it }, Modifier.fillMaxWidth(), label = { Text("e.g. 192.168.1.20") },
            singleLine = true, shape = RoundedCornerShape(14.dp), colors = tfColors())
        GradBtn(if (busy) "Connecting…" else "Connect") { if (!busy && ip.isNotBlank()) go(ip.trim()) }
        if (msg.isNotEmpty()) Text(msg, color = Bad, fontSize = 13.sp)
        Spacer(Modifier.height(16.dp))
    }
}

// ---------- Remote (controller home screen) ----------
/** Hardware volume buttons of the controller are routed here while the remote screen is open. */
var volKeyHandler: ((Int) -> Unit)? = null

tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

/** True while the remote screen is open: system bars stay hidden (swipe from an edge to peek at them). */
var immersiveWanted = false
fun setImmersive(a: Activity, on: Boolean) {
    val ic = WindowCompat.getInsetsController(a.window, a.window.decorView)
    if (on) { ic.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE; ic.hide(WindowInsetsCompat.Type.systemBars()) }
    else ic.show(WindowInsetsCompat.Type.systemBars())
}

@Composable fun Remote(c: Client, onExit: () -> Unit) {
    var fold by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    val toggleFull: () -> Unit = { c.send("fs"); fold = !fold }
    DisposableEffect(c) { volKeyHandler = { c.nudgeVol(it) }; onDispose { volKeyHandler = null } }
    // The remote is always full screen: status + navigation bars hidden, screen kept awake.
    DisposableEffect(Unit) {
        val act = ctx.findActivity()
        immersiveWanted = true
        if (act != null) { setImmersive(act, true); act.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
        onDispose {
            immersiveWanted = false
            act?.let { it.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED; setImmersive(it, false)
                it.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
        }
    }
    // Media full screen additionally forces landscape.
    DisposableEffect(fold) {
        ctx.findActivity()?.requestedOrientation = if (fold) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        onDispose {}
    }
    // Volume overlay disappears 1.5 s after the last change; optimistic play state is dropped if the host never confirms.
    LaunchedEffect(c.volOv) { if (c.volOv != null) { delay(1500); c.volOv = null } }
    LaunchedEffect(c.briOv) { if (c.briOv != null) { delay(1500); c.briOv = null } }
    LaunchedEffect(c.optPlay) { if (c.optPlay != null) { delay(1500); c.optPlay = null } }
    LaunchedEffect(c.spdOv) { if (c.spdOv != null) { delay(2500); c.spdOv = null } }
    // Left drawer with the user's shortcuts. Opened by the "Shortcuts" button or by swiping in from the left edge.
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val drawerScope = rememberCoroutineScope()
    remember { ShortcutStore.load(appPrefs) }
    ModalNavigationDrawer(
        drawerContent = { ShortcutDrawer(c) { drawerScope.launch { drawerState.close() } } },
        drawerState = drawerState,
        gesturesEnabled = drawerState.isOpen            // closed: opened only via button / edge strip, so touchpad drags never trigger it
    ) {
        Box(Modifier.fillMaxSize()) {
            if (fold) FullMedia(c, toggleFull)
            else BoxWithConstraints(Modifier.fillMaxSize()) {
                // landscape phones, tablets and unfolded foldables get the two-pane layout
                val wide = maxWidth > maxHeight || maxWidth >= 840.dp
                val compact = wide && maxHeight < 480.dp           // landscape phone
                val availH = maxHeight
                Screen(if (wide) 1600.dp else 640.dp) {
                    HomeController(c, onExit, toggleFull, wide, compact, availH) { drawerScope.launch { drawerState.open() } }
                }
            }
            // edge strip: width and distance needed come from Settings → "Edge-swipe sensitivity"
            Box(Modifier.align(Alignment.CenterStart).fillMaxHeight().width((10 + 30 * Cfg.edgeSens).dp).pointerInput(Unit) {
                var acc = 0f
                detectHorizontalDragGestures(onDragStart = { acc = 0f }, onHorizontalDrag = { ch, dx ->
                    ch.consume(); acc += dx
                    if (acc > 44f - 32f * Cfg.edgeSens) { acc = -1e9f; drawerScope.launch { drawerState.open() } }
                })
            })
        }
    }
}

fun fmt(ms: Long): String {
    val s = ms / 1000; val h = s / 3600; val m = (s % 3600) / 60; val x = s % 60
    return "%02d:%02d:%02d".format(h, m, x)
}

// ----- icons (drawn, so they look the same on every device) -----
@Composable fun FullIcon(expand: Boolean, onClick: () -> Unit) {
    val col = LocalContentColor.current
    Box(Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onClick), Alignment.Center) {
        Canvas(Modifier.size(18.dp)) {
            val w = size.width; val k = w * 0.38f; val sw = 2.2.dp.toPx()
            fun l(x1: Float, y1: Float, x2: Float, y2: Float) = drawLine(col, Offset(x1, y1), Offset(x2, y2), sw, StrokeCap.Round)
            if (expand) {
                l(0f, 0f, k, 0f); l(0f, 0f, 0f, k); l(w, 0f, w - k, 0f); l(w, 0f, w, k)
                l(0f, w, k, w); l(0f, w, 0f, w - k); l(w, w, w - k, w); l(w, w, w, w - k)
            } else {
                l(k, 0f, k, k); l(0f, k, k, k); l(w - k, 0f, w - k, k); l(w, k, w - k, k)
                l(k, w, k, w - k); l(0f, w - k, k, w - k); l(w - k, w, w - k, w - k); l(w, w - k, w - k, w - k)
            }
        }
    }
}

/** Circular "skip 10 s" arrow. forward = clockwise (↻), otherwise counter-clockwise (↺). */
@Composable fun SkipIcon(forward: Boolean, size: Dp) {
    val col = LocalContentColor.current
    Box(Modifier.size(size), Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = this.size.width * 0.075f
            val pad = sw * 2f
            val r = (this.size.width - pad * 2) / 2f
            val c = center
            val startA = -50f; val sweep = 280f
            val flip = if (forward) 1f else -1f
            scale(flip, 1f, pivot = c) {
                drawArc(col, startA, sweep, false, Offset(pad, pad), Size(r * 2, r * 2), style = Stroke(sw, cap = StrokeCap.Round))
                val a = Math.toRadians((startA + sweep).toDouble())
                val px = c.x + r * cos(a).toFloat(); val py = c.y + r * sin(a).toFloat()
                val tx = -sin(a).toFloat(); val ty = cos(a).toFloat()      // clockwise tangent
                val nx = cos(a).toFloat(); val ny = sin(a).toFloat()       // outward normal
                val hl = sw * 3.2f; val hw = sw * 2.2f
                val head = Path().apply {
                    moveTo(px + tx * hl, py + ty * hl)
                    lineTo(px + nx * hw, py + ny * hw)
                    lineTo(px - nx * hw, py - ny * hw); close()
                }
                drawPath(head, col)
            }
        }
        Text("10", fontSize = (size.value * 0.30f).sp, fontWeight = FontWeight.Bold)
    }
}

@Composable fun PlayPauseIcon(playing: Boolean, size: Dp, tint: Color) {
    Canvas(Modifier.size(size)) {
        val w = this.size.width; val h = this.size.height
        if (playing) {
            val bw = w * 0.26f
            drawRoundRect(tint, Offset(w * 0.18f, h * 0.12f), Size(bw, h * 0.76f), CornerRadius(bw / 3))
            drawRoundRect(tint, Offset(w * 0.82f - bw, h * 0.12f), Size(bw, h * 0.76f), CornerRadius(bw / 3))
        } else {
            drawPath(Path().apply { moveTo(w * 0.22f, h * 0.10f); lineTo(w * 0.90f, h * 0.5f); lineTo(w * 0.22f, h * 0.90f); close() }, tint)
        }
    }
}

@Composable fun NavIcon(kind: Int, size: Dp = 22.dp) {
    val col = LocalContentColor.current
    Canvas(Modifier.size(size)) {
        val w = this.size.width; val sw = 2.2.dp.toPx()
        fun l(x1: Float, y1: Float, x2: Float, y2: Float) = drawLine(col, Offset(x1 * w, y1 * w), Offset(x2 * w, y2 * w), sw, StrokeCap.Round)
        when (kind) {
            0 -> { l(.12f, .5f, .88f, .5f); l(.12f, .5f, .42f, .2f); l(.12f, .5f, .42f, .8f) }          // back
            1 -> drawPath(Path().apply {                                                                    // home
                moveTo(.5f * w, .12f * w); lineTo(.1f * w, .48f * w); lineTo(.2f * w, .48f * w); lineTo(.2f * w, .86f * w)
                lineTo(.8f * w, .86f * w); lineTo(.8f * w, .48f * w); lineTo(.9f * w, .48f * w); close()
            }, col, style = Stroke(sw, join = StrokeJoin.Round))
            2 -> { l(.15f, .25f, .85f, .25f); l(.15f, .5f, .85f, .5f); l(.15f, .75f, .85f, .75f) }       // menu / recents
            else -> for (i in 0..2) for (j in 0..2) drawCircle(col, sw * 0.8f, Offset((.2f + .3f * i) * w, (.2f + .3f * j) * w)) // app drawer
        }
    }
}

@Composable fun PadBtn(modifier: Modifier = Modifier, onClick: () -> Unit, content: @Composable BoxScope.() -> Unit) {
    val h = LocalHapticFeedback.current
    Box(modifier.clip(RoundedCornerShape(14.dp)).background(CardC).border(1.dp, Edge, RoundedCornerShape(14.dp))
        .clickable { h.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() },
        contentAlignment = Alignment.Center, content = content)
}

// ----- media pieces -----
@Composable fun Seek(c: Client, onArt: Boolean = false) {
    val st = c.st
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(100) } }
    var drag by remember { mutableStateOf<Float?>(null) }
    var release by remember { mutableIntStateOf(0) }
    LaunchedEffect(release) { if (release > 0) { delay(800); drag = null } }
    val playing = c.optPlay ?: st.playing
    val pos = if (playing) minOf(st.pos + ((now - st.at) * st.spd).toLong(), if (st.dur > 0) st.dur else Long.MAX_VALUE) else st.pos
    val frac = if (st.dur > 0) (pos.toFloat() / st.dur).coerceIn(0f, 1f) else 0f
    val lab = if (onArt) Color(0xCCFFFFFF) else Muted
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(fmt(if (drag != null) (drag!! * st.dur).toLong() else pos), fontSize = 12.sp, color = lab)
            Text(fmt(st.dur), fontSize = 12.sp, color = lab)
        }
        Slider(drag ?: frac, { drag = it }, Modifier.fillMaxWidth().height(28.dp), enabled = st.dur > 0,
            onValueChangeFinished = { drag?.let { c.send("seek", "ms" to (it * st.dur).toLong()) }; release++ },
            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Accent2,
                inactiveTrackColor = if (onArt) Color(0x55FFFFFF) else Color.Unspecified))
    }
}

/** Round, border-less translucent button used on top of the cover art. */
@Composable fun GlassBtn(modifier: Modifier, onClick: () -> Unit, content: @Composable BoxScope.() -> Unit) {
    val h = LocalHapticFeedback.current
    Box(modifier.clip(CircleShape).background(Color(0x2EFFFFFF)).clickable { h.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() },
        Alignment.Center, content = content)
}

@Composable fun SkipTile(c: Client, forward: Boolean, size: Dp, glass: Boolean = false) {
    val go = { c.send("skip", "ms" to (if (forward) 10000L else -10000L)) }
    val icon: @Composable BoxScope.() -> Unit = { SkipIcon(forward, size * 0.62f) }
    if (glass) GlassBtn(Modifier.size(size), go, icon) else PadBtn(Modifier.size(size), go, icon)
}

/** Previous / next track glyph: |◀ and ▶| */
@Composable fun TrackIcon(next: Boolean, size: Dp) {
    val col = LocalContentColor.current
    Canvas(Modifier.size(size)) {
        val w = this.size.width; val h = this.size.height; val bar = w * 0.16f
        if (next) {
            drawPath(Path().apply { moveTo(0f, 0f); lineTo(w * 0.78f, h / 2f); lineTo(0f, h); close() }, col)
            drawRoundRect(col, Offset(w - bar, 0f), Size(bar, h), CornerRadius(bar / 2f))
        } else {
            drawPath(Path().apply { moveTo(w, 0f); lineTo(w * 0.22f, h / 2f); lineTo(w, h); close() }, col)
            drawRoundRect(col, Offset(0f, 0f), Size(bar, h), CornerRadius(bar / 2f))
        }
    }
}

@Composable fun TrackBtn(c: Client, next: Boolean, size: Dp, glass: Boolean = false) {
    val go = { c.send("media", "k" to (if (next) "next" else "prev")) }
    val icon: @Composable BoxScope.() -> Unit = { TrackIcon(next, size * 0.42f) }
    if (glass) GlassBtn(Modifier.size(size), go, icon) else PadBtn(Modifier.size(size), go, icon)
}

@Composable fun PlayCircle(c: Client, size: Dp) {
    val h = LocalHapticFeedback.current
    Box(Modifier.size(size).clip(CircleShape).background(Grad)
        .clickable { h.performHapticFeedback(HapticFeedbackType.TextHandleMove); c.togglePlay() },
        contentAlignment = Alignment.Center) { PlayPauseIcon(c.optPlay ?: c.st.playing, size * 0.46f, Color.White) }
}

/** previous track · back 10 s · play/pause · forward 10 s · next track */
@Composable fun TransportRow(c: Client, tile: Dp, glass: Boolean = false, modifier: Modifier = Modifier) {
    val side = tile * 0.82f
    Row(modifier.fillMaxWidth(), Arrangement.SpaceEvenly, Alignment.CenterVertically) {
        TrackBtn(c, false, side, glass); SkipTile(c, false, tile, glass); PlayCircle(c, tile + 8.dp)
        SkipTile(c, true, tile, glass); TrackBtn(c, true, side, glass)
    }
}

@Composable fun VolumeBar(c: Client, onArt: Boolean = false) {
    val st = c.st
    val frac = c.volOv ?: if (st.max > 0) st.vol.toFloat() / st.max else 0f
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("🔈", fontSize = 16.sp)
        Slider(frac, { c.setVol(it) }, Modifier.weight(1f).padding(horizontal = 8.dp).height(28.dp),
            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Accent,
                inactiveTrackColor = if (onArt) Color(0x55FFFFFF) else Color.Unspecified))
        Text("🔊", fontSize = 16.sp)
    }
}

/** Vertical level indicator shown while swiping for brightness / volume. */
@Composable fun LevelPill(glyph: String, f: Float, note: String?, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(20.dp)).background(Color(0x99000000)).padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text(glyph, fontSize = 18.sp, color = Color.White)
        Spacer(Modifier.height(6.dp))
        Box(Modifier.width(6.dp).height(110.dp).clip(CircleShape).background(Color(0x44FFFFFF)), contentAlignment = Alignment.BottomCenter) {
            Box(Modifier.fillMaxWidth().fillMaxHeight(f.coerceIn(0f, 1f)).background(Color.White))
        }
        Spacer(Modifier.height(6.dp))
        Text("${(f * 100).roundToInt()}%", fontSize = 12.sp, color = Color.White)
        if (note != null) Text(note, fontSize = 10.sp, color = Color(0xFFFFB4B4))
    }
}

/** Keyboard key: a tap fires once, HOLD keeps firing (slow, then faster, then fast). [onFire] gets the repeat count. */
@Composable fun RepeatKey(modifier: Modifier, label: String, size: Int = 14, onFire: (Int) -> Unit) {
    val h = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val fire by rememberUpdatedState(onFire)
    Box(modifier.clip(RoundedCornerShape(12.dp)).background(CardC).border(1.dp, Edge, RoundedCornerShape(12.dp))
        .pointerInput(Unit) {
            detectTapGestures(onPress = {
                h.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                fire(1)
                val job = scope.launch {
                    delay(380)
                    var n = 0
                    while (true) { fire(if (n < 12) 1 else if (n < 30) 2 else 4); n++; delay(45) }
                }
                try { tryAwaitRelease() } finally { job.cancel() }
            })
        }, contentAlignment = Alignment.Center) { Text(label, fontSize = size.sp, fontWeight = FontWeight.Medium) }
}

@Composable fun BackspaceBtn(modifier: Modifier, onDelete: (Int) -> Unit) = RepeatKey(modifier, "⌫", 18, onDelete)

/** Toggles full screen of the VIDEO on the controlled device (YouTube & other apps, web players in browsers). */
@Composable fun VideoFsBtn(c: Client) {
    val h = LocalHapticFeedback.current
    Row(Modifier.padding(end = 6.dp).height(30.dp).clip(RoundedCornerShape(50)).background(Accent2.copy(alpha = 0.22f))
        .clickable { h.performHapticFeedback(HapticFeedbackType.TextHandleMove); c.send("vfs") }.padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text("⛶", fontSize = 14.sp); Spacer(Modifier.width(4.dp)); Text("Video", fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

/** Appears while an ad runs on the controlled app. Tapping "Skip ad" presses the skip button on the host. */
@Composable fun AdBar(c: Client, compact: Boolean) {
    val ad = c.st.ad
    if (ad == 0) return
    val h = LocalHapticFeedback.current
    val ready = ad == 2
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), Arrangement.Center) {
        Row(Modifier.height(if (compact) 32.dp else 38.dp).clip(RoundedCornerShape(50))
            .background(if (ready) Grad else Brush.linearGradient(listOf(Color(0x33FFFFFF), Color(0x33FFFFFF))))
            .clickable(enabled = ready) { h.performHapticFeedback(HapticFeedbackType.TextHandleMove); c.send("skipad") }
            .padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            CompositionLocalProvider(LocalContentColor provides Color.White) {
                Text(if (ready) "Skip ad" else "Ad playing…", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                if (ready) { Spacer(Modifier.width(8.dp)); TrackIcon(true, 12.dp) }
            }
        }
    }
}

/** Media panel whose background is the thumbnail / cover art of whatever is playing on the host. */
@Composable fun MediaCard(c: Client, shape: RoundedCornerShape, modifier: Modifier, pad: PaddingValues,
                          arr: Arrangement.Vertical = Arrangement.Top, fillHeight: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    val art = c.st.art
    Box(modifier.clip(shape).background(CardC).border(1.dp, Edge, shape)) {
        if (art != null) {
            Image(art.asImageBitmap(), null, Modifier.matchParentSize().then(if (Cfg.bgBlur >= 0.5f) Modifier.blur(Cfg.bgBlur.dp) else Modifier),
                contentScale = ContentScale.Crop, alpha = Cfg.bgAlpha)
            Box(Modifier.matchParentSize().background(Color(0x99000000)))   // dark scrim keeps controls readable
        }
        CompositionLocalProvider(LocalContentColor provides (if (art != null) Color.White else LocalContentColor.current)) {
            Column(Modifier.fillMaxWidth().then(if (fillHeight) Modifier.fillMaxHeight() else Modifier).padding(pad),
                verticalArrangement = arr, content = content)
        }
    }
}

/**
 * Full-screen media controls (landscape). The cover art fills the whole screen (blurred, edge to edge, no frame);
 * the controls float on top of it. The volume bar follows the controller's hardware volume buttons.
 */
@Composable fun FullMedia(c: Client, onExit: () -> Unit) {
    val st = c.st
    val art = st.art
    var skipFx by remember { mutableIntStateOf(0) }        // -1 / +1 = side of the last double-tap skip
    var skipStamp by remember { mutableIntStateOf(0) }
    LaunchedEffect(skipStamp) { if (skipStamp > 0) { delay(700); skipFx = 0 } }
    Box(Modifier.fillMaxSize().background(Color.Black).clipToBounds()) {
        if (art != null) {
            // scaled up a little so the blurred edges are never visible
            Image(art.asImageBitmap(), null, Modifier.fillMaxSize().graphicsLayer { scaleX = 1.15f; scaleY = 1.15f }
                .then(if (Cfg.bgBlur >= 0.5f) Modifier.blur(Cfg.bgBlur.dp) else Modifier),
                contentScale = ContentScale.Crop, alpha = Cfg.bgAlpha)
        } else Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0A0E1A), Color(0xFF1A2140)))))
        // soft gradient (no hard box) keeps text and controls readable
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x80000000), Color(0x26000000), Color(0xB0000000)))))
        // Swipe layer (behind the controls): drag up/down on the LEFT half = host brightness, on the RIGHT half = host volume.
        // Double-tap on the LEFT half = back 10 s, on the RIGHT half = forward 10 s.
        Box(Modifier.fillMaxSize().pointerInput(c) {
            detectTapGestures(onDoubleTap = { o ->
                val fwd = o.x >= size.width / 2f
                c.send("skip", "ms" to (if (fwd) 10000L else -10000L))
                skipFx = if (fwd) 1 else -1; skipStamp++
            })
        }.pointerInput(c) {
            var side = 0; var startF = 0f; var acc = 0f
            detectVerticalDragGestures(
                onDragStart = { o ->
                    side = if (o.x < size.width / 2f) 0 else 1; acc = 0f
                    if (side == 0) c.briStart()
                    startF = if (side == 0) (c.briOv ?: c.st.bri.takeIf { it >= 0f } ?: 0.5f)
                             else (c.volOv ?: (c.st.vol.toFloat() / c.st.max.coerceAtLeast(1)))
                },
                onVerticalDrag = { ch, dy ->
                    ch.consume(); acc += -dy
                    val f = (startF + acc / (size.height * 0.75f)).coerceIn(0f, 1f)
                    if (side == 0) c.setBri(f) else c.setVol(f)
                })
        })
        CompositionLocalProvider(LocalContentColor provides Color.White) {
            BoxWithConstraints(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.displayCutout).padding(horizontal = 28.dp, vertical = 12.dp)) {
                val tile = (maxHeight * 0.24f).coerceIn(44.dp, 100.dp)
                Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                        Column(Modifier.weight(1f).padding(top = 6.dp)) {
                            Text(if (!st.access) "Host needs notification access" else st.title, fontSize = 16.sp, fontWeight = FontWeight.Bold,
                                maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color.White)
                            if (st.artist.isNotBlank()) Text(st.artist, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color(0xCCFFFFFF))
                        }
                        SpeedChip(c)
                        VideoFsBtn(c)
                        FullIcon(false, onExit)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        TransportRow(c, tile, glass = true)
                        AdBar(c, false)
                    }
                    Column {
                        Seek(c, true)
                        Spacer(Modifier.height(4.dp))
                        VolumeBar(c, true)
                    }
                }
            }
        }
        c.briOv?.let { LevelPill("☀", it, if (st.briOk) null else "Host: allow brightness (Host screen)", Modifier.align(Alignment.CenterStart).padding(start = 48.dp)) }
        c.volOv?.let { LevelPill("🔊", it, null, Modifier.align(Alignment.CenterEnd).padding(end = 48.dp)) }
        if (skipFx != 0) Text(if (skipFx > 0) "10 s ⏩" else "⏪ 10 s", Modifier.align(if (skipFx > 0) Alignment.CenterEnd else Alignment.CenterStart)
            .padding(horizontal = 56.dp).clip(RoundedCornerShape(50)).background(Color(0x99000000)).padding(horizontal = 16.dp, vertical = 10.dp),
            color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}

fun spdLabel(f: Float) = "${(f * 100).roundToInt() / 100.0}×"

/** Playback speed of the media on the host (asks the active media session; apps that ignore it simply stay at their speed). */
@Composable fun SpeedChip(c: Client) {
    val cur = c.spdOv ?: c.st.spd
    var open by remember { mutableStateOf(false) }
    Box(Modifier.padding(end = 6.dp)) {
        Row(Modifier.height(30.dp).clip(RoundedCornerShape(50)).background(Accent2.copy(alpha = 0.22f)).clickable { open = true }.padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text("⏱", fontSize = 13.sp); Spacer(Modifier.width(4.dp)); Text(spdLabel(cur), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        DropdownMenu(open, { open = false }) {
            listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f).forEach { s ->
                DropdownMenuItem(text = { Text(spdLabel(s) + if (abs(s - cur) < 0.01f) "  ✓" else "") }, onClick = { c.setSpeed(s); open = false })
            }
        }
    }
}

// ----- mouse helpers -----
fun mMove(c: Client, dx: Float, dy: Float) = c.move(dx, dy)
fun mClick(c: Client, right: Boolean) = c.send(if (right) "rclick" else "click")
fun mScroll(c: Client, a: Float) = c.send("scroll", "dy" to a)

/** The controller's home screen: touchpad, buttons, media controls and text input. Adapts to phone / landscape / tablet. */
@OptIn(ExperimentalComposeUiApi::class)
@SuppressLint("MissingPermission")
@Composable fun HomeController(c: Client, onExit: () -> Unit, onFull: () -> Unit, wide: Boolean, compact: Boolean, availH: Dp, onMenu: () -> Unit = {}) {
    val ctx = LocalContext.current
    var speed by remember { mutableFloatStateOf(appPrefs.getFloat("speed", 1.6f)) }
    val gain by rememberUpdatedState(speed)
    var natural by remember { mutableStateOf(appPrefs.getBoolean("natural", true)) }
    var showHelp by remember { mutableStateOf(false) }
    val padScope = rememberCoroutineScope()
    val (hintText, hintSet) = rememberHint()
    if (showHelp) GestureHelp { showHelp = false }
    // TextFieldValue (not a plain String) so the IME keeps its composing region – needed for Gboard transliteration (English → Bangla).
    var tfv by remember { mutableStateOf(TextFieldValue("")) }
    fun setText(s: String) { tfv = TextFieldValue(s, TextRange(s.length)) }
    val kbd = LocalSoftwareKeyboardController.current
    var ctrl by remember { mutableStateOf(false) }            // Ctrl armed: the next key / quick key is sent as Ctrl+key
    val padShape = RoundedCornerShape(if (compact) 16.dp else 22.dp)
    val mShape = RoundedCornerShape(if (compact) 16.dp else 22.dp)
    var live by remember { mutableStateOf(appPrefs.getBoolean("live", true)) }
    var typing by remember { mutableStateOf(false) }
    val sendText = { if (tfv.text.isNotEmpty()) { c.send("text", "s" to tfv.text); setText("") } }
    // Backspace button: in live mode it edits the input box (the host follows); with an empty box it deletes on the host directly.
    val backspaceKey: (Int) -> Unit = { n ->
        val old = tfv.text
        if (live && old.isNotEmpty()) { val k = minOf(n, old.length); val nt = old.dropLast(k); setText(nt); c.liveDiff(old, nt); if (n > k) c.backspace(n - k) }
        else c.backspace(n)
    }
    val sendCombo: (String) -> Unit = { k -> c.combo(k); ctrl = false }
    val rowH = if (compact) 42.dp else 44.dp

    val statusBar: @Composable () -> Unit = {
        Row(Modifier.fillMaxWidth().padding(top = if (compact) 2.dp else 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("☰ Shortcuts", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Accent2,
                modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onMenu).padding(horizontal = 8.dp, vertical = 6.dp))
            Spacer(Modifier.width(6.dp))
            Row(Modifier.clip(RoundedCornerShape(50)).background(Good.copy(alpha = 0.15f)).padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).clip(CircleShape).background(Good)); Spacer(Modifier.width(6.dp))
                Text("Connected", color = Good, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.weight(1f))
            Text("Disconnect", color = Bad, fontSize = 13.sp, fontWeight = FontWeight.Medium,
                modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onExit).padding(horizontal = 10.dp, vertical = 6.dp))
        }
    }

    val padArea: @Composable (Modifier) -> Unit = { m ->
        // Scroll strip + app-drawer button. Position (right / left / hidden) and speed come from Settings in the left drawer.
        val stripCol: @Composable () -> Unit = {
            Column(Modifier.width(if (compact) 46.dp else 52.dp).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(if (compact) 6.dp else 8.dp)) {
                if (Cfg.stripPos == 2) Spacer(Modifier.weight(1f))
                else Box(Modifier.weight(1f).fillMaxWidth().clip(padShape).background(CardC).border(1.dp, Edge, padShape)
                    .pointerInput(Unit) {
                        var a = 0f
                        detectVerticalDragGestures(onDragEnd = { a = 0f }, onDragCancel = { a = 0f }) { ch, d ->
                            ch.consume(); a += d
                            if (abs(a) >= 2f) { mScroll(c, a * Cfg.scrollGain); a = 0f }
                        }
                    }, contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(if (compact) 4.dp else 10.dp)) {
                        Text("▲", color = Accent2, fontSize = 12.sp)
                        Text("S\nC\nR\nO\nL\nL", fontSize = 10.sp, color = Muted, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, lineHeight = 13.sp)
                        Text("▼", color = Accent2, fontSize = 12.sp)
                    }
                }
                // opens the app drawer on the controlled device
                PadBtn(Modifier.fillMaxWidth().height(rowH), { c.send("key", "k" to "drawer") }) { NavIcon(3, if (compact) 20.dp else 22.dp) }
            }
        }
        Row(m, horizontalArrangement = Arrangement.spacedBy(if (compact) 8.dp else 10.dp)) {
            if (Cfg.stripPos == 1) stripCol()
            Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(if (compact) 6.dp else 8.dp)) {
                Box(Modifier.weight(1f).fillMaxWidth().clip(padShape)
                    .background(Brush.linearGradient(if (Pal.dark) listOf(Color(0xFF1E2750), Color(0xFF131A33)) else listOf(Color(0xFFEEF0FF), Color(0xFFDCE3FA))))
                    .border(1.5.dp, Grad, padShape)
                    .systemGestureExclusion()      // keeps the OS back-swipe from stealing touches at the pad's edges
                    .touchpad(c, padScope, { gain }, { natural }, hintSet),
                    contentAlignment = Alignment.Center) {
                    Text(hintText ?: "Touchpad", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = if (hintText != null) Accent2 else Muted)
                    c.volOv?.let {
                        Text("🔊 ${(it * 100).roundToInt()}%", Modifier.align(Alignment.TopCenter).padding(top = 10.dp)
                            .clip(RoundedCornerShape(50)).background(Color(0xCC000000)).padding(horizontal = 12.dp, vertical = 4.dp),
                            color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
                // sensitivity, right below the touchpad
                Row(Modifier.fillMaxWidth().height(28.dp), verticalAlignment = Alignment.CenterVertically) {
                    Label("SENSITIVITY")
                    Slider(speed, { speed = it }, Modifier.weight(1f).padding(start = 10.dp).height(28.dp), valueRange = 0.8f..3.5f,
                        onValueChangeFinished = { appPrefs.edit().putFloat("speed", speed).apply() },
                        colors = SliderDefaults.colors(thumbColor = Accent2, activeTrackColor = Accent))
                    Text(if (natural) "Natural" else "Classic", color = Accent2, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(start = 8.dp).clip(RoundedCornerShape(8.dp)).clickable {
                            natural = !natural; appPrefs.edit().putBoolean("natural", natural).apply() }.padding(horizontal = 4.dp, vertical = 4.dp))
                    Text("?", color = Accent2, fontSize = 15.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { showHelp = true }.padding(horizontal = 8.dp, vertical = 2.dp))
                }
                if (compact) {
                    // landscape phone: L, R and the nav buttons share one row to save height
                    Row(Modifier.fillMaxWidth().height(rowH), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        PadBtn(Modifier.weight(1f).fillMaxHeight(), { mClick(c, false) }) { Text("L", fontWeight = FontWeight.Bold, fontSize = 17.sp) }
                        PadBtn(Modifier.weight(1f).fillMaxHeight(), { mClick(c, true) }) { Text("R", fontWeight = FontWeight.Bold, fontSize = 17.sp) }
                        PadBtn(Modifier.weight(1f).fillMaxHeight(), { c.send("key", "k" to "back") }) { NavIcon(0, 20.dp) }
                        PadBtn(Modifier.weight(1f).fillMaxHeight(), { c.send("key", "k" to "home") }) { NavIcon(1, 20.dp) }
                        PadBtn(Modifier.weight(1f).fillMaxHeight(), { c.send("key", "k" to "recents") }) { NavIcon(2, 20.dp) }
                    }
                } else {
                    Row(Modifier.fillMaxWidth().height(46.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PadBtn(Modifier.weight(1f).fillMaxHeight(), { mClick(c, false) }) { Text("L", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
                        PadBtn(Modifier.weight(1f).fillMaxHeight(), { mClick(c, true) }) { Text("R", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
                    }
                    Row(Modifier.fillMaxWidth().height(rowH), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PadBtn(Modifier.weight(1f).fillMaxHeight(), { c.send("key", "k" to "back") }) { NavIcon(0) }
                        PadBtn(Modifier.weight(1f).fillMaxHeight(), { c.send("key", "k" to "home") }) { NavIcon(1) }
                        PadBtn(Modifier.weight(1f).fillMaxHeight(), { c.send("key", "k" to "recents") }) { NavIcon(2) }
                    }
                }
            }
            if (Cfg.stripPos != 1) stripCol()
        }
    }

    val media: @Composable (Modifier, Boolean, Dp) -> Unit = { m, fill, tile ->
        val st = c.st
        val onArt = st.art != null
        MediaCard(c, mShape, m.fillMaxWidth(), PaddingValues(start = 12.dp, end = 12.dp, top = 0.dp, bottom = if (compact) 6.dp else 8.dp),
            if (fill) Arrangement.SpaceEvenly else Arrangement.Top, fill) {
            Row(Modifier.fillMaxWidth().height(if (compact) 28.dp else 32.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(if (!st.access) "Host needs notification access (see Host screen / ADB setup)"
                     else st.title + (if (st.artist.isNotBlank()) " · " + st.artist else ""),
                    Modifier.weight(1f).padding(start = 4.dp), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = if (st.access) Muted else Bad)
                VideoFsBtn(c)
                FullIcon(true, onFull)
            }
            AdBar(c, compact)
            TransportRow(c, tile, false, Modifier.padding(vertical = if (fill) 0.dp else 4.dp))
            Seek(c, onArt)
            VolumeBar(c, onArt)
        }
    }

    val input: @Composable () -> Unit = {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            // extra keys of a real keyboard, shown while the input box has focus; hold = repeat
            if (typing) Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                val k = Modifier.height(34.dp).widthIn(min = 44.dp)
                RepeatKey(k, "Esc", 12) { c.special("esc", it) }
                RepeatKey(k, "Tab", 12) { c.special("tab", it) }
                RepeatKey(k, "←") { c.special("left", it) }
                RepeatKey(k, "→") { c.special("right", it) }
                RepeatKey(k, "↑") { c.special("up", it) }
                RepeatKey(k, "↓") { c.special("down", it) }
                RepeatKey(k, "Home", 12) { c.special("home_line", it) }
                RepeatKey(k, "End", 12) { c.special("end_line", it) }
                RepeatKey(k, "Del", 12) { c.special("del", it) }
            }
            // quick Ctrl combinations, shown while Ctrl is armed (live mode)
            if (live && ctrl) Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                val k = Modifier.height(34.dp).widthIn(min = 52.dp)
                for ((key, label) in listOf("a" to "All", "c" to "Copy", "x" to "Cut", "v" to "Paste", "z" to "Undo", "y" to "Redo"))
                    PadBtn(k, { sendCombo(key) }) { Text("^" + key.uppercase() + " " + label, fontSize = 11.sp, fontWeight = FontWeight.Medium, color = Accent2,
                        modifier = Modifier.padding(horizontal = 6.dp)) }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(tfv, { nv ->
                    val old = tfv.text; val n = nv.text
                    if (live && ctrl && n.length > old.length && n.startsWith(old)) {
                        // Ctrl armed + a key typed: send Ctrl+key instead of the character
                        sendCombo(n.substring(old.length).first().lowercase())
                    } else {
                        if (live && n != old) c.liveDiff(old, n)
                        tfv = nv
                    }
                },
                    Modifier.weight(1f)
                    // every tap on the box opens (or, with the setting off, keeps closed) the keyboard – also when the box is already focused
                    .pointerInput(Unit) { awaitEachGesture { awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                        if (Cfg.showKb) kbd?.show() else kbd?.hide() } }
                    .onFocusChanged { typing = it.isFocused; if (it.isFocused) { if (Cfg.showKb) kbd?.show() else kbd?.hide() } }.onPreviewKeyEvent { e ->
                        // keyboard Backspace with an empty box still deletes on the host, like a physical keyboard
                        if (live && tfv.text.isEmpty() && e.key == Key.Backspace && e.type == KeyEventType.KeyDown) { c.backspace(1); true } else false
                    },
                    singleLine = true, shape = RoundedCornerShape(28.dp),
                    placeholder = { Text(if (live) "Type here – appears live" else "Input here") }, colors = tfColors(),
                    // no autoCorrect=false: that flag turns the keyboard's suggestions off, which breaks Gboard transliteration (En → Bn)
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { if (live) setText("") else sendText(); c.send("key", "k" to "enter") }))
                Text(if (live) "LIVE" else "SEND", color = if (live) Good else Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { live = !live; appPrefs.edit().putBoolean("live", live).apply(); setText(""); ctrl = false }
                        .padding(horizontal = 6.dp, vertical = 10.dp))
                BackspaceBtn(Modifier.size(48.dp), backspaceKey)
                // live mode: no Send button – a sticky Ctrl button instead; normal mode keeps Send
                if (live) {
                    val h = LocalHapticFeedback.current
                    Box(Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(if (ctrl) Accent else CardC)
                        .border(1.dp, if (ctrl) Accent else Edge, RoundedCornerShape(14.dp))
                        .clickable { h.performHapticFeedback(HapticFeedbackType.TextHandleMove); ctrl = !ctrl }, contentAlignment = Alignment.Center) {
                        Text("Ctrl", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = if (ctrl) Color.White else LocalContentColor.current)
                    }
                } else PadBtn(Modifier.size(48.dp), { sendText() }) { Text("➤", fontSize = 18.sp, color = Accent2) }
            }
        }
    }

    val sw = LocalConfiguration.current.screenWidthDp.dp
    val outer = Modifier.fillMaxSize().padding(horizontal = if (compact) 10.dp else 14.dp).padding(top = if (wide) 6.dp else 0.dp).padding(bottom = if (compact) 6.dp else 10.dp)
    when {
        // landscape phone / tablet / unfolded foldable: the touchpad takes the full height on the left; on the right the
        // status line, a media card that stretches over all remaining height, and the text input.
        wide -> Row(outer, horizontalArrangement = Arrangement.spacedBy(if (compact) 10.dp else 14.dp)) {
            padArea(Modifier.weight(1.15f).fillMaxHeight())
            BoxWithConstraints(Modifier.weight(1f).fillMaxHeight()) {
                val hTile = (maxHeight - 270.dp) * 0.9f
                val wTile = (maxWidth - 32.dp) / 4.7f
                val tile = minOf(hTile, wTile).coerceIn(38.dp, 84.dp)
                Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    statusBar()
                    media(Modifier.weight(1f), true, tile)
                    input()
                }
            }
        }
        // short portrait screens: everything keeps a usable size and the page scrolls
        else -> {
            val tile = ((sw - 28.dp - 24.dp - 8.dp) / 4.7f).coerceIn(44.dp, 62.dp)
            if (availH < 640.dp) Column(outer.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                statusBar(); padArea(Modifier.fillMaxWidth().height(320.dp)); media(Modifier, false, tile); input()
            }
            // normal portrait phone
            else Column(outer, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                statusBar(); padArea(Modifier.weight(1f).fillMaxWidth()); media(Modifier, false, tile); input()
            }
        }
    }
}

fun hostIp(): String = localIps().split(", ").first()

fun qrBitmap(text: String): Bitmap {
    val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 512, 512)
    val bmp = Bitmap.createBitmap(512, 512, Bitmap.Config.RGB_565)
    for (x in 0 until 512) for (y in 0 until 512) bmp.setPixel(x, y, if (m.get(x, y)) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
    return bmp
}

