package com.example.lanremote

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/** Controller-side settings (live state + saved in the app preferences). Edited from the "Settings" tab of the left drawer. */
object Cfg {
    /** Speed of the scroll strip and of two-finger scrolling (1 = default). */
    var scrollGain by mutableFloatStateOf(appPrefs.getFloat("scroll_gain", 1f))
    /** How easily the left-edge swipe opens the drawer: 0 = hard, 1 = very easy. */
    var edgeSens by mutableFloatStateOf(appPrefs.getFloat("edge_sens", 0.5f))
    /** Where the scroll strip sits next to the touchpad: 0 right · 1 left · 2 hidden (two-finger scroll only). */
    var stripPos by mutableIntStateOf(appPrefs.getInt("strip_pos", 0))
    /** Blur radius (dp) and opacity of the cover-art background behind the media controls. */
    var bgBlur by mutableFloatStateOf(appPrefs.getFloat("bg_blur", 10f))
    var bgAlpha by mutableFloatStateOf(appPrefs.getFloat("bg_alpha", 1f))
    /** Tapping the input box opens this device's on-screen keyboard (turn off when a hardware keyboard is used). */
    var showKb by mutableStateOf(appPrefs.getBoolean("show_kb", true))

    fun save() {
        appPrefs.edit().putFloat("scroll_gain", scrollGain).putFloat("edge_sens", edgeSens).putInt("strip_pos", stripPos)
            .putFloat("bg_blur", bgBlur).putFloat("bg_alpha", bgAlpha).putBoolean("show_kb", showKb).apply()
    }
    fun reset() { scrollGain = 1f; edgeSens = 0.5f; stripPos = 0; bgBlur = 10f; bgAlpha = 1f; showKb = true; save() }
}

@Composable private fun SetSlider(title: String, value: Float, range: ClosedFloatingPointRange<Float>, shown: String, hint: String? = null,
                                  onChange: (Float) -> Unit) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(shown, color = Accent2, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        if (hint != null) Text(hint, color = Muted, fontSize = 11.sp)
        Slider(value, onChange, Modifier.fillMaxWidth().height(32.dp), valueRange = range, onValueChangeFinished = { Cfg.save() },
            colors = SliderDefaults.colors(thumbColor = Accent2, activeTrackColor = Accent))
    }
}

@Composable private fun PosChip(label: String, on: Boolean, onClick: () -> Unit) {
    Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (on) Color.White else Muted,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(if (on) Accent else Edge).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 7.dp))
}

@Composable fun SettingsPanel(modifier: Modifier = Modifier) {
    Column(modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Label("SWIPING & SCROLLING")
        SetSlider("Scroll / swipe speed", Cfg.scrollGain, 0.3f..3f, "%.1f×".format(Cfg.scrollGain),
            "Scroll strip and two-finger scrolling") { Cfg.scrollGain = it }
        SetSlider("Edge-swipe sensitivity", Cfg.edgeSens, 0f..1f, "${(Cfg.edgeSens * 100).roundToInt()} %",
            "How easily a swipe from the left edge opens this drawer") { Cfg.edgeSens = it }
        Column {
            Text("Scroll strip position", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("Move the vertical scroll strip, or hide it and scroll with two fingers", color = Muted, fontSize = 11.sp)
            Spacer(Modifier.height(6.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                PosChip("Right", Cfg.stripPos == 0) { Cfg.stripPos = 0; Cfg.save() }
                PosChip("Left", Cfg.stripPos == 1) { Cfg.stripPos = 1; Cfg.save() }
                PosChip("Hidden", Cfg.stripPos == 2) { Cfg.stripPos = 2; Cfg.save() }
            }
        }
        Label("TYPING")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Keyboard pops up on tap", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("Tapping the input box opens this device's on-screen keyboard", color = Muted, fontSize = 11.sp)
            }
            Switch(Cfg.showKb, { Cfg.showKb = it; Cfg.save() })
        }
        Label("MEDIA BACKGROUND")
        SetSlider("Background blur", Cfg.bgBlur, 0f..30f, if (Cfg.bgBlur < 0.5f) "Off" else "${Cfg.bgBlur.roundToInt()}",
            "Cover-art picture behind the media controls") { Cfg.bgBlur = it }
        SetSlider("Background opacity", Cfg.bgAlpha, 0.1f..1f, "${(Cfg.bgAlpha * 100).roundToInt()} %") { Cfg.bgAlpha = it }
        Text("Reset to defaults", color = Bad, fontSize = 13.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { Cfg.reset() }.padding(vertical = 6.dp, horizontal = 4.dp))
        Spacer(Modifier.height(12.dp))
    }
}
