package com.example.lanremote

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.exp
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import org.json.JSONObject

/** Mouse + keyboard injection. Needs the user to enable it in Accessibility settings. */
class RemoteAccess : AccessibilityService() {
    companion object {
        @Volatile var instance: RemoteAccess? = null
        fun handle(j: JSONObject) { instance?.let { it.noteInput(j); it.run(j) } }
        /** Native server moved/clicked the real pointer: only mirror it with the overlay cursor (no gestures). */
        fun mirror(j: JSONObject) { instance?.let { it.noteInput(j); it.mirrorMove(j) } }
        /** 0 = no ad · 1 = ad playing, not skippable yet · 2 = a "Skip ad" button is on screen. */
        fun adState(): Int = instance?.adStateNow() ?: 0
    }
    private val ui = Handler(Looper.getMainLooper())
    private var x = 0f; private var y = 0f
    private var cursor: PointerView? = null
    private val hideCursor = Runnable { cursor?.visibility = View.GONE }
    private val IDLE_MS = 30_000L
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WindowManager::class.java)
        val rb = wm.currentWindowMetrics.bounds
        x = rb.width() / 2f; y = rb.height() / 2f
        val pv = PointerView(this); cursor = pv
        // One full-screen, touch-transparent window. The pointer is only *drawn* at a new place every frame (cheap and
        // eased), instead of asking the window manager to move a tiny window on every single touch event.
        lp = WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= 30) WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                                        else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        pv.target(x, y); pv.snap(); wm.addView(pv, lp); wake()
        startWorker()
    }

    // ---------- background worker: automatic ad skipping + keeping the host's on-screen keyboard hidden ----------
    private var worker: HandlerThread? = null
    private var bg: Handler? = null
    private var tickN = 0
    private var lastAuto = 0L
    private var kbApplied = -1
    /** Time of the last mouse / keyboard command. Accessibility tree scans are skipped while the controller is being used: walking a
     *  big tree makes the foreground app answer hundreds of binder calls, which delays the injected pointer events (mouse lag). */
    @Volatile private var lastInput = 0L
    fun noteInput(j: JSONObject) { if (j.optString("t") != "state") lastInput = SystemClock.elapsedRealtime() }
    private fun busyWithInput() = SystemClock.elapsedRealtime() - lastInput < 900

    private val tick = object : Runnable {
        override fun run() {
            var cost = 0L
            try {
                val p = getSharedPreferences("s", 0)
                applyKeyboard(p.getBoolean("hide_kb", true))
                val pm = getSystemService(PowerManager::class.java)
                // ads make sound, so the (cheap) "is audio playing" check keeps the expensive tree scan away from every other moment
                val audio = getSystemService(android.media.AudioManager::class.java).isMusicActive
                if (p.getBoolean("auto_skip", true) && pm.isInteractive && audio && !busyWithInput()) {
                    val t0 = SystemClock.elapsedRealtime()
                    val s = scanAll()
                    val n = s.node
                    val now = SystemClock.elapsedRealtime()
                    if (s.state == 2 && n != null && now - lastAuto > 1500) {
                        lastAuto = now; adAt = 0L
                        ui.post { pressNode(n) }
                    }
                    cost = SystemClock.elapsedRealtime() - t0
                }
            } catch (_: Throwable) {}
            bg?.postDelayed(this, maxOf(700L, cost * 5))     // slow tree (big web page) → scan less often
        }
    }

    private fun startWorker() {
        if (worker == null) { worker = HandlerThread("lanremote-auto", android.os.Process.THREAD_PRIORITY_BACKGROUND).also { it.start(); bg = Handler(it.looper) } }
        bg?.removeCallbacks(tick); bg?.postDelayed(tick, 1000)
    }

    /** Soft keyboard mode of the host: hidden = no on-screen keyboard pops up while the controller types or clicks into a field. */
    private fun applyKeyboard(hide: Boolean) {
        val want = if (hide) SHOW_MODE_HIDDEN else SHOW_MODE_AUTO
        if (kbApplied == want) return
        try { if (softKeyboardController.setShowMode(want)) kbApplied = want } catch (_: Throwable) {}
    }

    private fun realSize(): Pair<Int, Int> {
        val b = wm.currentWindowMetrics.bounds
        return Pair(b.width(), b.height())
    }

    private fun mirrorMove(j: JSONObject) = ui.post {
        if (j.optString("t") != "move") { wake(); return@post }
        val (w, h) = realSize()
        x = (x + j.getDouble("dx").toFloat()).coerceIn(0f, w - 1f)
        y = (y + j.getDouble("dy").toFloat()).coerceIn(0f, h - 1f); place(); wake()
    }

    private fun place() { cursor?.target(x, y) }

    /** Show the pointer and (re)start the 30 s idle timer. */
    private fun wake() {
        cursor?.let { if (it.visibility != View.VISIBLE) { it.visibility = View.VISIBLE; it.snap() } }
        ui.removeCallbacks(hideCursor); ui.postDelayed(hideCursor, IDLE_MS)
    }

    private fun run(j: JSONObject) = ui.post {
        val (rw, rh) = realSize()
        when (j.getString("t")) {
            "move" -> { x = (x + j.getDouble("dx").toFloat()).coerceIn(0f, rw - 1f)
                        y = (y + j.getDouble("dy").toFloat()).coerceIn(0f, rh - 1f); place(); wake(); if (dDrag) pumpDrag() }
            "down" -> { wake(); dDrag = true; dx0 = x; dy0 = y; dStroke = null; pumpDrag() }
            "up" -> { dDrag = false; pumpDrag() }
            "hscroll" -> hscroll(j.getDouble("dx").toFloat())
            "zoom" -> zoom(j.getDouble("f").toFloat())
            "click" -> { wake(); gesture(x, y, x, y, 50) }
            "rclick" -> { wake(); gesture(x, y, x, y, 700) }
            "scroll" -> scroll(j.getDouble("dy").toFloat())
            "launch" -> startPkg(j.getString("p"))
            "url" -> startUrl(j.getString("u"))
            "fs" -> fullscreen(false)
            "vfs" -> fullscreen(true)
            "skipad" -> skipAd()
            "text" -> insertText(j.getString("s"))
            "combo" -> combo(j.optString("k"))
            "key" -> when (j.getString("k")) {
                "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
                "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
                "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
                "drawer" -> openDrawer()
                "notif" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
                "quick" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
                "lock" -> performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
                "screenshot" -> performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
                "power" -> performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)
                "backspace" -> deleteBack(j.optInt("c", 1).coerceIn(1, 500))
                "left" -> moveCaret { _, s, e, c -> if (e > s) s else s - c }
                "right" -> moveCaret { _, s, e, c -> if (e > s) e else e + c }
                "home_line" -> moveCaret { _, _, _, _ -> 0 }
                "end_line" -> moveCaret { cur, _, _, _ -> cur.length }
                "del" -> editAt { cur, s, e -> val upTo = if (e > s) e else (e + j.optInt("c", 1)).coerceAtMost(cur.length)
                                               (cur.substring(0, s) + cur.substring(upTo)) to s }
                "enter" -> enter()
            }
        }
    }

    // ---------- smooth, continuous scrolling ----------
    // One long finger-drag is kept alive (continueStroke) and extended with every incoming delta, so scrolling follows
    // the controller's finger without the stop/start stutter of many separate swipes.
    private var scrollStroke: GestureDescription.StrokeDescription? = null
    private var scrollX = 0f; private var scrollY = 0f
    private var pendingDy = 0f
    private var scrolling = false
    private val endScroll = Runnable { finishScroll() }

    private fun scroll(dy: Float) {
        wake()
        val accel = 2.5f + minOf(Math.abs(dy), 40f) / 10f          // faster drag = faster scroll
        pendingDy += -dy * accel
        ui.removeCallbacks(endScroll)
        if (!scrolling) pumpScroll()
    }

    private fun pumpScroll() {
        if (Math.abs(pendingDy) < 1f) { if (scrollStroke != null) ui.postDelayed(endScroll, 120); return }
        val h = resources.displayMetrics.heightPixels
        val top = h * 0.08f; val bot = h * 0.92f
        val d = pendingDy.coerceIn(-500f, 500f)
        if (scrollStroke == null) {
            scrollX = x; scrollY = y.coerceIn(top, bot)
            if (d < 0 && scrollY - top < 120f) scrollY = bot - 20f else if (d > 0 && bot - scrollY < 120f) scrollY = top + 20f
        }
        val ny = (scrollY + d).coerceIn(top, bot)
        val hitEdge = scrollY + d != ny
        val moved = ny - scrollY
        pendingDy -= if (hitEdge) pendingDy else moved            // at an edge: restart the drag from a fresh place
        val dur = (Math.abs(moved) / 4f).toLong().coerceIn(10L, 80L)
        val path = Path().apply { moveTo(scrollX, scrollY); lineTo(scrollX, ny) }
        val cont = !hitEdge
        val sd = scrollStroke?.continueStroke(path, 0, dur, cont) ?: GestureDescription.StrokeDescription(path, 0, dur, cont)
        scrolling = true
        val ok = dispatchGesture(GestureDescription.Builder().addStroke(sd).build(), object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { ui.post { scrolling = false; scrollY = ny; scrollStroke = if (cont) sd else null; pumpScroll() } }
            override fun onCancelled(g: GestureDescription?) { ui.post { scrolling = false; scrollStroke = null; pendingDy = 0f } }
        }, ui)
        if (!ok) { scrolling = false; scrollStroke = null; pendingDy = 0f }
    }

    private fun finishScroll() {
        val st = scrollStroke ?: return
        if (scrolling) return
        val path = Path().apply { moveTo(scrollX, scrollY); lineTo(scrollX, scrollY) }
        scrolling = true
        val ok = dispatchGesture(GestureDescription.Builder().addStroke(st.continueStroke(path, 0, 10, false)).build(), object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { ui.post { scrolling = false; scrollStroke = null; pumpScroll() } }
            override fun onCancelled(g: GestureDescription?) { ui.post { scrolling = false; scrollStroke = null } }
        }, ui)
        if (!ok) { scrolling = false; scrollStroke = null }
    }

    // ---------- drag (tap-tap-hold-move): one long stroke that is extended with every pointer move ----------
    private var dStroke: GestureDescription.StrokeDescription? = null
    private var dDrag = false; private var dBusy = false
    private var dx0 = 0f; private var dy0 = 0f

    private fun pumpDrag() {
        if (dBusy) return
        val ending = !dDrag
        if (ending && dStroke == null) return
        val tx = x; val ty = y
        if (!ending && dStroke != null && tx == dx0 && ty == dy0) return
        val path = Path().apply { moveTo(dx0, dy0); if (tx != dx0 || ty != dy0) lineTo(tx, ty) }
        val cont = !ending
        val dur = if (dStroke == null) 400L else if (ending) 20L else 30L   // first stroke = the long-press hold
        val sd = dStroke?.continueStroke(path, 0, dur, cont) ?: GestureDescription.StrokeDescription(path, 0, dur, cont)
        dBusy = true
        val ok = dispatchGesture(GestureDescription.Builder().addStroke(sd).build(), object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { ui.post { dBusy = false; dx0 = tx; dy0 = ty; dStroke = if (cont) sd else null; pumpDrag() } }
            override fun onCancelled(g: GestureDescription?) { ui.post { dBusy = false; dStroke = null; dDrag = false } }
        }, ui)
        if (!ok) { dBusy = false; dStroke = null; dDrag = false }
    }

    // ---------- horizontal scroll and pinch zoom (fallback when the native server is not running) ----------
    private var hAcc = 0f
    private fun hscroll(dx: Float) {
        wake(); hAcc += -dx * 3f
        if (Math.abs(hAcc) < 60f) return
        val (w, _) = realSize()
        val d = hAcc.coerceIn(-400f, 400f); hAcc = 0f
        val sx = x.coerceIn(60f, w - 60f)
        gesture(sx, y, (sx + d).coerceIn(10f, w - 10f), y, 90)
    }

    private var zAcc = 1f; private var zBusy = false
    private fun zoom(f: Float) {
        wake(); zAcc = (zAcc * f).coerceIn(0.4f, 2.5f)
        if (zBusy || Math.abs(zAcc - 1f) < 0.08f) return
        val (w, _) = realSize()
        val r0 = 110f * resources.displayMetrics.density; val r1 = r0 * zAcc; zAcc = 1f
        val m = maxOf(r0, r1) + 10f
        val cx = if (w > 2 * m) x.coerceIn(m, w - m) else w / 2f
        fun line(sign: Float) = GestureDescription.StrokeDescription(Path().apply { moveTo(cx + sign * r0, y); lineTo(cx + sign * r1, y) }, 0, 140)
        zBusy = true
        val ok = dispatchGesture(GestureDescription.Builder().addStroke(line(-1f)).addStroke(line(1f)).build(), object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { ui.post { zBusy = false } }
            override fun onCancelled(g: GestureDescription?) { ui.post { zBusy = false } }
        }, ui)
        if (!ok) zBusy = false
    }

    private fun startPkg(p: String) {
        try { packageManager.getLaunchIntentForPackage(p)?.let { startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)) } } catch (_: Exception) {}
    }
    private fun startUrl(u: String) {
        if (!(u.startsWith("https://") || u.startsWith("http://"))) return
        try { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
    }

    /** Opens the app drawer: system "all apps" action on Android 12L+, else Home + swipe up. */
    private fun openDrawer() {
        if (Build.VERSION.SDK_INT >= 32 && performGlobalAction(GLOBAL_ACTION_ACCESSIBILITY_ALL_APPS)) return
        performGlobalAction(GLOBAL_ACTION_HOME)
        ui.postDelayed({
            val dm = resources.displayMetrics
            val cx = dm.widthPixels / 2f
            gesture(cx, dm.heightPixels * 0.92f, cx, dm.heightPixels * 0.35f, 250)
        }, 400)
    }

    private fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long) {
        val p = Path().apply { moveTo(x1, y1); if (x1 != x2 || y1 != y2) lineTo(x2, y2) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, ms)).build(), null, null)
    }

    /**
     * Edits the focused text field AT THE CARET (like a real keyboard), not at the end of the text:
     * [f] gets the current text and the selection and returns the new text plus the new caret position.
     */
    private fun editAt(f: (cur: String, s: Int, e: Int) -> Pair<String, Int>) {
        val n = findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return
        val hint = n.isShowingHintText
        val cur = if (hint) "" else n.text?.toString() ?: ""
        var s = if (hint) 0 else n.textSelectionStart
        var e = if (hint) 0 else n.textSelectionEnd
        if (s < 0 || e < 0) { s = cur.length; e = cur.length }
        s = s.coerceIn(0, cur.length); e = e.coerceIn(0, cur.length)
        if (s > e) { val t = s; s = e; e = t }
        val (nt, caret) = f(cur, s, e)
        n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, nt) })
        n.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, Bundle().apply {
            putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, caret.coerceIn(0, nt.length))
            putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, caret.coerceIn(0, nt.length)) })
    }

    /** Moves the caret of the focused field (arrow keys / Home / End when the native server is not running). */
    private fun moveCaret(f: (cur: String, s: Int, e: Int, count: Int) -> Int) {
        val n = findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return
        val cur = if (n.isShowingHintText) "" else n.text?.toString() ?: ""
        var s = n.textSelectionStart; var e = n.textSelectionEnd
        if (s < 0 || e < 0) { s = cur.length; e = cur.length }
        s = s.coerceIn(0, cur.length); e = e.coerceIn(0, cur.length)
        if (s > e) { val t = s; s = e; e = t }
        val p = f(cur, s, e, 1).coerceIn(0, cur.length)
        n.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, Bundle().apply {
            putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, p)
            putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, p) })
    }

    /** Ctrl + key when the native server is not available: the Ctrl shortcuts that have an Accessibility equivalent. */
    private fun combo(k: String) {
        val n = findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return
        when (k.lowercase()) {
            "a" -> {
                val len = (if (n.isShowingHintText) "" else n.text?.toString() ?: "").length
                n.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, Bundle().apply {
                    putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0)
                    putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, len) })
            }
            "c" -> n.performAction(AccessibilityNodeInfo.ACTION_COPY)
            "x" -> n.performAction(AccessibilityNodeInfo.ACTION_CUT)
            "v" -> n.performAction(AccessibilityNodeInfo.ACTION_PASTE)
        }
    }

    private fun insertText(t: String) = editAt { cur, s, e -> (cur.substring(0, s) + t + cur.substring(e)) to (s + t.length) }

    /** Backspace: removes the selection, or [count] characters in front of the caret. */
    private fun deleteBack(count: Int) = editAt { cur, s, e ->
        val from = if (e > s) (s - (count - 1)).coerceAtLeast(0) else (s - count).coerceAtLeast(0)
        (cur.substring(0, from) + cur.substring(e)) to from
    }

    // ---------- video full screen (YouTube, streaming apps, web players in any browser) ----------
    private val FS_RE = Regex("""(?i)(full[\s\-]?screen)""")
    private val FS_I18N = listOf("pantalla completa", "tela cheia", "plein écran", "vollbild", "schermo intero", "volledig scherm",
        "полноэкранный", "tam ekran", "layar penuh", "toàn màn hình", "全画面", "전체 화면", "전체화면", "全屏", "全螢幕",
        "फ़ुल स्क्रीन", "फुल स्क्रीन", "ملء الشاشة", "pełny ekran", "เต็มหน้าจอ")
    private val FS_IDS = listOf("fullscreen_button", "exo_fullscreen", "exo_fullscreen_button", "player_fullscreen_button", "fullscreen",
        "fs_button", "btn_fullscreen", "full_screen_button", "fullscreen_toggle", "fullscreen_icon", "iv_fullscreen", "img_fullscreen",
        "button_fullscreen", "ima_fullscreen", "enter_fullscreen_button", "full_screen")
    private val FS_ID_RE = Regex("""(?i).*[:/_](full_?screen|exo_fullscreen|fs_button|btn_fs|enter_fs).*""")

    private fun fsLabel(n: AccessibilityNodeInfo): Boolean =
        labelsOf(n).any { l -> FS_RE.containsMatchIn(l) || FS_I18N.any { l.contains(it, true) } } ||
            n.viewIdResourceName?.let { FS_ID_RE.matches(it) } == true

    /** Breadth-first walk over a window's nodes; [f] returns true to stop. Bounded, because every node is a binder call. */
    private fun walk(root: AccessibilityNodeInfo, budget: Int, f: (AccessibilityNodeInfo) -> Boolean) {
        val q = ArrayDeque<AccessibilityNodeInfo>(); q.add(root)
        var left = budget
        while (q.isNotEmpty() && left > 0) {
            val n = q.removeFirst(); left--
            if (f(n)) return
            for (i in 0 until n.childCount) n.getChild(i)?.let { q.add(it) }
        }
    }

    /** [tree] = also walk the whole accessibility tree (web players in browsers often expose the button only that way). */
    private fun findFullscreen(tree: Boolean): AccessibilityNodeInfo? {
        val i18n = FS_I18N
        for (root in appRoots()) {
            val pkg = root.packageName?.toString() ?: ""
            if (pkg.isNotEmpty()) for (id in FS_IDS) {
                val n = root.findAccessibilityNodeInfosByViewId("$pkg:id/$id").firstOrNull { it.isVisibleToUser }
                if (n != null) return n
            }
            for (q in listOf("full screen", "fullscreen", "full-screen") + i18n) for (n in root.findAccessibilityNodeInfosByText(q)) {
                if (!n.isVisibleToUser) continue
                val okLabel = labelsOf(n).any { it.length <= 40 }
                val idOk = n.viewIdResourceName?.let { FS_ID_RE.matches(it) } == true
                if (okLabel || idOk) return n
            }
        }
        if (tree) for (root in appRoots()) {
            var hit: AccessibilityNodeInfo? = null
            walk(root, 1500) { n -> if (n.isVisibleToUser && fsLabel(n)) { hit = n; true } else false }
            if (hit != null) return hit
        }
        return null
    }

    /** Presses the node (or its clickable parent); falls back to tapping its centre (web content is often not "clickable"). */
    private fun pressNode(n: AccessibilityNodeInfo): Boolean {
        var t: AccessibilityNodeInfo? = n
        while (t != null && !t.isClickable) t = t.parent
        if (t != null && t.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        val b = android.graphics.Rect(); n.getBoundsInScreen(b)
        if (b.isEmpty) return false
        gesture(b.exactCenterX(), b.exactCenterY(), b.exactCenterX(), b.exactCenterY(), 50)
        return true
    }

    private val VIDEO_CLS = Regex("""(?i)(SurfaceView|TextureView|VideoView|PlayerView|ExoPlayer)""")

    /** Biggest visible native video surface on screen (null for web videos, which have no node of their own). */
    private fun videoBounds(): android.graphics.Rect? {
        var best: android.graphics.Rect? = null; var bestA = 0L
        for (root in appRoots()) walk(root, 700) { n ->
            if (n.isVisibleToUser && VIDEO_CLS.containsMatchIn(n.className?.toString() ?: "")) {
                val r = android.graphics.Rect(); n.getBoundsInScreen(r)
                val a = r.width().toLong() * r.height()
                if (a > bestA) { bestA = a; best = r }
            }
            false
        }
        return best
    }

    private var fsToken = 0

    private fun tryFullscreen(tree: Boolean): Boolean = findFullscreen(tree)?.let { pressNode(it) } ?: false

    /**
     * Toggles full screen of the video in front. [deep] = when the full screen button is not on screen: wake the player controls
     * (tap on the video), search again (whole tree, with retries while the controls fade in), then tap where the button normally
     * sits (bottom-right corner of the video), and finally the swipe-up gesture of the YouTube app.
     */
    private fun fullscreen(deep: Boolean) {
        val tok = ++fsToken
        if (tryFullscreen(deep)) return
        if (!deep) return
        val (w, h) = realSize()
        val land = w > h
        val vb = videoBounds()
        val cx = vb?.exactCenterX() ?: (w / 2f); val cy = vb?.exactCenterY() ?: (if (land) h / 2f else h * 0.28f)
        gesture(cx, cy, cx, cy, 40)                                       // show the controls
        ui.postDelayed({
            if (tok != fsToken) return@postDelayed
            if (tryFullscreen(true)) return@postDelayed
            gesture(cx, cy, cx, cy, 40)                                   // the first tap may only have focused the page
            ui.postDelayed({
                if (tok != fsToken) return@postDelayed
                if (tryFullscreen(true)) return@postDelayed
                val pkg = appRoots().firstOrNull()?.packageName?.toString() ?: ""
                if (pkg.startsWith("com.google.android.youtube") && !land)  // YouTube: swipe up on the player = full screen
                    gesture(cx, cy + h * 0.06f, cx, cy - h * 0.12f, 160)
                else if (vb != null) {
                    val d = resources.displayMetrics.density
                    val tx = vb.right - 28 * d; val ty = vb.bottom - 28 * d
                    gesture(tx, ty, tx, ty, 50)
                }
            }, 650)
        }, 550)
    }

    // ---------- ad detection: video + music streaming apps and the common Android browsers ----------
    // Works through the accessibility tree, so it needs no app-specific hooks. A skip control is recognised by its
    // label ("Skip ad", "Skip", localised variants) or by well-known view ids. A bare "Skip" is only trusted inside a
    // browser / streaming app AND when an ad cue (e.g. "Ad · 0:15", "Visit advertiser") is found nearby.
    @Volatile private var adCache = 0
    @Volatile private var adAt = 0L

    private class Scan(val node: AccessibilityNodeInfo?, val state: Int, val deep: Boolean = false)
    @Volatile private var lastDeep = 0L          // last time the whole tree was walked (throttled to ~1 per 1.2 s)
    @Volatile private var deepState = 0
    @Volatile private var deepAt = 0L

    private val BROWSER_PKGS = listOf("com.android.chrome", "com.chrome.", "com.google.android.apps.chrome", "org.mozilla.",
        "com.microsoft.emmx", "com.brave.browser", "com.opera.", "com.sec.android.app.sbrowser", "com.vivaldi.browser",
        "com.duckduckgo.mobile.android", "com.kiwibrowser.browser", "com.mi.globalbrowser", "com.android.browser",
        "com.UCMobile", "com.uc.browser", "com.yandex.browser", "com.huawei.browser", "com.ecosia.android", "org.torproject",
        "com.naver.whale", "mark.via", "com.cloudmosa.puffin", "com.google.android.googlequicksearchbox")
    private val STREAM_PKGS = listOf("com.google.android.youtube", "com.google.android.apps.youtube", "in.startv.hotstar",
        "com.jio.media.ondemand", "com.sonyliv", "com.graymatrix.did", "com.amazon.avod", "com.amazon.mp3", "com.disney.",
        "com.hulu.", "com.peacocktv.", "com.cbs.app", "com.wbd.stream", "com.tubitv", "tv.pluto.android", "tv.twitch.android",
        "com.dailymotion.", "com.vimeo.", "com.crunchyroll.", "com.mxtech.videoplayer", "com.plexapp.android", "com.netflix.",
        "com.facebook.katana", "com.facebook.lite", "com.instagram.android", "com.zhiliaoapp.musically", "com.ss.android.ugc.",
        "com.spotify.", "com.pandora.android", "com.soundcloud.android", "deezer.android.app", "com.jio.media.jiobeats",
        "com.gaana", "com.bsbportal.music", "com.audiomack", "tunein.player", "com.clearchannel.iheartradio", "com.anghami",
        "com.napster.", "com.boomplay.", "com.apple.android.music", "com.aspiro.tidal", "com.hungama.", "com.bms.", "com.voot.")
    private val STREAM_TOKENS = listOf("youtube", "hotstar", "video", "music", "player", "radio", "stream", "podcast", "tv.")

    private fun isBrowser(pkg: String) = BROWSER_PKGS.any { pkg.startsWith(it) } || pkg.startsWith("org.chromium.") ||
        pkg.contains("browser", true) || pkg.contains("chrome", true) || pkg.contains("firefox", true)
    private fun isStreaming(pkg: String) = STREAM_PKGS.any { pkg.startsWith(it) } || STREAM_TOKENS.any { pkg.contains(it) }

    private val SKIP_AD_RE = Regex("""(?i)^\W*(skip\s*(the\s*)?(video\s*)?(ads?|adverts?|advertisements?|commercials?)|ad\s*skip)\W*\z""")
    private val COUNTDOWN_RE = Regex("""(?i)(skip\s*(ads?\s*)?(in|after)\s*\d+|skip\s*ads?\s*\d+|can\s*skip\s*(ad\s*)?in|\d+\s*s?\s*(left\s*)?(to|until)\s*skip)""")
    private val BARE_RE = Regex("""(?i)^\W*skip\W*\z""")
    private val CUE_RE = Regex("""(?i)(^\W*(ad|ads|advertisement)\s*([·•|:\-–]|\d+\s*(of|/)\s*\d+|\d+:\d+)|visit advertiser|my ad center|why this ad|ads? will (resume|end)|ad will end|video will play after( the)? ad|ad\s*break|ad\s*playing)""")
    private val SKIP_ID_RE = Regex("""(?i).*(skip_?ad|ad_?skip|skip_?ads|modern_skip|ima_skip).*""")
    private val AD_ID_RE = Regex("""(?i).*[:/_](ad_(progress|countdown|timer|badge|label|remaining|counter|info|break)|(video|player|ima|preroll|midroll)_?ad).*""")
    private val SKIP_QUERIES = listOf("skip")
    private val AD_WORD_RE = Regex("""(?i)^\W*(ads?|sponsored)\W*\z""")
    private val CUE_QUERIES = listOf("Visit advertiser", "Why this ad", "My Ad Center", "Ad ·", "Ad •", "Ad 1 of", "Ad 2 of", "Ads will resume", "Ad will end")
    private val SKIP_I18N = mapOf(
        "es" to listOf("omitir anuncio", "saltar anuncio", "saltar publicidad", "omitir publicidad"),
        "pt" to listOf("pular anúncio", "pular publicidade", "ignorar anúncio"),
        "fr" to listOf("passer l'annonce", "ignorer l'annonce", "passer la publicité", "ignorer la publicité"),
        "de" to listOf("werbung überspringen", "anzeige überspringen"),
        "it" to listOf("salta annuncio", "salta pubblicità"),
        "nl" to listOf("advertentie overslaan", "reclame overslaan"),
        "ru" to listOf("пропустить рекламу", "пропустить"),
        "tr" to listOf("reklamı geç", "reklamı atla"),
        "pl" to listOf("pomiń reklamę"),
        "id" to listOf("lewati iklan"),
        "vi" to listOf("bỏ qua quảng cáo"),
        "th" to listOf("ข้ามโฆษณา"),
        "ja" to listOf("広告をスキップ", "広告をスキップする"),
        "ko" to listOf("광고 건너뛰기"),
        "zh" to listOf("跳过广告", "略過廣告"),
        "hi" to listOf("विज्ञापन छोड़ें", "विज्ञापन स्किप करें", "स्किप ऐड"),
        "ar" to listOf("تخطي الإعلان"))

    /** Cached for 350 ms, called from the host's state thread. */
    fun adStateNow(): Int {
        val now = SystemClock.elapsedRealtime()
        if (now - adAt < 350 || (busyWithInput() && adAt != 0L)) return adCache
        adAt = now
        val s = try { scanAll() } catch (_: Exception) { Scan(null, 0) }
        if (s.deep) { deepState = s.state; deepAt = now }
        // a scan that skipped the (throttled) full-tree walk must not make a button found by the last walk blink away
        adCache = if (!s.deep && s.state < deepState && now - deepAt < 3500) deepState else s.state
        return adCache
    }

    /** Every application window on screen (also picture-in-picture / split screen), top-most first. */
    private fun appRoots(): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        try {
            for (w in windows) if (w.type == AccessibilityWindowInfo.TYPE_APPLICATION) w.root?.let { if (it.packageName != packageName) out.add(it) }
        } catch (_: Exception) {}
        if (out.isEmpty()) rootInActiveWindow?.let { out.add(it) }
        return out
    }

    /** [force] = always walk the whole tree (used when the user presses "Skip ad"); otherwise it is done at most every 1.2 s. */
    private fun scanAll(force: Boolean = false): Scan {
        val now = SystemClock.elapsedRealtime()
        val deep = force || (now - lastDeep > 3000 && !busyWithInput())
        if (deep) lastDeep = now
        var best = Scan(null, 0)
        for (r in appRoots()) {
            val s = try { scanRoot(r, deep) } catch (_: Exception) { Scan(null, 0) }
            if (s.state > best.state) best = s
            if (best.state == 2) break
        }
        return Scan(best.node, best.state, deep)
    }

    private fun labelsOf(n: AccessibilityNodeInfo): List<String> =
        listOfNotNull(n.text?.toString(), n.contentDescription?.toString(), n.tooltipText?.toString()).map { it.trim() }.filter { it.isNotEmpty() && it.length <= 60 }

    private fun scanRoot(root: AccessibilityNodeInfo, deep: Boolean): Scan {
        val pkg = root.packageName?.toString() ?: ""
        val browser = isBrowser(pkg)
        val known = browser || isStreaming(pkg)
        var cue = false
        var countdown = false
        var exact: AccessibilityNodeInfo? = null
        var bare: AccessibilityNodeInfo? = null

        // 1) view ids used by native players (YouTube and friends)
        if (pkg.isNotEmpty()) {
            for (id in listOf("skip_ad_button", "skip_ad_button_container", "modern_skip_button", "skip_ad_text", "skip_ads_button", "btn_skip_ad", "ad_skip_button", "skip_ad"))
            {
                val n = root.findAccessibilityNodeInfosByViewId("$pkg:id/$id").firstOrNull { it.isVisibleToUser }
                if (n != null) {
                    val l = labelsOf(n).firstOrNull() ?: ""
                    if (l.any { it.isDigit() }) { countdown = true } else if (exact == null) { exact = n }
                }
            }
            if (root.findAccessibilityNodeInfosByViewId("$pkg:id/ad_progress_text").isNotEmpty()) cue = true
        }

        // 2) text / description search for skip controls (English + the device language)
        val lang = java.util.Locale.getDefault().language
        val i18n = SKIP_I18N[lang] ?: emptyList()
        val seen = HashSet<AccessibilityNodeInfo>()
        for (q in SKIP_QUERIES + i18n) for (n in root.findAccessibilityNodeInfosByText(q)) {
            if (!n.isVisibleToUser || !seen.add(n)) continue
            val idMatch = n.viewIdResourceName?.let { SKIP_ID_RE.matches(it) } == true
            for (l in labelsOf(n)) {
                val low = l.lowercase()
                when {
                    COUNTDOWN_RE.containsMatchIn(low) -> countdown = true
                    SKIP_AD_RE.matches(low) || i18n.any { low.contains(it) } || (idMatch && low.any { it.isLetter() }) ->
                        if (low.any { it.isDigit() }) countdown = true else if (exact == null) exact = n
                    BARE_RE.matches(low) -> if (bare == null) bare = n
                }
            }
        }

        // 2b) browsers / players that the text search does not find (web content, custom views): look at every node of the window
        if (deep && known && exact == null) {
            walk(root, 500) { n ->
                if (n.isVisibleToUser) for (l in labelsOf(n)) {
                    val low = l.lowercase()
                    when {
                        COUNTDOWN_RE.containsMatchIn(low) -> countdown = true
                        SKIP_AD_RE.matches(low) || i18n.any { low.contains(it) } ->
                            if (low.any { it.isDigit() }) countdown = true else if (exact == null) exact = n
                        BARE_RE.matches(low) -> if (bare == null) bare = n
                        CUE_RE.containsMatchIn(low) -> cue = true
                    }
                }
                exact != null
            }
        }

        // 3) cues that an ad (not a normal video) is playing
        if (known && exact == null) {
            for (q in CUE_QUERIES) {
                if (cue) break
                for (n in root.findAccessibilityNodeInfosByText(q))
                    if (n.isVisibleToUser && labelsOf(n).any { CUE_RE.containsMatchIn(it) }) { cue = true; break }
            }
        }

        exact?.let { return Scan(it, 2) }
        if (bare != null && known && (cue || (browser && nearbyCue(bare!!)))) return Scan(bare, 2)
        if (countdown || cue) return Scan(null, 1)
        return Scan(null, 0)
    }

    /** Looks for an ad cue in the neighbourhood of a bare "Skip" button (the player overlay it sits in). */
    private fun nearbyCue(skip: AccessibilityNodeInfo): Boolean {
        var p = skip.parent
        var depth = 0
        var budget = 300
        while (p != null && depth < 7) {
            val q = ArrayDeque<AccessibilityNodeInfo>(); q.add(p)
            while (q.isNotEmpty() && budget > 0) {
                val n = q.removeFirst(); budget--
                if (labelsOf(n).any { CUE_RE.containsMatchIn(it) || AD_WORD_RE.matches(it) }) return true
                for (i in 0 until n.childCount) n.getChild(i)?.let { q.add(it) }
            }
            p = p.parent; depth++
        }
        return false
    }

    /** Presses the on-screen "Skip ad" button of the app / browser in front. */
    private fun skipAd() {
        val n = scanAll(true).node ?: return
        pressNode(n); adAt = 0L
    }

    private fun enter() {
        val n = findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return
        if (Build.VERSION.SDK_INT >= 30) n.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        else insertText("\n")
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: android.content.Intent?): Boolean {
        instance = null
        bg?.removeCallbacks(tick); worker?.quitSafely(); worker = null; bg = null; kbApplied = -1
        ui.removeCallbacks(hideCursor); ui.removeCallbacks(endScroll)
        try { wm.removeView(cursor) } catch (_: Exception) {}
        return super.onUnbind(i)
    }
}

/**
 * Classic arrow mouse pointer, drawn inside a full-screen overlay. The tip (hotspot) is at (x, y) in screen coordinates.
 * The drawn position eases towards the target every frame (≈20 ms time constant), so the pointer glides even though
 * touch events arrive in small, uneven steps over Wi-Fi.
 */
class PointerView(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val k = 1.5f * d
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 1.3f * d; strokeJoin = Paint.Join.ROUND }
    private val path = android.graphics.Path().apply {
        moveTo(1f * k, 1f * k); lineTo(1f * k, 17.5f * k); lineTo(5f * k, 13.5f * k); lineTo(8f * k, 20f * k)
        lineTo(10.5f * k, 19f * k); lineTo(7.5f * k, 12.5f * k); lineTo(13f * k, 12.5f * k); close()
    }
    private var tx = 0f; private var ty = 0f      // where the pointer should be
    private var cx = 0f; private var cy = 0f      // where it is drawn
    private var lastFrame = 0L
    private val loc = IntArray(2)

    fun target(x: Float, y: Float) { tx = x; ty = y; invalidate() }
    fun snap() { cx = tx; cy = ty; lastFrame = 0L; invalidate() }

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = if (lastFrame == 0L) 8L else (now - lastFrame).coerceIn(1L, 50L)
        lastFrame = now
        val a = 1f - exp(-dt / 20f)
        cx += (tx - cx) * a; cy += (ty - cy) * a
        val moving = abs(tx - cx) > 0.4f || abs(ty - cy) > 0.4f
        if (!moving) { cx = tx; cy = ty }
        getLocationOnScreen(loc)
        c.save(); c.translate(cx - loc[0], cy - loc[1]); c.drawPath(path, fill); c.drawPath(path, line); c.restore()
        if (moving) postInvalidateOnAnimation() else lastFrame = 0L
    }
}
