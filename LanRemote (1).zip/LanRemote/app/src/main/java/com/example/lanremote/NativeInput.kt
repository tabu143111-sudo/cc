package com.example.lanremote

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.io.PrintWriter
import java.net.InetSocketAddress
import java.net.Socket

/** Bridge from the host app to the ADB-started [InputServer]. If it is not running, input falls back to Accessibility. */
object NativeInput {
    @Volatile var connected = false
    /** Protocol version of the running native server (1 = old build without brightness, 2 = current). */
    @Volatile var ver = 0
    private var sock: Socket? = null
    private var out: PrintWriter? = null

    @Synchronized fun connect(ctx: Context) {
        if (connected) return
        try {
            val f = File(ctx.getExternalFilesDir(null), "native_token")
            if (!f.exists()) return
            val s = Socket(); s.tcpNoDelay = true; s.connect(InetSocketAddress("127.0.0.1", 8766), 600); s.soTimeout = 2000
            val o = PrintWriter(s.getOutputStream(), true)
            o.println(f.readText().trim())
            val hello = s.getInputStream().bufferedReader().readLine()
            if (hello != null && hello.startsWith("ok")) { ver = hello.removePrefix("ok").toIntOrNull() ?: 1; s.soTimeout = 0; sock = s; out = o; connected = true } else s.close()
        } catch (_: Exception) {}
    }

    @Synchronized private fun drop() { connected = false; try { sock?.close() } catch (_: Exception) {}; sock = null; out = null }

    /** Would the native server take this command? (No side effects.) */
    fun accepts(j: JSONObject): Boolean {
        if (!connected) return false
        return when (j.optString("t")) {
            "move", "click", "rclick", "scroll", "hscroll", "down", "up", "bright", "launch", "url" -> true
            "combo" -> ver >= 4
            // u = the characters to delete are non-ASCII: a real Backspace would remove whole grapheme clusters, so Accessibility deletes exact characters
            "key" -> !j.optBoolean("u", false) &&
                j.optString("k") in listOf("back", "home", "recents", "backspace", "enter", "del", "tab", "esc", "left", "right", "up", "down", "home_line", "end_line")
            "text" -> j.optString("s").all { it.code in 32..126 || it == '\n' }   // other characters: Accessibility fallback
            else -> false
        }
    }

    /** @return true when the native server handled the command. */
    @Synchronized fun forward(j: JSONObject): Boolean {
        if (!accepts(j)) return false
        val o = out ?: return false
        o.println(j.toString())
        if (o.checkError()) { drop(); return false }
        return true
    }
}
