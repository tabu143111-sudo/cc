package com.example.lanremote

import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.InputDevice
import android.view.InputEvent
import android.view.KeyCharacterMap
import android.view.KeyEvent
import android.view.MotionEvent
import org.json.JSONObject
import java.io.File
import java.lang.reflect.Method
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.SecureRandom

/**
 * Runs with ADB (shell) privileges – NOT inside the app process:
 *   CLASSPATH=<base.apk> app_process /system/bin com.example.lanremote.InputServer
 * It injects genuine mouse and keyboard input events into Android (the same path a USB/Bluetooth mouse and keyboard use),
 * so the host shows the system mouse pointer and behaves like a physical mouse + keyboard is attached.
 * Only the LAN Remote app can talk to it: a random token is written to the app's own external-files folder.
 */
object InputServer {
    private const val PKG = "com.example.lanremote"
    private const val PORT = 8766
    private var manager: Any? = null
    private var inject: Method? = null
    private var w = 1080; private var h = 2400
    private var px = 540f; private var py = 1200f
    private var downTime = 0L
    private var lastDisplay = 0L
    private var dragging = false
    private var remX = 0f; private var remY = 0f      // pointer movement received but not yet injected

    @JvmStatic fun main(args: Array<String>) {
        initInput()
        // Movement is not injected in big jumps: every 8 ms a share of the pending distance is applied, so the pointer
        // glides smoothly even when the network delivers the touch deltas unevenly.
        Thread { while (true) { try { Thread.sleep(8) } catch (_: Exception) {}; try { synchronized(InputServer) { stepMove() } } catch (_: Exception) {} } }
            .apply { isDaemon = true; start() }
        val ss = try { ServerSocket(PORT, 4, InetAddress.getByName("127.0.0.1")) }
        catch (e: Exception) { println("Input server already running (port $PORT busy)."); return }
        val token = ByteArray(16).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02x".format(it) }
        try {
            val dir = File("/sdcard/Android/data/$PKG/files"); dir.mkdirs()
            val f = File(dir, "native_token"); f.writeText(token); f.setReadable(true, false)
        } catch (e: Exception) { println("Could not write token: $e") }
        // the shell may grant the app "modify system settings", so host brightness works without any manual step
        Thread { try { Runtime.getRuntime().exec(arrayOf("sh", "-c", "cmd appops set $PKG WRITE_SETTINGS allow; cmd appops set $PKG SYSTEM_ALERT_WINDOW allow")).waitFor() } catch (_: Exception) {} }.start()
        println("LAN Remote native input server running on 127.0.0.1:$PORT")
        while (true) { val s = ss.accept(); Thread { serve(s, token) }.start() }
    }

    private fun serve(s: Socket, token: String) {
        try {
            s.use {
                val r = it.getInputStream().bufferedReader()
                s.soTimeout = 3000; s.tcpNoDelay = true
                if (r.readLine() != token) return
                s.soTimeout = 0
                it.getOutputStream().apply { write("ok3\n".toByteArray()); flush() }
                while (true) {
                    val l = r.readLine() ?: break
                    try { synchronized(this) { handle(JSONObject(l)) } } catch (_: Exception) {}
                }
                try { synchronized(this) { if (dragging) handle(JSONObject().put("t", "up")) } } catch (_: Exception) {}
            }
        } catch (_: Exception) {}
    }

    private fun handle(j: JSONObject) {
        when (j.getString("t")) {
            "move" -> { remX += j.getDouble("dx").toFloat(); remY += j.getDouble("dy").toFloat() }
            "down" -> if (!dragging) { flushMove(); dragging = true; downTime = SystemClock.uptimeMillis()
                        send(motion(MotionEvent.ACTION_DOWN, MotionEvent.BUTTON_PRIMARY))
                        send(motion(MotionEvent.ACTION_BUTTON_PRESS, MotionEvent.BUTTON_PRIMARY, 0f, MotionEvent.BUTTON_PRIMARY)) }
            "up" -> if (dragging) { flushMove(); dragging = false
                        send(motion(MotionEvent.ACTION_BUTTON_RELEASE, 0, 0f, MotionEvent.BUTTON_PRIMARY))
                        send(motion(MotionEvent.ACTION_UP, 0)); send(motion(MotionEvent.ACTION_HOVER_MOVE, 0)) }
            "hscroll" -> send(motion(MotionEvent.ACTION_SCROLL, 0, 0f, 0, j.getDouble("dx").toFloat() * (3f + minOf(Math.abs(j.getDouble("dx").toFloat()), 40f) / 8f) / 100f))
            "click" -> click(MotionEvent.BUTTON_PRIMARY)
            "rclick" -> click(MotionEvent.BUTTON_SECONDARY)
            "scroll" -> { val dy = j.getDouble("dy").toFloat()
                          val accel = 3f + minOf(Math.abs(dy), 40f) / 8f
                          send(motion(MotionEvent.ACTION_SCROLL, 0, -dy * accel / 100f)) }
            "key" -> when (j.getString("k")) {
                "back" -> key(KeyEvent.KEYCODE_BACK); "home" -> key(KeyEvent.KEYCODE_HOME)
                "recents" -> key(KeyEvent.KEYCODE_APP_SWITCH)
                "enter" -> key(KeyEvent.KEYCODE_ENTER)
                else -> KEYS[j.getString("k")]?.let { code -> repeat(j.optInt("c", 1).coerceIn(1, 500)) { key(code) } }
            }
            "text" -> typeText(j.getString("s"))
            "bright" -> setBright(j.getInt("v").coerceIn(1, 65535))
            "launch" -> j.getString("p").let { p -> if (PKG_RE.matches(p)) bg("monkey", "-p", p, "-c", "android.intent.category.LAUNCHER", "1") }
            "url" -> j.getString("u").let { u -> if (u.startsWith("https://") || u.startsWith("http://")) bg("am", "start", "-a", "android.intent.action.VIEW", "-d", u) }
        }
    }

    private val KEYS = mapOf("backspace" to KeyEvent.KEYCODE_DEL, "del" to KeyEvent.KEYCODE_FORWARD_DEL, "tab" to KeyEvent.KEYCODE_TAB,
        "esc" to KeyEvent.KEYCODE_ESCAPE, "left" to KeyEvent.KEYCODE_DPAD_LEFT, "right" to KeyEvent.KEYCODE_DPAD_RIGHT,
        "up" to KeyEvent.KEYCODE_DPAD_UP, "down" to KeyEvent.KEYCODE_DPAD_DOWN, "home_line" to KeyEvent.KEYCODE_MOVE_HOME,
        "end_line" to KeyEvent.KEYCODE_MOVE_END)

    // ---------- shortcuts: no shell string is ever built from received data (argument arrays only) ----------
    private val PKG_RE = Regex("[A-Za-z0-9_.]+")
    private fun bg(vararg cmd: String) = Thread {
        try { val p = ProcessBuilder(*cmd).redirectErrorStream(true).start(); p.inputStream.bufferedReader().readText(); p.waitFor() } catch (_: Exception) {}
    }.start()

    // ---------- screen brightness (shell may write system settings; the app itself needs WRITE_SETTINGS) ----------
    private val briLock = Object()
    private var briWant = -1
    private var briBusy = false
    private fun setBright(v: Int) {
        synchronized(briLock) { briWant = v; if (briBusy) return; briBusy = true }
        Thread {
            while (true) {
                var x = -1
                synchronized(briLock) { x = briWant; briWant = -1; if (x < 0) briBusy = false }
                if (x < 0) break
                try {
                    Runtime.getRuntime().exec(arrayOf("sh", "-c",
                        "(cmd settings put system screen_brightness_mode 0; cmd settings put system screen_brightness $x) >/dev/null 2>&1 || " +
                        "(settings put system screen_brightness_mode 0; settings put system screen_brightness $x)")).waitFor()
                } catch (_: Exception) {}
            }
        }.start()
    }

    // ---------- smooth pointer movement ----------
    private fun moveBy(sx: Float, sy: Float) {
        refreshDisplay()
        px = (px + sx).coerceIn(0f, w - 1f); py = (py + sy).coerceIn(0f, h - 1f)
        if (dragging) send(motion(MotionEvent.ACTION_MOVE, MotionEvent.BUTTON_PRIMARY)) else send(motion(MotionEvent.ACTION_HOVER_MOVE, 0))
    }
    private fun stepMove() {
        if (remX == 0f && remY == 0f) return
        val sx = if (Math.abs(remX) < 1.5f) remX else remX * 0.45f
        val sy = if (Math.abs(remY) < 1.5f) remY else remY * 0.45f
        remX -= sx; remY -= sy
        moveBy(sx, sy)
    }
    /** Applies everything still pending at once (before a click / press / release, so they land at the right spot). */
    private fun flushMove() {
        if (remX == 0f && remY == 0f) return
        val sx = remX; val sy = remY; remX = 0f; remY = 0f
        moveBy(sx, sy)
    }

    // ---------- mouse ----------
    private fun click(button: Int) {
        flushMove()
        downTime = SystemClock.uptimeMillis()
        send(motion(MotionEvent.ACTION_DOWN, button))
        send(motion(MotionEvent.ACTION_BUTTON_PRESS, button, 0f, button))
        try { Thread.sleep(40) } catch (_: Exception) {}
        send(motion(MotionEvent.ACTION_BUTTON_RELEASE, 0, 0f, button))
        send(motion(MotionEvent.ACTION_UP, 0))
        send(motion(MotionEvent.ACTION_HOVER_MOVE, 0))
    }

    private fun motion(action: Int, buttons: Int, vscroll: Float = 0f, actionButton: Int = 0, hscroll: Float = 0f): MotionEvent {
        val now = SystemClock.uptimeMillis()
        val pp = MotionEvent.PointerProperties().apply { id = 0; toolType = MotionEvent.TOOL_TYPE_MOUSE }
        val cx = px; val cy = py
        val pc = MotionEvent.PointerCoords().apply {
            x = cx; y = cy; pressure = if (buttons != 0) 1f else 0f; size = 1f
            if (vscroll != 0f) setAxisValue(MotionEvent.AXIS_VSCROLL, vscroll)
            if (hscroll != 0f) setAxisValue(MotionEvent.AXIS_HSCROLL, hscroll)
        }
        val e = MotionEvent.obtain(if (downTime == 0L) now else downTime, now, action, 1, arrayOf(pp), arrayOf(pc),
            0, buttons, 1f, 1f, 0, 0, InputDevice.SOURCE_MOUSE, 0)
        if (actionButton != 0) try { MotionEvent::class.java.getMethod("setActionButton", Int::class.javaPrimitiveType).invoke(e, actionButton) } catch (_: Exception) {}
        return e
    }

    // ---------- keyboard ----------
    private fun key(code: Int, meta: Int = 0) {
        val now = SystemClock.uptimeMillis()
        send(KeyEvent(now, now, KeyEvent.ACTION_DOWN, code, 0, meta, KeyCharacterMap.VIRTUAL_KEYBOARD, 0, 0, InputDevice.SOURCE_KEYBOARD))
        send(KeyEvent(now, SystemClock.uptimeMillis(), KeyEvent.ACTION_UP, code, 0, meta, KeyCharacterMap.VIRTUAL_KEYBOARD, 0, 0, InputDevice.SOURCE_KEYBOARD))
    }

    private fun typeText(s: String) {
        val evs = KeyCharacterMap.load(KeyCharacterMap.VIRTUAL_KEYBOARD).getEvents(s.toCharArray()) ?: return
        for (e in evs) send(KeyEvent(e.downTime, e.eventTime, e.action, e.keyCode, e.repeatCount, e.metaState,
            KeyCharacterMap.VIRTUAL_KEYBOARD, e.scanCode, e.flags, InputDevice.SOURCE_KEYBOARD))
    }

    // ---------- plumbing ----------
    private fun send(e: InputEvent) { try { inject?.invoke(manager, e, 0) } catch (_: Exception) {} finally { if (e is MotionEvent) e.recycle() } }

    private fun initInput() {
        for (name in listOf("android.hardware.input.InputManagerGlobal", "android.hardware.input.InputManager")) {
            try {
                val c = Class.forName(name)
                val m = c.getDeclaredMethod("getInstance").apply { isAccessible = true }.invoke(null)
                inject = m!!.javaClass.getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
                manager = m; break
            } catch (_: Exception) {}
        }
        refreshDisplay(true)
        px = w / 2f; py = h / 2f   // same start point as the overlay cursor
    }

    private fun refreshDisplay(force: Boolean = false) {
        val now = SystemClock.uptimeMillis()
        if (!force && now - lastDisplay < 1500) return
        lastDisplay = now
        try {
            val g = Class.forName("android.hardware.display.DisplayManagerGlobal").getMethod("getInstance").invoke(null)
            val d = g!!.javaClass.getMethod("getRealDisplay", Int::class.javaPrimitiveType).invoke(g, 0) as android.view.Display
            val dm = DisplayMetrics(); d.getRealMetrics(dm)
            if (dm.widthPixels > 0) { w = dm.widthPixels; h = dm.heightPixels; px = px.coerceIn(0f, w - 1f); py = py.coerceIn(0f, h - 1f) }
        } catch (_: Exception) {}
    }
}
