package com.example.lanremote

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.provider.Settings
import java.net.NetworkInterface
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Starts the native [InputServer] without a PC.
 * 1. WRITE_SECURE_SETTINGS (already granted) lets this app switch Wireless debugging on by itself.
 * 2. The debugging port is found through mDNS (_adb-tls-connect).
 * 3. Termux (already paired once with `adb pair`) runs `adb connect` + the start command on this same device.
 * Needs: Termux with android-tools, `allow-external-apps=true` in ~/.termux/termux.properties, and the
 * "Run commands in Termux" permission for this app.
 */
object NativeStarter {
    private const val PKG = "com.example.lanremote"
    const val TERMUX_PERM = "com.termux.permission.RUN_COMMAND"
    @Volatile var status = ""
    @Volatile var busy = false
        private set

    fun termuxInstalled(ctx: Context) = try { ctx.packageManager.getPackageInfo("com.termux", 0); true } catch (_: Exception) { false }
    fun termuxAllowed(ctx: Context) = ctx.checkSelfPermission(TERMUX_PERM) == PackageManager.PERMISSION_GRANTED

    fun start(ctx0: Context) {
        val ctx = ctx0.applicationContext
        synchronized(this) { if (busy) return; busy = true }
        Thread {
            try { run(ctx) } catch (e: Exception) { status = "Failed: ${e.message}" } finally { busy = false }
        }.start()
    }

    private fun run(ctx: Context) {
        NativeInput.connect(ctx)
        if (NativeInput.connected) { status = "Native server is running"; return }
        if (!AutoGrant.canWrite(ctx)) { status = "Grant WRITE_SECURE_SETTINGS first (setup guide)"; return }
        if (!termuxInstalled(ctx)) { status = "Termux is not installed on this device"; return }
        if (!termuxAllowed(ctx)) { status = "Allow \"Run commands in Termux\" for this app"; return }
        status = "Turning on Wireless debugging…"
        val cr = ctx.contentResolver
        Settings.Global.putInt(cr, "development_settings_enabled", 1)
        Settings.Global.putInt(cr, "adb_wifi_enabled", 1)
        status = "Finding the debugging port…"
        val port = findPort(ctx)
        if (port <= 0) { status = "Wireless debugging port not found (is Wi-Fi connected?)"; return }
        status = "Starting the server through Termux…"
        runTermux(ctx, port)
        repeat(25) {
            Thread.sleep(1000)
            NativeInput.connect(ctx)
            if (NativeInput.connected) { status = "Native server is running"; return }
        }
        status = "Server did not start. In Termux make sure adb is paired and allow-external-apps=true is set."
    }

    private fun localAddrs(): Set<String> = try {
        NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }.mapNotNull { it.hostAddress }.toSet()
    } catch (_: Exception) { emptySet() }

    private fun findPort(ctx: Context): Int {
        val nsd = ctx.getSystemService(NsdManager::class.java)
        val local = localAddrs()
        val latch = CountDownLatch(1)
        var port = 0
        val dl = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(t: String) {}
            override fun onStartDiscoveryFailed(t: String, e: Int) { latch.countDown() }
            override fun onStopDiscoveryFailed(t: String, e: Int) {}
            override fun onDiscoveryStopped(t: String) {}
            override fun onServiceLost(s: NsdServiceInfo) {}
            override fun onServiceFound(s: NsdServiceInfo) {
                @Suppress("DEPRECATION")
                nsd.resolveService(s, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(s: NsdServiceInfo, e: Int) {}
                    override fun onServiceResolved(r: NsdServiceInfo) {
                        val h = r.host
                        if (h != null && (h.isLoopbackAddress || local.contains(h.hostAddress))) { port = r.port; latch.countDown() }
                    }
                })
            }
        }
        nsd.discoverServices("_adb-tls-connect._tcp", NsdManager.PROTOCOL_DNS_SD, dl)
        latch.await(20, TimeUnit.SECONDS)
        try { nsd.stopServiceDiscovery(dl) } catch (_: Exception) {}
        return port
    }

    private fun runTermux(ctx: Context, port: Int) {
        val a = "127.0.0.1:$port"
        val script = listOf(
            "export PATH=\"\$PATH:/data/data/com.termux/files/usr/bin\"",
            "adb connect $a",
            "adb -s $a shell \"mkdir -p /sdcard/Android/data/$PKG/files; CLASSPATH=\\\$(pm path $PKG | head -n 1 | cut -d: -f2) nohup app_process /system/bin $PKG.InputServer > /data/local/tmp/lanremote.log 2>&1 &\"",
            "sleep 2",
            "adb disconnect $a"
        ).joinToString("\n")
        val i = Intent("com.termux.RUN_COMMAND")
            .setClassName("com.termux", "com.termux.app.RunCommandService")
            .putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash")
            .putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-c", script))
            .putExtra("com.termux.RUN_COMMAND_BACKGROUND", true)
        ctx.startForegroundService(i)
    }
}
