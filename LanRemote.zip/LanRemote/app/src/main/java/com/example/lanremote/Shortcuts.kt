package com.example.lanremote

import android.content.SharedPreferences
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

/** One user-defined quick action. type: app · url · text · sys · media. [arg] = package / address / text / action key. */
data class Shortcut(val id: String, val type: String, val name: String, val icon: String, val arg: String = "", val flag: Boolean = false)
data class Opt(val key: String, val label: String, val icon: String)
data class HostApp(val pkg: String, val label: String)

val SYS_ACTIONS = listOf(Opt("home", "Home", "🏠"), Opt("back", "Back", "◀️"), Opt("recents", "Recents", "🗂️"),
    Opt("notif", "Notifications", "🔔"), Opt("quick", "Quick settings", "⚙️"), Opt("drawer", "App drawer", "🔳"),
    Opt("screenshot", "Screenshot", "📸"), Opt("lock", "Lock screen", "🔒"), Opt("power", "Power menu", "⏻"))
val MEDIA_ACTIONS = listOf(Opt("play_pause", "Play / pause", "⏯️"), Opt("next", "Next", "⏭️"), Opt("prev", "Previous", "⏮️"), Opt("mute", "Mute", "🔇"))
private val TYPES = listOf("app" to "📱 App", "url" to "🌐 Website", "text" to "⌨️ Text", "sys" to "🧭 System", "media" to "🎵 Media")
private val EMOJIS = listOf("📱", "🌐", "▶️", "🎵", "📺", "🎮", "📷", "💬", "📧", "🗺️", "⚙️", "🏠", "⭐", "🔥", "📝", "🔔", "🛒", "📁")

object ShortcutStore {
    val items = mutableStateListOf<Shortcut>()
    private var loaded = false

    fun newId() = System.currentTimeMillis().toString(36) + (0..999).random()

    private fun defaults() = listOf(
        Shortcut(newId(), "sys", "Home", "🏠", "home"), Shortcut(newId(), "sys", "Back", "◀️", "back"),
        Shortcut(newId(), "sys", "Recents", "🗂️", "recents"), Shortcut(newId(), "sys", "Notifications", "🔔", "notif"),
        Shortcut(newId(), "sys", "Screenshot", "📸", "screenshot"),
        Shortcut(newId(), "app", "YouTube", "▶️", "com.google.android.youtube"), Shortcut(newId(), "app", "Chrome", "🌐", "com.android.chrome"))

    fun load(p: SharedPreferences) {
        if (loaded) return
        loaded = true
        val raw = p.getString("shortcuts", null)
        if (raw == null) { items.addAll(defaults()); save(p); return }
        try {
            val a = JSONArray(raw)
            for (i in 0 until a.length()) a.getJSONObject(i).let {
                items.add(Shortcut(it.getString("id"), it.getString("type"), it.getString("name"), it.optString("icon", "⭐"), it.optString("arg"), it.optBoolean("flag")))
            }
        } catch (_: Exception) { items.clear(); items.addAll(defaults()) }
    }

    fun save(p: SharedPreferences) {
        val a = JSONArray()
        items.forEach { a.put(JSONObject().put("id", it.id).put("type", it.type).put("name", it.name).put("icon", it.icon).put("arg", it.arg).put("flag", it.flag)) }
        p.edit().putString("shortcuts", a.toString()).apply()
    }
}

/** Runs a shortcut ON THE HOST (the controlled device). */
fun runShortcut(c: Client, s: Shortcut) {
    when (s.type) {
        "app" -> c.send("launch", "p" to s.arg)
        "url" -> c.send("url", "u" to s.arg)
        "text" -> { c.typeText(s.arg); if (s.flag) c.special("enter") }
        "sys" -> c.send("key", "k" to s.arg)
        "media" -> if (s.arg == "mute") c.send("vol", "k" to "mute") else c.send("media", "k" to s.arg)
    }
}

@Composable fun ShortcutDrawer(c: Client, close: () -> Unit) {
    var editing by remember { mutableStateOf<Shortcut?>(null) }
    var adding by remember { mutableStateOf(false) }
    ModalDrawerSheet(modifier = Modifier.width(310.dp), drawerContainerColor = Bg1) {
        Column(Modifier.fillMaxHeight().padding(14.dp)) {
            Text("Shortcuts", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
            Text("Tap = run on the host · long-press = edit", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            LazyVerticalGrid(GridCells.Fixed(3), Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(ShortcutStore.items, key = { it.id }) { s -> ShortcutTile(s, { runShortcut(c, s); close() }, { editing = s }) }
                item {
                    Column(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(16.dp)).border(1.dp, Accent2, RoundedCornerShape(16.dp))
                        .clickable { adding = true }, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Text("+", fontSize = 28.sp, color = Accent2, fontWeight = FontWeight.Bold)
                        Text("Add", fontSize = 11.sp, color = Accent2)
                    }
                }
            }
        }
    }
    if (adding) ShortcutEditor(c, null) { adding = false }
    editing?.let { ShortcutEditor(c, it) { editing = null } }
}

@Composable fun ShortcutTile(s: Shortcut, onRun: () -> Unit, onEdit: () -> Unit) {
    val h = LocalHapticFeedback.current
    Column(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(16.dp)).background(CardC).border(1.dp, Edge, RoundedCornerShape(16.dp))
        .pointerInput(s) {
            detectTapGestures(onTap = { h.performHapticFeedback(HapticFeedbackType.TextHandleMove); onRun() },
                onLongPress = { h.performHapticFeedback(HapticFeedbackType.LongPress); onEdit() })
        }.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(s.icon, fontSize = 26.sp)
        Spacer(Modifier.height(4.dp))
        Text(s.name, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
    }
}

@Composable private fun Chip(label: String, on: Boolean, onClick: () -> Unit) {
    Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (on) Color.White else Muted,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(if (on) Accent else Edge).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 7.dp))
}

private fun fixUrl(u: String): String { val t = u.trim(); return if (t.startsWith("http://") || t.startsWith("https://")) t else "https://$t" }

@Composable fun ShortcutEditor(c: Client, orig: Shortcut?, onClose: () -> Unit) {
    var type by remember { mutableStateOf(orig?.type ?: "app") }
    var name by remember { mutableStateOf(orig?.name ?: "") }
    var icon by remember { mutableStateOf(orig?.icon ?: "📱") }
    var arg by remember { mutableStateOf(orig?.arg ?: "") }
    var flag by remember { mutableStateOf(orig?.flag ?: false) }
    var picker by remember { mutableStateOf(false) }
    if (picker) AppPicker(c, { picker = false }) { a -> arg = a.pkg; if (name.isBlank()) name = a.label; picker = false }
    fun pickOpt(o: Opt) {
        if (name.isBlank() || (SYS_ACTIONS + MEDIA_ACTIONS).any { it.label == name }) name = o.label
        arg = o.key; icon = o.icon
    }
    fun save() {
        val ns = Shortcut(orig?.id ?: ShortcutStore.newId(), type, name.trim(), icon, if (type == "url") fixUrl(arg) else if (type == "text") arg else arg.trim(), flag)
        if (orig == null) ShortcutStore.items.add(ns) else { val i = ShortcutStore.items.indexOfFirst { it.id == orig.id }; if (i >= 0) ShortcutStore.items[i] = ns }
        ShortcutStore.save(appPrefs); onClose()
    }
    fun move(d: Int) {
        val i = ShortcutStore.items.indexOfFirst { it.id == orig?.id }; val j = i + d
        if (i >= 0 && j in ShortcutStore.items.indices) { val t = ShortcutStore.items[i]; ShortcutStore.items[i] = ShortcutStore.items[j]; ShortcutStore.items[j] = t; ShortcutStore.save(appPrefs) }
    }
    AlertDialog(onDismissRequest = onClose,
        title = { Text(if (orig == null) "New shortcut" else "Edit shortcut", fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for ((k, l) in TYPES) Chip(l, type == k) { if (type != k) { type = k; arg = ""; flag = false } }
                }
                OutlinedTextField(name, { name = it.take(24) }, Modifier.fillMaxWidth(), label = { Text("Name") }, singleLine = true, shape = RoundedCornerShape(14.dp), colors = tfColors())
                Row(Modifier.horizontalScroll(rememberScrollState())) {
                    for (e in EMOJIS) Text(e, fontSize = 22.sp, modifier = Modifier.clip(CircleShape).background(if (icon == e) Accent2.copy(alpha = 0.3f) else Color.Transparent)
                        .clickable { icon = e }.padding(6.dp))
                }
                when (type) {
                    "app" -> {
                        OutlinedTextField(arg, { arg = it.trim() }, Modifier.fillMaxWidth(), label = { Text("Package name") }, singleLine = true, shape = RoundedCornerShape(14.dp), colors = tfColors())
                        GradBtn("Pick an app from the host") { picker = true }
                    }
                    "url" -> OutlinedTextField(arg, { arg = it }, Modifier.fillMaxWidth(), label = { Text("Address, e.g. youtube.com") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri), shape = RoundedCornerShape(14.dp), colors = tfColors())
                    "text" -> {
                        OutlinedTextField(arg, { arg = it }, Modifier.fillMaxWidth(), label = { Text("Text typed on the host") }, shape = RoundedCornerShape(14.dp), colors = tfColors())
                        Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(flag, { flag = it }); Text("Press Enter afterwards") }
                    }
                    "sys" -> Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        SYS_ACTIONS.forEach { o -> Chip(o.icon + " " + o.label, arg == o.key) { pickOpt(o) } }
                    }
                    "media" -> Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        MEDIA_ACTIONS.forEach { o -> Chip(o.icon + " " + o.label, arg == o.key) { pickOpt(o) } }
                    }
                }
                if (orig != null) Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Chip("◀ Move earlier", false) { move(-1) }; Chip("Move later ▶", false) { move(1) }
                }
            }
        },
        confirmButton = { TextButton({ save() }, enabled = name.isNotBlank() && arg.isNotBlank()) { Text("Save") } },
        dismissButton = {
            Row {
                if (orig != null) TextButton({ ShortcutStore.items.removeAll { it.id == orig.id }; ShortcutStore.save(appPrefs); onClose() }) { Text("Delete", color = Bad) }
                TextButton(onClose) { Text("Cancel") }
            }
        })
}

/** Lists the apps installed on the host (asked live over the connection) so one can be chosen without typing a package name. */
@Composable fun AppPicker(c: Client, onClose: () -> Unit, onPick: (HostApp) -> Unit) {
    var q by remember { mutableStateOf("") }
    var timedOut by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { c.requestApps(); delay(6000); timedOut = true }
    val list = c.apps.filter { q.isBlank() || it.label.contains(q, true) || it.pkg.contains(q, true) }
    AlertDialog(onDismissRequest = onClose, title = { Text("Apps on the host", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), label = { Text("Search") }, singleLine = true, shape = RoundedCornerShape(14.dp), colors = tfColors())
                Spacer(Modifier.height(8.dp))
                if (c.apps.isEmpty()) Text(if (timedOut) "No answer. Install the latest build on the host and keep the host running." else "Loading…", color = Muted, fontSize = 13.sp)
                LazyColumn(Modifier.heightIn(max = 340.dp)) {
                    items(list, key = { it.pkg }) { a ->
                        Row(Modifier.fillMaxWidth().clickable { onPick(a) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(34.dp).clip(CircleShape).background(Accent.copy(alpha = 0.25f)), contentAlignment = Alignment.Center) {
                                Text(a.label.take(1).uppercase(), fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(a.label, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(a.pkg, fontSize = 11.sp, color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        }, confirmButton = {}, dismissButton = { TextButton(onClose) { Text("Close") } })
}
