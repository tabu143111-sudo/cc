package com.example.lanremote

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private const val PKG = "com.example.lanremote"
private val Slate = Brush.linearGradient(listOf(Color(0xFF334155), Color(0xFF475569)))

/** Command box with a Copy button. */
@Composable private fun Cmd(text: String) {
    val cb = LocalClipboardManager.current
    val ctx = LocalContext.current
    Column(Modifier.fillMaxWidth().padding(top = 8.dp).clip(RoundedCornerShape(12.dp)).background(Color(0x22000000))
        .border(1.dp, Edge, RoundedCornerShape(12.dp)).padding(12.dp)) {
        SelectionContainer { Text(text, fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = Accent2) }
        Text("Copy", color = Accent, fontWeight = FontWeight.Bold, fontSize = 13.sp,
            modifier = Modifier.padding(top = 8.dp).clip(RoundedCornerShape(8.dp)).clickable {
                cb.setText(AnnotatedString(text)); Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
            }.padding(vertical = 4.dp, horizontal = 2.dp))
    }
}

@Composable private fun StepTitle(n: Int, title: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(28.dp).clip(CircleShape).background(Grad), contentAlignment = Alignment.Center) {
            Text("$n", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White) }
        Spacer(Modifier.width(10.dp))
        Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
    Spacer(Modifier.height(8.dp))
}

@Composable private fun Body(t: String) = Text(t, color = Muted, fontSize = 13.sp, lineHeight = 19.sp)

@Composable private fun Status(label: String, ok: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 3.dp)) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(if (ok) Good else Bad))
        Spacer(Modifier.width(10.dp)); Text(label, fontSize = 14.sp)
    }
}

@Composable fun GuideScreen(onBack: () -> Unit) = Screen {
    val ctx = LocalContext.current
    var auto by remember { mutableStateOf(false) }
    var native by remember { mutableStateOf(false) }
    var acc by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { while (true) { auto = AutoGrant.canWrite(ctx); native = NativeInput.connected
        acc = RemoteAccess.instance != null; delay(1000) } }

    val ip = remember { hostIp().takeIf { it.contains('.') } ?: "<IP>" }
    var pairAddr by remember { mutableStateOf("$ip:") }
    var connAddr by remember { mutableStateOf("$ip:") }
    fun addr(v: String) = if (v.trim().endsWith(":") || v.isBlank()) "$ip:PORT" else v.trim()

    Header("Setup guide", "Grant permissions with Wireless debugging", onBack)
    Column(Modifier.padding(horizontal = 20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Panel {
            Label("STATUS (LIVE)"); Spacer(Modifier.height(6.dp))
            Status(if (auto) "Permanent access: active" else "Permanent access: not granted yet", auto)
            Status(if (acc) "Mouse & keyboard (Accessibility): on" else "Mouse & keyboard (Accessibility): off", acc)
            Status(if (native) "Native mouse & keyboard: running" else "Native mouse & keyboard: not running (optional)", native)
            Spacer(Modifier.height(8.dp))
            Body("This guide is for the device that will be CONTROLLED (the host). You need a second phone with Termux, or a PC with ADB, " +
                "on the same Wi-Fi. You only do steps 1–5 once. Step 6 is optional and must be repeated after every reboot.")
        }

        Panel {
            StepTitle(1, "Install ADB on the other phone")
            Body("On the second phone install Termux from F-Droid (the Play Store version is outdated), open it and run:")
            Cmd("pkg update && pkg install android-tools")
            Spacer(Modifier.height(10.dp))
            GradBtn("Open Termux on this device", brush = Slate) {
                val i = ctx.packageManager.getLaunchIntentForPackage("com.termux")
                if (i != null) ctx.startActivity(i) else Toast.makeText(ctx, "Termux is not installed here", Toast.LENGTH_SHORT).show()
            }
            Body("\nUsing a PC instead? Install Android platform-tools and use the same adb commands below.")
        }

        Panel {
            StepTitle(2, "Turn on Wireless debugging (this device)")
            Body("Open Developer options and switch on Wireless debugging. If Developer options is hidden: Settings → About → tap Build number 7 times.")
            Spacer(Modifier.height(10.dp))
            GradBtn("Open Developer options", brush = Slate) {
                try { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) }
                catch (_: Exception) { ctx.startActivity(Intent(Settings.ACTION_DEVICE_INFO_SETTINGS)) } }
        }

        Panel {
            StepTitle(3, "Pair")
            Body("Tap Wireless debugging → Pair device with pairing code. Keep that dialog open. Type the IP address & Port from the dialog " +
                "(the pairing port), then run the command in Termux and enter the 6-digit code when asked.")
            OutlinedTextField(pairAddr, { pairAddr = it.filter { c -> !c.isWhitespace() } }, Modifier.fillMaxWidth().padding(top = 10.dp),
                label = { Text("Pairing IP:port") }, singleLine = true, shape = RoundedCornerShape(14.dp), colors = tfColors())
            Cmd("adb pair ${addr(pairAddr)}")
            Body("\nWait for \"Successfully paired\".")
        }

        Panel {
            StepTitle(4, "Connect")
            Body("Close the dialog. On the main Wireless debugging screen copy the IP address & Port (a different port than pairing).")
            OutlinedTextField(connAddr, { connAddr = it.filter { c -> !c.isWhitespace() } }, Modifier.fillMaxWidth().padding(top = 10.dp),
                label = { Text("Connect IP:port") }, singleLine = true, shape = RoundedCornerShape(14.dp), colors = tfColors())
            Cmd("adb connect ${addr(connAddr)}")
            Body("\nRun each command on its own line. Don't paste several at once.")
        }

        Panel {
            StepTitle(5, "Grant permanent access")
            Cmd("adb shell pm grant $PKG android.permission.WRITE_SECURE_SETTINGS")
            Body("\nNo output means success. The status at the top turns green and the app then switches on Accessibility and notification " +
                "access by itself, also after reboots. Pairing stays valid, so next time you only need steps 2 and 4 if you ever need ADB again.")
            Spacer(Modifier.height(10.dp))
            Cmd("adb shell dumpsys deviceidle whitelist +$PKG")
            Body("\nOptional: the command above keeps the app from being killed by battery optimisation.")
        }

        Panel {
            StepTitle(6, "Optional: native mouse pointer")
            Body("Injects real mouse and keyboard events, so the pointer can reach the navigation bar. Run these two in Termux:")
            Cmd("adb shell \"mkdir -p /sdcard/Android/data/$PKG/files\"")
            Cmd("adb shell \"CLASSPATH=\\\$(pm path $PKG | head -n 1 | cut -d: -f2) nohup app_process /system/bin $PKG.InputServer > /data/local/tmp/lanremote.log 2>&1 &\"")
            Body("\nCheck it started:")
            Cmd("adb shell cat /data/local/tmp/lanremote.log")
            Body("\nYou should see \"native input server running\". Then in this app tap Stop host and Start host. " +
                "It stops when the device reboots: reconnect (steps 2 and 4) and run the second command again.")
        }

        Panel {
            Label("TROUBLESHOOTING"); Spacer(Modifier.height(6.dp))
            Body("• Pairing fails: both devices must be on the same Wi-Fi, and the pairing dialog must still be open.\n" +
                "• Connect fails: the connect port changes when Wireless debugging is toggled. Re-read it on the main screen.\n" +
                "• \"bash: !: event not found\": run  set +H  first.\n" +
                "• \"Unknown package\": install this app on the host first.\n" +
                "• SecurityException on grant: on Xiaomi/Poco/Honor enable \"USB debugging (Security settings)\" in Developer options.\n" +
                "• Server says port busy: it is already running.")
        }
        Spacer(Modifier.height(16.dp))
    }
}
