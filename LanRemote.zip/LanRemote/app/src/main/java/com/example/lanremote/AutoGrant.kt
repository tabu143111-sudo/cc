package com.example.lanremote

import android.Manifest
import android.content.ComponentName
import android.content.ContentResolver
import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings

/**
 * Once WRITE_SECURE_SETTINGS has been granted over ADB (see adb_setup.bat / adb_setup.sh) the app can switch on its own
 * Accessibility service (mouse + keyboard) and Notification listener (media info) – permanently, and again after reboots.
 */
object AutoGrant {
    private const val PKG = "com.example.lanremote"
    private val A11Y = ComponentName(PKG, "$PKG.RemoteAccess")
    private val NL = ComponentName(PKG, "$PKG.MediaListener")

    fun canWrite(ctx: Context) = ctx.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED

    /** @param force switch the Accessibility service off and on again (used when the system has stopped it). */
    fun ensure(ctx: Context, force: Boolean = false): Boolean {
        if (!canWrite(ctx)) return false
        return try {
            val cr = ctx.contentResolver
            if (force) remove(cr, "enabled_accessibility_services", A11Y)
            add(cr, "enabled_accessibility_services", A11Y)
            Settings.Secure.putInt(cr, "accessibility_enabled", 1)
            add(cr, "enabled_notification_listeners", NL)
            true
        } catch (_: Exception) { false }
    }

    private fun parts(cr: ContentResolver, key: String) =
        (Settings.Secure.getString(cr, key) ?: "").split(":").filter { it.isNotBlank() }

    private fun has(list: List<String>, c: ComponentName) = list.any { ComponentName.unflattenFromString(it) == c }

    private fun add(cr: ContentResolver, key: String, c: ComponentName) {
        val l = parts(cr, key)
        if (!has(l, c)) Settings.Secure.putString(cr, key, (l + c.flattenToString()).joinToString(":"))
    }

    private fun remove(cr: ContentResolver, key: String, c: ComponentName) {
        val l = parts(cr, key)
        if (has(l, c)) Settings.Secure.putString(cr, key, l.filter { ComponentName.unflattenFromString(it) != c }.joinToString(":"))
    }
}
