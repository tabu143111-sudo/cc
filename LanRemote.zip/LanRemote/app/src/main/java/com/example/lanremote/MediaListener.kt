package com.example.lanremote

import android.app.Notification
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.concurrent.ConcurrentHashMap

/**
 * Enabling it grants permission to read the active media session (title, art, position).
 * It also remembers the large icon of media notifications (the video / album thumbnail many players only expose there).
 */
class MediaListener : NotificationListenerService() {
    companion object { val icons = ConcurrentHashMap<String, Bitmap>() }

    override fun onListenerConnected() { try { activeNotifications?.forEach { grab(it) } } catch (_: Exception) {} }
    override fun onNotificationPosted(sbn: StatusBarNotification) = grab(sbn)

    @Suppress("DEPRECATION")
    private fun legacyIcon(n: Notification): Bitmap? = n.extras.getParcelable(Notification.EXTRA_LARGE_ICON) as? Bitmap

    private fun grab(sbn: StatusBarNotification) {
        try {
            val n = sbn.notification
            if (!n.extras.containsKey(Notification.EXTRA_MEDIA_SESSION)) return
            var bm: Bitmap? = null
            val d = n.getLargeIcon()?.loadDrawable(this)
            if (d != null) bm = if (d is BitmapDrawable) d.bitmap else if (d.intrinsicWidth > 0 && d.intrinsicHeight > 0) {
                Bitmap.createBitmap(d.intrinsicWidth, d.intrinsicHeight, Bitmap.Config.ARGB_8888).also { d.setBounds(0, 0, it.width, it.height); d.draw(Canvas(it)) }
            } else null
            if (bm == null) bm = legacyIcon(n)
            if (bm != null) icons[sbn.packageName] = bm
        } catch (_: Exception) {}
    }
}
