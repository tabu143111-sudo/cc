package com.example.lanremote

import android.app.*
import android.content.Intent
import android.media.AudioManager
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Base64
import android.content.ComponentName
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock
import java.io.ByteArrayOutputStream
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.roundToInt
import android.view.KeyEvent
import org.json.JSONObject
import java.io.PrintWriter
import java.net.ServerSocket
import java.net.Socket

class HostService : Service() {
    companion object { @Volatile var running = false; @Volatile var pin = (10_000_000..99_999_999).random().toString(); const val PORT = 8765 }
    private var server: ServerSocket? = null
    private var nsd: NsdManager? = null
    private var reg: NsdManager.RegistrationListener? = null
    private val am by lazy { getSystemService(AudioManager::class.java) }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        pin = i?.getStringExtra("pin") ?: pin
        val ch = "host"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Host", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, ch).setContentTitle("LAN Remote host running")
            .setSmallIcon(android.R.drawable.ic_media_play).build())
        if (running) return START_NOT_STICKY
        running = true
        Thread {   // keeps Accessibility / notification access switched on (works once granted via ADB)
            var lastForce = 0L
            var lastNative = -90_000L
            while (running) {
                try {
                    NativeInput.connect(this)
                    if (!NativeInput.connected && getSharedPreferences("s", 0).getBoolean("auto_native", false)
                        && SystemClock.elapsedRealtime() - lastNative > 90_000) {
                        lastNative = SystemClock.elapsedRealtime(); NativeStarter.start(this)
                    }
                    if (AutoGrant.canWrite(this)) {
                        val dead = RemoteAccess.instance == null
                        val now = SystemClock.elapsedRealtime()
                        AutoGrant.ensure(this, dead && now - lastForce > 20_000)
                        if (dead) lastForce = now
                    }
                    Thread.sleep(3000)
                } catch (_: Exception) {}
            }
        }.start()
        Thread {
            try {
                server = ServerSocket(PORT)
                registerNsd()
                while (running) { val s = server!!.accept(); Thread { serve(s) }.start() }
            } catch (_: Exception) {}
        }.start()
        return START_NOT_STICKY
    }

    private fun registerNsd() {
        nsd = getSystemService(NsdManager::class.java)
        reg = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(i: NsdServiceInfo) {}
            override fun onRegistrationFailed(i: NsdServiceInfo, e: Int) {}
            override fun onServiceUnregistered(i: NsdServiceInfo) {}
            override fun onUnregistrationFailed(i: NsdServiceInfo, e: Int) {}
        }
        val info = NsdServiceInfo().apply { serviceName = "Host-${Build.MODEL}"; serviceType = "_lanremote._tcp."; port = PORT }
        nsd?.registerService(info, NsdManager.PROTOCOL_DNS_SD, reg)
    }

    private fun serve(s: Socket) {
        val alive = AtomicBoolean(true)
        try {
            s.use {
                val r = it.getInputStream().bufferedReader()
                val w = PrintWriter(it.getOutputStream(), true)
                val salt = Crypto.salt()
                w.println(Base64.encodeToString(salt, Base64.NO_WRAP))
                val key = Crypto.key(pin, salt)
                val a = try { JSONObject(Crypto.dec(key, r.readLine() ?: return)) } catch (e: Exception) { Thread.sleep(1500); return }
                if (a.optString("t") != "auth") return
                var last = a.optLong("n")
                synchronized(w) { w.println(Crypto.enc(key, JSONObject().put("ok", true).toString())) }
                // State is pushed twice a second, and immediately after a media command (poke), so the controller
                // behaves like the native media controls.
                val sem = java.util.concurrent.Semaphore(0)
                val poke = { Thread { try { Thread.sleep(120) } catch (_: Exception) {}; sem.release() }.start() }
                Thread {
                    var lastArt = Int.MIN_VALUE
                    while (alive.get()) {
                        try {
                            val st = stateJson()
                            val ah = st.optString("art").hashCode()
                            if (st.has("art") && ah == lastArt) st.remove("art") else if (st.has("art")) lastArt = ah
                            synchronized(w) { w.println(Crypto.enc(key, st.toString())) }
                        } catch (_: Exception) {}
                        try { sem.tryAcquire(500, java.util.concurrent.TimeUnit.MILLISECONDS); sem.drainPermits() } catch (_: Exception) {}
                    }
                }.start()
                while (true) {
                    val l = r.readLine() ?: break
                    try {
                        val j = JSONObject(Crypto.dec(key, l))
                        val n = j.getLong("n"); if (n <= last) continue
                        last = n; handle(j, poke)
                    } catch (e: javax.crypto.AEADBadTagException) { break } catch (_: Exception) {}
                }
            }
        } catch (_: Exception) {} finally { alive.set(false) }
    }

    private fun handle(j: JSONObject, poke: () -> Unit = {}) {
        when (j.getString("t")) {
            "media" -> {
                val mcc = mc(); val kk = j.getString("k")
                if (mcc != null && kk in listOf("play_pause", "next", "prev", "stop")) {
                    val t = mcc.transportControls
                    when (kk) {
                        "play_pause" -> if (mcc.playbackState?.state == PlaybackState.STATE_PLAYING) t.pause() else t.play()
                        "next" -> t.skipToNext(); "prev" -> t.skipToPrevious(); else -> t.stop()
                    }
                    poke(); return
                }
                val code = when (j.getString("k")) {
                    "play_pause" -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
                    "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
                    "prev" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                    "stop" -> KeyEvent.KEYCODE_MEDIA_STOP
                    "ff" -> KeyEvent.KEYCODE_MEDIA_FAST_FORWARD
                    "rw" -> KeyEvent.KEYCODE_MEDIA_REWIND
                    else -> return
                }
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
                poke()
            }
            "vol" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, when (j.getString("k")) {
                "up" -> AudioManager.ADJUST_RAISE
                "down" -> AudioManager.ADJUST_LOWER
                else -> AudioManager.ADJUST_TOGGLE_MUTE
            }, AudioManager.FLAG_SHOW_UI)
            "seek" -> { mc()?.transportControls?.seekTo(j.getLong("ms")); poke() }
            "skip" -> { mc()?.let { c -> c.transportControls.seekTo((pos(c) + j.getLong("ms")).coerceAtLeast(0)) }; poke() }
            "volset" -> am.setStreamVolume(AudioManager.STREAM_MUSIC,
                (j.getDouble("f") * am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)).roundToInt(), 0)
            else -> if (NativeInput.forward(j)) RemoteAccess.mirror(j) else RemoteAccess.handle(j)
        }
    }

    @Volatile private var access = true
    private fun mc(): MediaController? = try {
        val l = getSystemService(MediaSessionManager::class.java).getActiveSessions(ComponentName(this, MediaListener::class.java))
        access = true
        l.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: l.firstOrNull()
    } catch (_: SecurityException) { access = false; null } catch (_: Exception) { null }

    private fun pos(c: MediaController): Long {
        val p = c.playbackState ?: return 0
        val v = if (p.state == PlaybackState.STATE_PLAYING)
            p.position + ((SystemClock.elapsedRealtime() - p.lastPositionUpdateTime) * p.playbackSpeed).toLong() else p.position
        return v.coerceAtLeast(0)
    }

    private var artKey = ""
    private var artB64 = ""
    private var artTries = 0

    private fun scaled(bm: android.graphics.Bitmap): String {
        val sc = 360f / maxOf(bm.width, bm.height)
        val b = Bitmap.createScaledBitmap(bm, (bm.width * sc).toInt().coerceAtLeast(1), (bm.height * sc).toInt().coerceAtLeast(1), true)
        val o = ByteArrayOutputStream(); b.compress(Bitmap.CompressFormat.JPEG, 70, o)
        return Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
    }

    /** Thumbnail / cover: bitmap in the session metadata, then its content:// URI, then the player's notification icon. */
    private fun findArt(md: MediaMetadata?, pkg: String): Bitmap? {
        md?.let {
            listOf(MediaMetadata.METADATA_KEY_ART, MediaMetadata.METADATA_KEY_ALBUM_ART, MediaMetadata.METADATA_KEY_DISPLAY_ICON)
                .forEach { k -> it.getBitmap(k)?.let { b -> return b } }
            listOf(MediaMetadata.METADATA_KEY_ART_URI, MediaMetadata.METADATA_KEY_ALBUM_ART_URI, MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)
                .forEach { k ->
                    val u = it.getString(k)
                    if (u != null && (u.startsWith("content:") || u.startsWith("file:"))) try {
                        contentResolver.openInputStream(android.net.Uri.parse(u))?.use { st -> android.graphics.BitmapFactory.decodeStream(st)?.let { b -> return b } }
                    } catch (_: Exception) {}
                }
        }
        return MediaListener.icons[pkg]
    }

    private fun stateJson(): JSONObject {
        val j = JSONObject().put("t", "state")
        j.put("vol", am.getStreamVolume(AudioManager.STREAM_MUSIC)).put("max", am.getStreamMaxVolume(AudioManager.STREAM_MUSIC))
        val c = mc()
        j.put("access", access)
        if (c == null) return j.put("title", "Nothing playing").put("artist", "").put("playing", false).put("pos", 0).put("dur", 0).put("spd", 1.0).put("art", "")
        val md = c.metadata
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: c.packageName ?: ""
        val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: ""
        val key = c.packageName + "|" + title + "|" + artist
        if (key != artKey) { artKey = key; artB64 = ""; artTries = 0 }
        // players often attach the thumbnail a moment after the title, so keep looking for a few seconds
        if (artB64.isEmpty() && artTries < 30) { artTries++; findArt(md, c.packageName)?.let { artB64 = scaled(it) } }
        return j.put("title", title).put("artist", artist).put("art", artB64)
            .put("playing", c.playbackState?.state == PlaybackState.STATE_PLAYING)
            .put("pos", pos(c)).put("dur", md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L)
            .put("spd", (c.playbackState?.playbackSpeed ?: 1f).toDouble())
    }

    override fun onDestroy() {
        running = false
        try { server?.close() } catch (_: Exception) {}
        try { reg?.let { nsd?.unregisterService(it) } } catch (_: Exception) {}
        super.onDestroy()
    }
}
