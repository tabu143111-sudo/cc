package com.example.lanremote

import android.app.*
import android.content.Intent
import android.media.AudioManager
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Base64
import android.view.KeyEvent
import org.json.JSONObject
import java.io.PrintWriter
import java.net.ServerSocket
import java.net.Socket

class HostService : Service() {
    companion object { @Volatile var running = false; @Volatile var pin = (10_000_000..99_999_999).random().toString(); const val PORT = 8765 }
    private var server: ServerSocket? = null
    private var nsd: NsdManager? = null
    private var reg: NsdManager.RegistrationListener? = null
    private val am by lazy { getSystemService(AudioManager::class.java) }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        pin = i?.getStringExtra("pin") ?: pin
        val ch = "host"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Host", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, ch).setContentTitle("LAN Remote host running")
            .setSmallIcon(android.R.drawable.ic_media_play).build())
        if (running) return START_NOT_STICKY
        running = true
        Thread {
            try {
                server = ServerSocket(PORT)
                registerNsd()
                while (running) { val s = server!!.accept(); Thread { serve(s) }.start() }
            } catch (_: Exception) {}
        }.start()
        return START_NOT_STICKY
    }

    private fun registerNsd() {
        nsd = getSystemService(NsdManager::class.java)
        reg = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(i: NsdServiceInfo) {}
            override fun onRegistrationFailed(i: NsdServiceInfo, e: Int) {}
            override fun onServiceUnregistered(i: NsdServiceInfo) {}
            override fun onUnregistrationFailed(i: NsdServiceInfo, e: Int) {}
        }
        val info = NsdServiceInfo().apply { serviceName = "Host-${Build.MODEL}"; serviceType = "_lanremote._tcp."; port = PORT }
        nsd?.registerService(info, NsdManager.PROTOCOL_DNS_SD, reg)
    }

    private fun serve(s: Socket) {
        try {
            s.use {
                val r = it.getInputStream().bufferedReader()
                val w = PrintWriter(it.getOutputStream(), true)
                val salt = Crypto.salt()
                w.println(Base64.encodeToString(salt, Base64.NO_WRAP))
                val key = Crypto.key(pin, salt)
                val a = try { JSONObject(Crypto.dec(key, r.readLine() ?: return)) } catch (e: Exception) { Thread.sleep(1500); return }
                if (a.optString("t") != "auth") return
                var last = a.optLong("n")
                w.println(Crypto.enc(key, JSONObject().put("ok", true).toString()))
                while (true) {
                    val l = r.readLine() ?: break
                    try {
                        val j = JSONObject(Crypto.dec(key, l))
                        val n = j.getLong("n"); if (n <= last) continue
                        last = n; handle(j)
                    } catch (e: javax.crypto.AEADBadTagException) { break } catch (_: Exception) {}
                }
            }
        } catch (_: Exception) {}
    }

    private fun handle(j: JSONObject) {
        when (j.getString("t")) {
            "media" -> {
                val code = when (j.getString("k")) {
                    "play_pause" -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
                    "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
                    "prev" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                    "stop" -> KeyEvent.KEYCODE_MEDIA_STOP
                    "ff" -> KeyEvent.KEYCODE_MEDIA_FAST_FORWARD
                    "rw" -> KeyEvent.KEYCODE_MEDIA_REWIND
                    else -> return
                }
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
            }
            "vol" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, when (j.getString("k")) {
                "up" -> AudioManager.ADJUST_RAISE
                "down" -> AudioManager.ADJUST_LOWER
                else -> AudioManager.ADJUST_TOGGLE_MUTE
            }, AudioManager.FLAG_SHOW_UI)
            else -> RemoteAccess.handle(j)
        }
    }

    override fun onDestroy() {
        running = false
        try { server?.close() } catch (_: Exception) {}
        try { reg?.let { nsd?.unregisterService(it) } } catch (_: Exception) {}
        super.onDestroy()
    }
}
