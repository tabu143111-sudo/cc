package com.example.lanremote

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.io.PrintWriter
import java.net.InetSocketAddress
import java.net.Socket

/** Bridge from the host app to the ADB-started [InputServer]. If it is not running, input falls back to Accessibility. */
object NativeInput {
    @Volatile var connected = false
    private var sock: Socket? = null
    private var out: PrintWriter? = null

    @Synchronized fun connect(ctx: Context) {
        if (connected) return
        try {
            val f = File(ctx.getExternalFilesDir(null), "native_token")
            if (!f.exists()) return
            val s = Socket(); s.connect(InetSocketAddress("127.0.0.1", 8766), 600); s.soTimeout = 2000
            val o = PrintWriter(s.getOutputStream(), true)
            o.println(f.readText().trim())
            if (s.getInputStream().bufferedReader().readLine() == "ok") { s.soTimeout = 0; sock = s; out = o; connected = true } else s.close()
        } catch (_: Exception) {}
    }

    @Synchronized private fun drop() { connected = false; try { sock?.close() } catch (_: Exception) {}; sock = null; out = null }

    /** @return true when the native server handled the command. */
    @Synchronized fun forward(j: JSONObject): Boolean {
        if (!connected) return false
        val ok = when (j.optString("t")) {
            "move", "click", "rclick", "scroll", "hscroll", "down", "up" -> true
            "key" -> j.optString("k") in listOf("back", "home", "recents", "backspace", "enter")
            "text" -> j.optString("s").all { it.code in 32..126 || it == '\n' }   // other characters: Accessibility fallback
            else -> false
        }
        if (!ok) return false
        val o = out ?: return false
        o.println(j.toString())
        if (o.checkError()) { drop(); return false }
        return true
    }
}
