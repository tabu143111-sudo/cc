package com.example.lanremote

import android.Manifest
import android.content.Intent
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.util.concurrent.Executors
import kotlin.math.abs
import android.util.Base64
import android.content.SharedPreferences
import android.content.res.Configuration
import java.util.concurrent.atomic.AtomicLong
import javax.crypto.spec.SecretKeySpec
import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlin.math.roundToInt
import androidx.compose.animation.core.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import kotlinx.coroutines.delay

data class PlayState(val title: String = "Not playing", val artist: String = "", val playing: Boolean = false,
    val pos: Long = 0, val dur: Long = 0, val vol: Int = 0, val max: Int = 1, val art: Bitmap? = null, val at: Long = 0)

class Client {
    var st by mutableStateOf(PlayState())
    private var sock: Socket? = null
    private var out: PrintWriter? = null
    private var key: SecretKeySpec? = null
    private val seq = AtomicLong(0)
    private val ex = Executors.newSingleThreadExecutor()
    fun connect(host: String, pin: String, cb: (Boolean) -> Unit) = ex.execute {
        try {
            val s = Socket(); s.connect(InetSocketAddress(host, HostService.PORT), 4000); s.soTimeout = 6000; sock = s
            out = PrintWriter(s.getOutputStream(), true)
            val rd = BufferedReader(InputStreamReader(s.getInputStream()))
            key = Crypto.key(pin, Base64.decode(rd.readLine(), Base64.NO_WRAP))
            out!!.println(Crypto.enc(key!!, JSONObject().put("t", "auth").put("n", seq.incrementAndGet()).toString()))
            val r = rd.readLine()
            val ok = r != null && JSONObject(Crypto.dec(key!!, r)).optBoolean("ok")
            if (ok) {
                s.soTimeout = 0
                Thread {
                    try { while (true) { val l = rd.readLine() ?: break
                        val j = JSONObject(Crypto.dec(key!!, l)); if (j.optString("t") == "state") onState(j) } } catch (_: Exception) {}
                }.start()
            }
            cb(ok)
        } catch (e: Exception) { cb(false) }
    }
    fun send(t: String, vararg kv: Pair<String, Any>) = ex.execute {
        try {
            val j = JSONObject().put("t", t).put("n", seq.incrementAndGet()); kv.forEach { j.put(it.first, it.second) }
            out?.println(Crypto.enc(key!!, j.toString()))
        } catch (_: Exception) {}
    }
    private fun onState(j: JSONObject) {
        val art = if (j.has("art")) j.optString("art").let { if (it.isEmpty()) null else Base64.decode(it, Base64.NO_WRAP).let { b -> BitmapFactory.decodeByteArray(b, 0, b.size) } } else st.art
        st = PlayState(j.optString("title"), j.optString("artist"), j.optBoolean("playing"), j.optLong("pos"), j.optLong("dur"),
            j.optInt("vol"), j.optInt("max", 1), art, System.currentTimeMillis())
    }
    fun close() { try { sock?.close() } catch (_: Exception) {}; ex.shutdown() }
}

// ---------- Theme ----------
object Pal { var dark by mutableStateOf(true) }
lateinit var appPrefs: SharedPreferences
fun setDark(v: Boolean) { Pal.dark = v; appPrefs.edit().putBoolean("dark", v).apply() }
val Bg1 get() = if (Pal.dark) Color(0xFF0A0E1A) else Color(0xFFF4F6FF)
val Bg2 get() = if (Pal.dark) Color(0xFF151B33) else Color(0xFFE6EBFB)
val CardC get() = if (Pal.dark) Color(0xFF1A2140) else Color.White
val Muted get() = if (Pal.dark) Color(0xFF94A3B8) else Color(0xFF64748B)
val Edge get() = if (Pal.dark) Color(0x16FFFFFF) else Color(0x1A0F172A)
val Accent = Color(0xFF7C5CFF); val Accent2 = Color(0xFF22D3EE)
val Good = Color(0xFF34D399); val Bad = Color(0xFFF87171)
val Grad = Brush.linearGradient(listOf(Accent, Accent2))

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        appPrefs = getSharedPreferences("s", 0)
        Pal.dark = appPrefs.getBoolean("dark", (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES)
        setContent {
            MaterialTheme(colorScheme = if (Pal.dark) darkColorScheme(primary = Accent, background = Bg1, surface = Bg1) else lightColorScheme(primary = Accent, background = Bg1, surface = Bg1)) {
                Surface(Modifier.fillMaxSize(), color = Bg1) { App() }
            }
        }
    }
}

@Composable fun App() {
    var mode by remember { mutableStateOf<String?>(null) }
    var client by remember { mutableStateOf<Client?>(null) }
    val c = client
    when {
        mode == null -> Home { mode = it }
        mode == "host" -> HostScreen { mode = null }
        c == null -> Connect({ mode = null }) { client = it }
        else -> Remote(c) { c.close(); client = null; mode = null }
    }
}

// ---------- Reusable pieces ----------
@Composable fun Screen(maxW: Dp = 560.dp, content: @Composable ColumnScope.() -> Unit) {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Bg1, Bg2))).statusBarsPadding(),
        contentAlignment = Alignment.TopCenter) {
        Column(Modifier.widthIn(max = maxW).fillMaxSize(), content = content)
    }
}

@Composable fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxWidth().background(CardC, RoundedCornerShape(20.dp))
        .border(1.dp, Edge, RoundedCornerShape(20.dp)).padding(16.dp), content = content)
}

@Composable fun Label(t: String) = Text(t, fontSize = 11.sp, color = Muted, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)

@Composable fun GradBtn(text: String, modifier: Modifier = Modifier, brush: Brush = Grad, onClick: () -> Unit) {
    val h = LocalHapticFeedback.current
    Box(modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(16.dp)).background(brush)
        .clickable { h.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() },
        contentAlignment = Alignment.Center) {
        Text(text, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
    }
}

@Composable fun RoundBtn(glyph: String, size: Dp, filled: Boolean = false, onClick: () -> Unit) {
    val h = LocalHapticFeedback.current
    Box(Modifier.size(size).clip(CircleShape)
        .then(if (filled) Modifier.background(Grad) else Modifier.background(CardC).border(1.dp, Edge, CircleShape))
        .clickable { h.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() },
        contentAlignment = Alignment.Center) { Text(glyph, fontSize = (size.value * 0.38f).sp, color = if (filled) Color.White else LocalContentColor.current) }
}

@Composable fun Tile(glyph: String, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val h = LocalHapticFeedback.current
    Column(modifier.height(76.dp).clip(RoundedCornerShape(18.dp)).background(CardC)
        .border(1.dp, Edge, RoundedCornerShape(18.dp))
        .clickable { h.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() },
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(glyph, fontSize = 22.sp); Text(label, fontSize = 11.sp, color = Muted)
    }
}

@Composable fun Header(title: String, sub: String, onBack: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(20.dp, 16.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) { RoundBtn("←", 44.dp, onClick = onBack); Spacer(Modifier.width(14.dp)) }
        Column { Text(title, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold); Text(sub, color = Muted, fontSize = 13.sp) }
    }
}

@Composable fun tfColors() = OutlinedTextFieldDefaults.colors(focusedBorderColor = Accent2,
    unfocusedBorderColor = Color(0x33FFFFFF), cursorColor = Accent2, focusedLabelColor = Accent2, unfocusedLabelColor = Muted)

fun localIps(): String = NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }
    .filter { it is Inet4Address && !it.isLoopbackAddress }.joinToString { it.hostAddress ?: "" }.ifEmpty { "not on Wi-Fi" }

// ---------- Home ----------
@Composable fun ModeCard(icon: String, title: String, desc: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(CardC)
        .border(1.dp, Edge, RoundedCornerShape(24.dp)).clickable(onClick = onClick).padding(20.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(60.dp).clip(RoundedCornerShape(18.dp)).background(Grad), contentAlignment = Alignment.Center) {
            Text(icon, fontSize = 28.sp) }
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) { Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text(desc, color = Muted, fontSize = 13.sp) }
        Text("›", fontSize = 30.sp, color = Muted)
    }
}

@Composable fun Home(pick: (String) -> Unit) = Screen {
    Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.End) {
        RoundBtn(if (Pal.dark) "☀" else "🌙", 44.dp) { setDark(!Pal.dark) }
    }
    Spacer(Modifier.height(12.dp))
    Column(Modifier.padding(horizontal = 24.dp)) {
        Box(Modifier.size(68.dp).clip(RoundedCornerShape(22.dp)).background(Grad), contentAlignment = Alignment.Center) {
            Text("📡", fontSize = 32.sp) }
        Spacer(Modifier.height(18.dp))
        Text("LAN Remote", fontSize = 36.sp, fontWeight = FontWeight.ExtraBold)
        Text("Media, mouse and keyboard control\nover your Wi-Fi.", color = Muted, fontSize = 15.sp)
    }
    Spacer(Modifier.height(36.dp))
    Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        ModeCard("🎮", "Controller", "Use this device as the remote") { pick("controller") }
        ModeCard("📺", "Host", "Let another device control this one") { pick("host") }
    }
    Spacer(Modifier.weight(1f))
    Text("Both devices must be on the same network", color = Muted, fontSize = 12.sp,
        modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 24.dp))
}

// ---------- Host ----------
@Composable fun HostScreen(onBack: () -> Unit) = Screen {
    val ctx = LocalContext.current
    var pin by remember { mutableStateOf(HostService.pin) }
    var on by remember { mutableStateOf(HostService.running) }
    var acc by remember { mutableStateOf(false) }
    var nlOn by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { while (true) { acc = RemoteAccess.instance != null
        nlOn = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners")?.contains(ctx.packageName) == true; delay(1000) } }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    val pulse by rememberInfiniteTransition(label = "p").animateFloat(0.3f, 1f,
        infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "a")
    Header("Host", "🔒 Encrypted · this device will be controlled", onBack)
    Column(Modifier.padding(horizontal = 20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(12.dp).clip(CircleShape).background((if (on) Good else Muted).copy(alpha = if (on) pulse else 1f)))
                Spacer(Modifier.width(10.dp))
                Text(if (on) "Host is running" else "Host is stopped", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
            Spacer(Modifier.height(14.dp)); Label("YOUR IP ADDRESS")
            Text(localIps(), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Accent2)
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(pin, { pin = it.filter(Char::isLetterOrDigit).take(16) }, Modifier.fillMaxWidth(),
                label = { Text("Pairing code") }, supportingText = { Text("6–16 letters or digits. Enter the same code on the controller.") }, singleLine = true, shape = RoundedCornerShape(14.dp), colors = tfColors())
        }
        val ip = hostIp()
        if (ip.contains('.')) Panel {
            Label("SCAN TO CONNECT"); Spacer(Modifier.height(10.dp))
            val qr = remember(pin, ip) { qrBitmap("LANREMOTE|$ip|$pin") }
            Image(qr.asImageBitmap(), "QR code", Modifier.size(200.dp).clip(RoundedCornerShape(12.dp)).align(Alignment.CenterHorizontally))
            Text("Open the Controller on the other device and tap Scan QR. The code contains your pairing code, so only show it to people you trust.",
                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
        }
        GradBtn(if (on) "Stop host" else "Start host",
            brush = if (on) Brush.linearGradient(listOf(Color(0xFFEF4444), Color(0xFFF97316))) else Grad) {
            if (!on && pin.length < 6) return@GradBtn
            if (Build.VERSION.SDK_INT >= 33) perm.launch(Manifest.permission.POST_NOTIFICATIONS)
            val i = Intent(ctx, HostService::class.java).putExtra("pin", pin)
            if (on) ctx.stopService(i) else ctx.startForegroundService(i)
            on = !on
        }
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(12.dp).clip(CircleShape).background(if (acc) Good else Bad))
                Spacer(Modifier.width(10.dp))
                Text(if (acc) "Mouse & keyboard: enabled" else "Mouse & keyboard: off", fontWeight = FontWeight.Bold)
            }
            Text("Media and volume work without this. Enable the Accessibility service to allow cursor, taps, scrolling and typing.",
                color = Muted, fontSize = 13.sp, modifier = Modifier.padding(vertical = 10.dp))
            GradBtn("Open Accessibility settings", brush = Brush.linearGradient(listOf(Color(0xFF334155), Color(0xFF475569)))) {
                ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(12.dp).clip(CircleShape).background(if (nlOn) Good else Bad))
                Spacer(Modifier.width(10.dp))
                Text(if (nlOn) "Now-playing info: enabled" else "Now-playing info: off", fontWeight = FontWeight.Bold)
            }
            Text("Lets the controller show the title, artwork and time bar, and seek.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(vertical = 10.dp))
            GradBtn("Open notification access", brush = Brush.linearGradient(listOf(Color(0xFF334155), Color(0xFF475569)))) {
                ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        }
        Spacer(Modifier.height(16.dp))
    }
}

// ---------- Connect ----------
@Composable fun Connect(onBack: () -> Unit, onConnected: (Client) -> Unit) = Screen {
    val ctx = LocalContext.current
    val found = remember { mutableStateListOf<Pair<String, String>>() }
    var ip by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    DisposableEffect(Unit) {
        val nsd = ctx.getSystemService(NsdManager::class.java)
        val l = object : NsdManager.DiscoveryListener {
            override fun onServiceFound(s: NsdServiceInfo) {
                nsd.resolveService(s, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(s: NsdServiceInfo, e: Int) {}
                    override fun onServiceResolved(r: NsdServiceInfo) {
                        val h = r.host?.hostAddress ?: return
                        if (found.none { it.second == h }) found.add(r.serviceName to h)
                    }
                })
            }
            override fun onServiceLost(s: NsdServiceInfo) {}
            override fun onDiscoveryStarted(t: String) {}
            override fun onDiscoveryStopped(t: String) {}
            override fun onStartDiscoveryFailed(t: String, e: Int) {}
            override fun onStopDiscoveryFailed(t: String, e: Int) {}
        }
        nsd.discoverServices("_lanremote._tcp.", NsdManager.PROTOCOL_DNS_SD, l)
        onDispose { try { nsd.stopServiceDiscovery(l) } catch (_: Exception) {} }
    }
    fun go(h: String) {
        busy = true; msg = ""
        val c = Client()
        c.connect(h, pin) { ok -> busy = false; if (ok) onConnected(c) else msg = "Couldn't connect. Check the IP, PIN and that the host is started." }
    }
    val scan = rememberLauncherForActivityResult(ScanContract()) { r ->
        r.contents?.split("|")?.let { p -> if (p.size == 3 && p[0] == "LANREMOTE") { pin = p[2]; go(p[1]) } }
    }
    Header("Controller", "🔒 Encrypted · pick a host to control", onBack)
    Column(Modifier.padding(horizontal = 20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        GradBtn("📷  Scan QR code") { scan.launch(ScanOptions().setBeepEnabled(false).setPrompt("Scan the QR shown on the host").setOrientationLocked(false)) }
        Panel {
            OutlinedTextField(pin, { pin = it.filter(Char::isLetterOrDigit).take(16) }, Modifier.fillMaxWidth(),
                label = { Text("Pairing code") }, singleLine = true, shape = RoundedCornerShape(14.dp), colors = tfColors())
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Label("NEARBY HOSTS"); Spacer(Modifier.width(10.dp))
            if (found.isEmpty()) CircularProgressIndicator(Modifier.size(14.dp), color = Accent2, strokeWidth = 2.dp)
        }
        if (found.isEmpty()) Text("Searching your network…", color = Muted, fontSize = 13.sp)
        found.forEach { (n, h) ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(CardC).border(1.dp, Edge, RoundedCornerShape(18.dp))
                .clickable { go(h) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("📺", fontSize = 26.sp); Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) { Text(n, fontWeight = FontWeight.Bold); Text(h, color = Accent2, fontSize = 13.sp) }
                Text("Connect ›", color = Muted)
            }
        }
        Label("OR ENTER IP MANUALLY")
        OutlinedTextField(ip, { ip = it }, Modifier.fillMaxWidth(), label = { Text("e.g. 192.168.1.20") },
            singleLine = true, shape = RoundedCornerShape(14.dp), colors = tfColors())
        GradBtn(if (busy) "Connecting…" else "Connect") { if (!busy && ip.isNotBlank()) go(ip.trim()) }
        if (msg.isNotEmpty()) Text(msg, color = Bad, fontSize = 13.sp)
        Spacer(Modifier.height(16.dp))
    }
}

// ---------- Remote ----------
@Composable fun Remote(c: Client, onExit: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var fold by remember { mutableStateOf(false) }
    val toggleFull: () -> Unit = { c.send("fs"); fold = !fold }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth >= 840.dp
        Screen(if (wide) 1600.dp else 560.dp) {
            if (fold) {
                Box(Modifier.weight(1f)) { FoldLayout(c, toggleFull) }
            } else {
                Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Row(Modifier.clip(RoundedCornerShape(50)).background(Good.copy(alpha = 0.15f)).padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(Good)); Spacer(Modifier.width(8.dp))
                        Text("Connected · 🔒", color = Good, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.weight(1f))
                    TextButton(onExit) { Text("Disconnect", color = Bad) }
                }
                Box(Modifier.weight(1f)) {
                    if (wide) {
                        Row(Modifier.fillMaxSize()) {
                            Box(Modifier.weight(1f)) { MediaTab(c, toggleFull) }
                            Box(Modifier.weight(1.2f)) { Mouse(c) }
                            Box(Modifier.weight(1f)) { Keys(c) }
                        }
                    } else {
                        when (tab) { 0 -> MediaTab(c, toggleFull); 1 -> Mouse(c); else -> Keys(c) }
                    }
                }
                if (!wide) NavigationBar(containerColor = CardC) {
                    listOf("🎵" to "Media", "🖱️" to "Mouse", "⌨️" to "Keyboard").forEachIndexed { i, (g, t) ->
                        NavigationBarItem(tab == i, { tab = i }, icon = { Text(g, fontSize = 22.sp) }, label = { Text(t) },
                            colors = NavigationBarItemDefaults.colors(indicatorColor = Accent.copy(alpha = 0.35f),
                                selectedTextColor = MaterialTheme.colorScheme.onSurface, unselectedTextColor = Muted))
                    }
                }
            }
        }
    }
}

fun fmt(ms: Long): String {
    val s = ms / 1000; val h = s / 3600; val m = (s % 3600) / 60; val x = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, x) else "%d:%02d".format(m, x)
}

@Composable fun Art(bm: Bitmap?, size: Dp) {
    Box(Modifier.size(size).clip(RoundedCornerShape(12.dp)).background(Grad), contentAlignment = Alignment.Center) {
        if (bm != null) Image(bm.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text("🎵", fontSize = (size.value * 0.45f).sp)
    }
}

@Composable fun FullIcon(onClick: () -> Unit) {
    val col = LocalContentColor.current
    Box(Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onClick), Alignment.Center) {
        Canvas(Modifier.size(18.dp)) {
            val w = size.width; val k = w * 0.38f; val sw = 2.2.dp.toPx()
            fun l(x1: Float, y1: Float, x2: Float, y2: Float) = drawLine(col, Offset(x1, y1), Offset(x2, y2), sw, StrokeCap.Round)
            l(0f, 0f, k, 0f); l(0f, 0f, 0f, k); l(w, 0f, w - k, 0f); l(w, 0f, w, k)
            l(0f, w, k, w); l(0f, w, 0f, w - k); l(w, w, w - k, w); l(w, w, w, w - k)
        }
    }
}

@Composable fun Seek(c: Client) {
    val st = c.st
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(250) } }
    var drag by remember { mutableStateOf<Float?>(null) }
    var release by remember { mutableIntStateOf(0) }
    LaunchedEffect(release) { if (release > 0) { delay(1500); drag = null } }
    val pos = if (st.playing) minOf(st.pos + (now - st.at), if (st.dur > 0) st.dur else Long.MAX_VALUE) else st.pos
    val frac = if (st.dur > 0) (pos.toFloat() / st.dur).coerceIn(0f, 1f) else 0f
    Slider(drag ?: frac, { drag = it }, Modifier.fillMaxWidth(), enabled = st.dur > 0,
        onValueChangeFinished = { drag?.let { c.send("seek", "ms" to (it * st.dur).toLong()) }; release++ },
        colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Accent2))
    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(fmt(if (drag != null) (drag!! * st.dur).toLong() else pos), fontSize = 12.sp, color = Muted)
        Text(fmt(st.dur), fontSize = 12.sp, color = Muted)
    }
}

@Composable fun Transport(c: Client, s: Float = 1f) {
    Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly, Alignment.CenterVertically) {
        RoundBtn("⏮", (46 * s).dp) { c.send("media", "k" to "prev") }
        RoundBtn("↺10", (58 * s).dp) { c.send("skip", "ms" to -10000L) }
        RoundBtn(if (c.st.playing) "⏸" else "▶", (78 * s).dp, true) { c.send("media", "k" to "play_pause") }
        RoundBtn("10↻", (58 * s).dp) { c.send("skip", "ms" to 10000L) }
        RoundBtn("⏭", (46 * s).dp) { c.send("media", "k" to "next") }
    }
}

@Composable fun VolumeBar(c: Client) {
    val st = c.st
    var drag by remember { mutableStateOf<Float?>(null) }
    var release by remember { mutableIntStateOf(0) }
    LaunchedEffect(release) { if (release > 0) { delay(1500); drag = null } }
    val frac = if (st.max > 0) st.vol.toFloat() / st.max else 0f
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("🔈", fontSize = 16.sp)
        Slider(drag ?: frac, { drag = it; c.send("volset", "f" to it) }, Modifier.weight(1f).padding(horizontal = 8.dp),
            onValueChangeFinished = { release++ },
            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Accent))
        Text("🔊", fontSize = 16.sp)
    }
}

@Composable fun MediaTab(c: Client, onFull: () -> Unit) {
    val st = c.st
    Column(Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Panel {
            Row(verticalAlignment = Alignment.Top) {
                Art(st.art, 64.dp); Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(st.title, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(st.artist, color = Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                FullIcon(onFull)
            }
            Spacer(Modifier.height(12.dp)); Seek(c)
            Spacer(Modifier.height(8.dp)); Transport(c)
            Spacer(Modifier.height(14.dp)); VolumeBar(c)
        }
        if (st.title == "Nothing playing") Text("No media info? On the host, tap “Open notification access” and enable LAN Remote.",
            color = Muted, fontSize = 12.sp)
    }
}

/** Dual-screen "folded" look: touchpad on the top half, media controls on the bottom half. */
@Composable fun FoldLayout(c: Client, onExit: () -> Unit) {
    val st = c.st
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f)) { Mouse(c, true) }
        Box(Modifier.fillMaxWidth().height(12.dp).background(Brush.verticalGradient(listOf(Color(0xFF05070D), Color(0xFF232B4D), Color(0xFF05070D)))))
        Column(Modifier.weight(1f).padding(horizontal = 20.dp, vertical = 8.dp), verticalArrangement = Arrangement.SpaceEvenly) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Art(st.art, 44.dp); Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(st.title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(st.artist, color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                FullIcon(onExit)
            }
            Seek(c); Transport(c, 0.85f); VolumeBar(c)
        }
    }
}

fun mMove(c: Client, dx: Float, dy: Float) {
    if (BtHid.useBt) BtHid.send(0, dx.roundToInt(), dy.roundToInt(), 0) else c.send("move", "dx" to dx, "dy" to dy)
}
fun mClick(c: Client, right: Boolean) {
    if (BtHid.useBt) { BtHid.send(if (right) 2 else 1, 0, 0, 0); BtHid.send(0, 0, 0, 0) } else c.send(if (right) "rclick" else "click")
}
fun mScroll(c: Client, a: Float) {
    if (BtHid.useBt) BtHid.send(0, 0, 0, (-a / 30f).roundToInt().coerceIn(-5, 5)) else c.send("scroll", "dy" to a)
}

@SuppressLint("MissingPermission")
@Composable fun Mouse(c: Client, compact: Boolean = false) {
    val ctx = LocalContext.current
    var speed by remember { mutableFloatStateOf(1.6f) }
    val gain by rememberUpdatedState(speed)
    var pick by remember { mutableStateOf(false) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) BtHid.start(ctx) }
    val shape = RoundedCornerShape(24.dp)
    if (pick) AlertDialog(onDismissRequest = { pick = false }, confirmButton = { TextButton({ pick = false }) { Text("Close") } },
        title = { Text("Paired devices") },
        text = { Column {
            Text("Pair both devices in Android Bluetooth settings first.", fontSize = 12.sp, color = Muted)
            BtHid.bonded().forEach { d -> TextButton({ BtHid.connect(d); pick = false }) { Text(d.name ?: d.address) } }
        } })
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            listOf(false to "📶 Wi-Fi", true to "🔵 Bluetooth").forEach { (bt, label) ->
                val sel = BtHid.useBt == bt
                Box(Modifier.weight(1f).height(40.dp).clip(RoundedCornerShape(12.dp))
                    .then(if (sel) Modifier.background(Grad) else Modifier.background(CardC).border(1.dp, Edge, RoundedCornerShape(12.dp)))
                    .clickable {
                        BtHid.useBt = bt
                        if (bt) { if (Build.VERSION.SDK_INT >= 31) perm.launch(Manifest.permission.BLUETOOTH_CONNECT) else BtHid.start(ctx) }
                    }, contentAlignment = Alignment.Center) {
                    Text(label, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = if (sel) Color.White else LocalContentColor.current)
                }
            }
            if (BtHid.useBt) TextButton({ pick = true }) { Text(if (BtHid.connected) "● Connected" else "Choose host") }
        }
        if (BtHid.useBt && !compact) Text(BtHid.status, color = Muted, fontSize = 12.sp)
        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.weight(1f).fillMaxHeight().clip(shape)
                .background(Brush.linearGradient(if (Pal.dark) listOf(Color(0xFF1E2750), Color(0xFF131A33)) else listOf(Color(0xFFEEF0FF), Color(0xFFDCE3FA)))).border(1.5.dp, Grad, shape)
                .pointerInput(Unit) { detectTapGestures(onTap = { mClick(c, false) }, onLongPress = { mClick(c, true) }) }
                .pointerInput(Unit) { detectDragGestures { ch, d -> ch.consume(); mMove(c, d.x * gain, d.y * gain) } },
                contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🖱️", fontSize = 34.sp); Text("Touchpad", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("Drag · Tap = click · Hold = right-click", color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
                }
            }
            Box(Modifier.width(56.dp).fillMaxHeight().clip(shape).background(CardC).border(1.dp, Edge, shape)
                .pointerInput(Unit) {
                    var a = 0f
                    detectVerticalDragGestures { ch, d -> ch.consume(); a += d; if (abs(a) > 30) { mScroll(c, a); a = 0f } }
                }, contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("▲", color = Accent2); Text("SCROLL", fontSize = 9.sp, color = Muted, fontWeight = FontWeight.Bold); Text("▼", color = Accent2)
                }
            }
        }
        if (!compact) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Tile("◧", "Left click", Modifier.weight(1f)) { mClick(c, false) }
                Tile("◨", "Right click", Modifier.weight(1f)) { mClick(c, true) }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Label("SPEED")
                Slider(speed, { speed = it }, Modifier.weight(1f).padding(start = 12.dp), valueRange = 0.8f..3.5f,
                    colors = SliderDefaults.colors(thumbColor = Accent2, activeTrackColor = Accent))
            }
        }
    }
}

fun hostIp(): String = localIps().split(", ").first()

fun qrBitmap(text: String): Bitmap {
    val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 512, 512)
    val bmp = Bitmap.createBitmap(512, 512, Bitmap.Config.RGB_565)
    for (x in 0 until 512) for (y in 0 until 512) bmp.setPixel(x, y, if (m.get(x, y)) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
    return bmp
}

@Composable fun Keys(c: Client) {
    var text by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Panel {
            Label("TYPE ON HOST"); Spacer(Modifier.height(10.dp))
            OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), minLines = 3, shape = RoundedCornerShape(14.dp),
                placeholder = { Text("Type something…") }, colors = tfColors())
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GradBtn("Send", Modifier.weight(1f)) { c.send("text", "s" to text); text = "" }
                GradBtn("Send + Enter", Modifier.weight(1f), Brush.linearGradient(listOf(Color(0xFF334155), Color(0xFF475569)))) {
                    c.send("text", "s" to text); c.send("key", "k" to "enter"); text = "" }
            }
        }
        Label("SPECIAL KEYS")
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Tile("⌫", "Backspace", Modifier.weight(1f)) { c.send("key", "k" to "backspace") }
            Tile("↵", "Enter", Modifier.weight(1f)) { c.send("key", "k" to "enter") }
            Tile("␣", "Space", Modifier.weight(1f)) { c.send("text", "s" to " ") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Tile("◀", "Back", Modifier.weight(1f)) { c.send("key", "k" to "back") }
            Tile("🏠", "Home", Modifier.weight(1f)) { c.send("key", "k" to "home") }
            Tile("▣", "Recents", Modifier.weight(1f)) { c.send("key", "k" to "recents") }
        }
    }
}
