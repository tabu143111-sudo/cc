package com.example.lanremote

import android.Manifest
import android.content.Intent
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.util.concurrent.Executors
import kotlin.math.abs
import android.util.Base64
import android.content.SharedPreferences
import android.content.res.Configuration
import java.util.concurrent.atomic.AtomicLong
import javax.crypto.spec.SecretKeySpec
import androidx.compose.animation.core.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import kotlinx.coroutines.delay

class Client {
    private var sock: Socket? = null
    private var out: PrintWriter? = null
    private var key: SecretKeySpec? = null
    private val seq = AtomicLong(0)
    private val ex = Executors.newSingleThreadExecutor()
    fun connect(host: String, pin: String, cb: (Boolean) -> Unit) = ex.execute {
        try {
            val s = Socket(); s.connect(InetSocketAddress(host, HostService.PORT), 4000); s.soTimeout = 6000; sock = s
            out = PrintWriter(s.getOutputStream(), true)
            val rd = BufferedReader(InputStreamReader(s.getInputStream()))
            key = Crypto.key(pin, Base64.decode(rd.readLine(), Base64.NO_WRAP))
            out!!.println(Crypto.enc(key!!, JSONObject().put("t", "auth").put("n", seq.incrementAndGet()).toString()))
            val r = rd.readLine()
            val ok = r != null && JSONObject(Crypto.dec(key!!, r)).optBoolean("ok")
            if (ok) s.soTimeout = 0
            cb(ok)
        } catch (e: Exception) { cb(false) }
    }
    fun send(t: String, vararg kv: Pair<String, Any>) = ex.execute {
        try {
            val j = JSONObject().put("t", t).put("n", seq.incrementAndGet()); kv.forEach { j.put(it.first, it.second) }
            out?.println(Crypto.enc(key!!, j.toString()))
        } catch (_: Exception) {}
    }
    fun close() { try { sock?.close() } catch (_: Exception) {}; ex.shutdown() }
}

// ---------- Theme ----------
object Pal { var dark by mutableStateOf(true) }
lateinit var appPrefs: SharedPreferences
fun setDark(v: Boolean) { Pal.dark = v; appPrefs.edit().putBoolean("dark", v).apply() }
val Bg1 get() = if (Pal.dark) Color(0xFF0A0E1A) else Color(0xFFF4F6FF)
val Bg2 get() = if (Pal.dark) Color(0xFF151B33) else Color(0xFFE6EBFB)
val CardC get() = if (Pal.dark) Color(0xFF1A2140) else Color.White
val Muted get() = if (Pal.dark) Color(0xFF94A3B8) else Color(0xFF64748B)
val Edge get() = if (Pal.dark) Color(0x16FFFFFF) else Color(0x1A0F172A)
val Accent = Color(0xFF7C5CFF); val Accent2 = Color(0xFF22D3EE)
val Good = Color(0xFF34D399); val Bad = Color(0xFFF87171)
val Grad = Brush.linearGradient(listOf(Accent, Accent2))

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        appPrefs = getSharedPreferences("s", 0)
        Pal.dark = appPrefs.getBoolean("dark", (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES)
        setContent {
            MaterialTheme(colorScheme = if (Pal.dark) darkColorScheme(primary = Accent, background = Bg1, surface = Bg1) else lightColorScheme(primary = Accent, background = Bg1, surface = Bg1)) {
                Surface(Modifier.fillMaxSize(), color = Bg1) { App() }
            }
        }
    }
}

@Composable fun App() {
    var mode by remember { mutableStateOf<String?>(null) }
    var client by remember { mutableStateOf<Client?>(null) }
    val c = client
    when {
        mode == null -> Home { mode = it }
        mode == "host" -> HostScreen { mode = null }
        c == null -> Connect({ mode = null }) { client = it }
        else -> Remote(c) { c.close(); client = null; mode = null }
    }
}

// ---------- Reusable pieces ----------
@Composable fun Screen(maxW: Dp = 560.dp, content: @Composable ColumnScope.() -> Unit) {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Bg1, Bg2))).statusBarsPadding(),
        contentAlignment = Alignment.TopCenter) {
        Column(Modifier.widthIn(max = maxW).fillMaxSize(), content = content)
    }
}

@Composable fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxWidth().background(CardC, RoundedCornerShape(20.dp))
        .border(1.dp, Edge, RoundedCornerShape(20.dp)).padding(16.dp), content = content)
}

@Composable fun Label(t: String) = Text(t, fontSize = 11.sp, color = Muted, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)

@Composable fun GradBtn(text: String, modifier: Modifier = Modifier, brush: Brush = Grad, onClick: () -> Unit) {
    val h = LocalHapticFeedback.current
    Box(modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(16.dp)).background(brush)
        .clickable { h.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() },
        contentAlignment = Alignment.Center) {
        Text(text, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
    }
}

@Composable fun RoundBtn(glyph: String, size: Dp, filled: Boolean = false, onClick: () -> Unit) {
    val h = LocalHapticFeedback.current
    Box(Modifier.size(size).clip(CircleShape)
        .then(if (filled) Modifier.background(Grad) else Modifier.background(CardC).border(1.dp, Edge, CircleShape))
        .clickable { h.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() },
        contentAlignment = Alignment.Center) { Text(glyph, fontSize = (size.value * 0.38f).sp, color = if (filled) Color.White else LocalContentColor.current) }
}

@Composable fun Tile(glyph: String, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val h = LocalHapticFeedback.current
    Column(modifier.height(76.dp).clip(RoundedCornerShape(18.dp)).background(CardC)
        .border(1.dp, Edge, RoundedCornerShape(18.dp))
        .clickable { h.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() },
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(glyph, fontSize = 22.sp); Text(label, fontSize = 11.sp, color = Muted)
    }
}

@Composable fun Header(title: String, sub: String, onBack: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(20.dp, 16.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) { RoundBtn("←", 44.dp, onClick = onBack); Spacer(Modifier.width(14.dp)) }
        Column { Text(title, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold); Text(sub, color = Muted, fontSize = 13.sp) }
    }
}

@Composable fun tfColors() = OutlinedTextFieldDefaults.colors(focusedBorderColor = Accent2,
    unfocusedBorderColor = Color(0x33FFFFFF), cursorColor = Accent2, focusedLabelColor = Accent2, unfocusedLabelColor = Muted)

fun localIps(): String = NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }
    .filter { it is Inet4Address && !it.isLoopbackAddress }.joinToString { it.hostAddress ?: "" }.ifEmpty { "not on Wi-Fi" }

// ---------- Home ----------
@Composable fun ModeCard(icon: String, title: String, desc: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(CardC)
        .border(1.dp, Edge, RoundedCornerShape(24.dp)).clickable(onClick = onClick).padding(20.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(60.dp).clip(RoundedCornerShape(18.dp)).background(Grad), contentAlignment = Alignment.Center) {
            Text(icon, fontSize = 28.sp) }
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) { Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text(desc, color = Muted, fontSize = 13.sp) }
        Text("›", fontSize = 30.sp, color = Muted)
    }
}

@Composable fun Home(pick: (String) -> Unit) = Screen {
    Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.End) {
        RoundBtn(if (Pal.dark) "☀" else "🌙", 44.dp) { setDark(!Pal.dark) }
    }
    Spacer(Modifier.height(12.dp))
    Column(Modifier.padding(horizontal = 24.dp)) {
        Box(Modifier.size(68.dp).clip(RoundedCornerShape(22.dp)).background(Grad), contentAlignment = Alignment.Center) {
            Text("📡", fontSize = 32.sp) }
        Spacer(Modifier.height(18.dp))
        Text("LAN Remote", fontSize = 36.sp, fontWeight = FontWeight.ExtraBold)
        Text("Media, mouse and keyboard control\nover your Wi-Fi.", color = Muted, fontSize = 15.sp)
    }
    Spacer(Modifier.height(36.dp))
    Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        ModeCard("🎮", "Controller", "Use this device as the remote") { pick("controller") }
        ModeCard("📺", "Host", "Let another device control this one") { pick("host") }
    }
    Spacer(Modifier.weight(1f))
    Text("Both devices must be on the same network", color = Muted, fontSize = 12.sp,
        modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 24.dp))
}

// ---------- Host ----------
@Composable fun HostScreen(onBack: () -> Unit) = Screen {
    val ctx = LocalContext.current
    var pin by remember { mutableStateOf(HostService.pin) }
    var on by remember { mutableStateOf(HostService.running) }
    var acc by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { while (true) { acc = RemoteAccess.instance != null; delay(1000) } }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    val pulse by rememberInfiniteTransition(label = "p").animateFloat(0.3f, 1f,
        infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "a")
    Header("Host", "🔒 Encrypted · this device will be controlled", onBack)
    Column(Modifier.padding(horizontal = 20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(12.dp).clip(CircleShape).background((if (on) Good else Muted).copy(alpha = if (on) pulse else 1f)))
                Spacer(Modifier.width(10.dp))
                Text(if (on) "Host is running" else "Host is stopped", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
            Spacer(Modifier.height(14.dp)); Label("YOUR IP ADDRESS")
            Text(localIps(), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Accent2)
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(pin, { pin = it.filter(Char::isLetterOrDigit).take(16) }, Modifier.fillMaxWidth(),
                label = { Text("Pairing code") }, supportingText = { Text("6–16 letters or digits. Enter the same code on the controller.") }, singleLine = true, shape = RoundedCornerShape(14.dp), colors = tfColors())
        }
        GradBtn(if (on) "Stop host" else "Start host",
            brush = if (on) Brush.linearGradient(listOf(Color(0xFFEF4444), Color(0xFFF97316))) else Grad) {
            if (!on && pin.length < 6) return@GradBtn
            if (Build.VERSION.SDK_INT >= 33) perm.launch(Manifest.permission.POST_NOTIFICATIONS)
            val i = Intent(ctx, HostService::class.java).putExtra("pin", pin)
            if (on) ctx.stopService(i) else ctx.startForegroundService(i)
            on = !on
        }
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(12.dp).clip(CircleShape).background(if (acc) Good else Bad))
                Spacer(Modifier.width(10.dp))
                Text(if (acc) "Mouse & keyboard: enabled" else "Mouse & keyboard: off", fontWeight = FontWeight.Bold)
            }
            Text("Media and volume work without this. Enable the Accessibility service to allow cursor, taps, scrolling and typing.",
                color = Muted, fontSize = 13.sp, modifier = Modifier.padding(vertical = 10.dp))
            GradBtn("Open Accessibility settings", brush = Brush.linearGradient(listOf(Color(0xFF334155), Color(0xFF475569)))) {
                ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        Spacer(Modifier.height(16.dp))
    }
}

// ---------- Connect ----------
@Composable fun Connect(onBack: () -> Unit, onConnected: (Client) -> Unit) = Screen {
    val ctx = LocalContext.current
    val found = remember { mutableStateListOf<Pair<String, String>>() }
    var ip by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    DisposableEffect(Unit) {
        val nsd = ctx.getSystemService(NsdManager::class.java)
        val l = object : NsdManager.DiscoveryListener {
            override fun onServiceFound(s: NsdServiceInfo) {
                nsd.resolveService(s, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(s: NsdServiceInfo, e: Int) {}
                    override fun onServiceResolved(r: NsdServiceInfo) {
                        val h = r.host?.hostAddress ?: return
                        if (found.none { it.second == h }) found.add(r.serviceName to h)
                    }
                })
            }
            override fun onServiceLost(s: NsdServiceInfo) {}
            override fun onDiscoveryStarted(t: String) {}
            override fun onDiscoveryStopped(t: String) {}
            override fun onStartDiscoveryFailed(t: String, e: Int) {}
            override fun onStopDiscoveryFailed(t: String, e: Int) {}
        }
        nsd.discoverServices("_lanremote._tcp.", NsdManager.PROTOCOL_DNS_SD, l)
        onDispose { try { nsd.stopServiceDiscovery(l) } catch (_: Exception) {} }
    }
    fun go(h: String) {
        busy = true; msg = ""
        val c = Client()
        c.connect(h, pin) { ok -> busy = false; if (ok) onConnected(c) else msg = "Couldn't connect. Check the IP, PIN and that the host is started." }
    }
    Header("Controller", "🔒 Encrypted · pick a host to control", onBack)
    Column(Modifier.padding(horizontal = 20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Panel {
            OutlinedTextField(pin, { pin = it.filter(Char::isLetterOrDigit).take(16) }, Modifier.fillMaxWidth(),
                label = { Text("Pairing code") }, singleLine = true, shape = RoundedCornerShape(14.dp), colors = tfColors())
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Label("NEARBY HOSTS"); Spacer(Modifier.width(10.dp))
            if (found.isEmpty()) CircularProgressIndicator(Modifier.size(14.dp), color = Accent2, strokeWidth = 2.dp)
        }
        if (found.isEmpty()) Text("Searching your network…", color = Muted, fontSize = 13.sp)
        found.forEach { (n, h) ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(CardC).border(1.dp, Edge, RoundedCornerShape(18.dp))
                .clickable { go(h) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("📺", fontSize = 26.sp); Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) { Text(n, fontWeight = FontWeight.Bold); Text(h, color = Accent2, fontSize = 13.sp) }
                Text("Connect ›", color = Muted)
            }
        }
        Label("OR ENTER IP MANUALLY")
        OutlinedTextField(ip, { ip = it }, Modifier.fillMaxWidth(), label = { Text("e.g. 192.168.1.20") },
            singleLine = true, shape = RoundedCornerShape(14.dp), colors = tfColors())
        GradBtn(if (busy) "Connecting…" else "Connect") { if (!busy && ip.isNotBlank()) go(ip.trim()) }
        if (msg.isNotEmpty()) Text(msg, color = Bad, fontSize = 13.sp)
        Spacer(Modifier.height(16.dp))
    }
}

// ---------- Remote ----------
@Composable fun Remote(c: Client, onExit: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth >= 840.dp
        Screen(if (wide) 1600.dp else 560.dp) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.clip(RoundedCornerShape(50)).background(Good.copy(alpha = 0.15f)).padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(Good)); Spacer(Modifier.width(8.dp))
                    Text("Connected · 🔒", color = Good, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.weight(1f))
                TextButton(onExit) { Text("Disconnect", color = Bad) }
            }
            Box(Modifier.weight(1f)) {
                if (wide) {
                    Row(Modifier.fillMaxSize()) {
                        Box(Modifier.weight(1f)) { MediaTab(c) }
                        Box(Modifier.weight(1.2f)) { Mouse(c) }
                        Box(Modifier.weight(1f)) { Keys(c) }
                    }
                } else {
                    when (tab) { 0 -> MediaTab(c); 1 -> Mouse(c); else -> Keys(c) }
                }
            }
            if (!wide) NavigationBar(containerColor = CardC) {
                listOf("🎵" to "Media", "🖱️" to "Mouse", "⌨️" to "Keyboard").forEachIndexed { i, (g, t) ->
                    NavigationBarItem(tab == i, { tab = i }, icon = { Text(g, fontSize = 22.sp) }, label = { Text(t) },
                        colors = NavigationBarItemDefaults.colors(indicatorColor = Accent.copy(alpha = 0.35f),
                            selectedTextColor = MaterialTheme.colorScheme.onSurface, unselectedTextColor = Muted))
                }
            }
        }
    }
}

@Composable fun MediaTab(c: Client) {
    Column(Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Panel {
            Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), Arrangement.SpaceEvenly, Alignment.CenterVertically) {
                RoundBtn("⏮", 64.dp) { c.send("media", "k" to "prev") }
                RoundBtn("▶", 104.dp, true) { c.send("media", "k" to "play_pause") }
                RoundBtn("⏭", 64.dp) { c.send("media", "k" to "next") }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Tile("⏪", "Rewind", Modifier.weight(1f)) { c.send("media", "k" to "rw") }
            Tile("⏹", "Stop", Modifier.weight(1f)) { c.send("media", "k" to "stop") }
            Tile("⏩", "Forward", Modifier.weight(1f)) { c.send("media", "k" to "ff") }
        }
        Panel {
            Label("VOLUME"); Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Tile("🔉", "Down", Modifier.weight(1f)) { c.send("vol", "k" to "down") }
                Tile("🔇", "Mute", Modifier.weight(1f)) { c.send("vol", "k" to "mute") }
                Tile("🔊", "Up", Modifier.weight(1f)) { c.send("vol", "k" to "up") }
            }
        }
    }
}

@Composable fun Mouse(c: Client) {
    var speed by remember { mutableFloatStateOf(1.6f) }
    val gain by rememberUpdatedState(speed)
    val shape = RoundedCornerShape(24.dp)
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.weight(1f).fillMaxHeight().clip(shape)
                .background(Brush.linearGradient(if (Pal.dark) listOf(Color(0xFF1E2750), Color(0xFF131A33)) else listOf(Color(0xFFEEF0FF), Color(0xFFDCE3FA)))).border(1.5.dp, Grad, shape)
                .pointerInput(Unit) { detectTapGestures(onTap = { c.send("click") }, onLongPress = { c.send("rclick") }) }
                .pointerInput(Unit) { detectDragGestures { ch, d -> ch.consume(); c.send("move", "dx" to d.x * gain, "dy" to d.y * gain) } },
                contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🖱️", fontSize = 38.sp); Text("Touchpad", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Drag to move · Tap to click\nHold for right-click", color = Muted, fontSize = 13.sp, textAlign = TextAlign.Center)
                }
            }
            Box(Modifier.width(60.dp).fillMaxHeight().clip(shape).background(CardC).border(1.dp, Edge, shape)
                .pointerInput(Unit) {
                    var a = 0f
                    detectVerticalDragGestures { ch, d -> ch.consume(); a += d; if (abs(a) > 30) { c.send("scroll", "dy" to a); a = 0f } }
                }, contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("▲", color = Accent2); Text("SCROLL", fontSize = 9.sp, color = Muted, fontWeight = FontWeight.Bold); Text("▼", color = Accent2)
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Tile("◧", "Left click", Modifier.weight(1f)) { c.send("click") }
            Tile("◨", "Right click", Modifier.weight(1f)) { c.send("rclick") }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Label("SPEED")
            Slider(speed, { speed = it }, Modifier.weight(1f).padding(start = 12.dp), valueRange = 0.8f..3.5f,
                colors = SliderDefaults.colors(thumbColor = Accent2, activeTrackColor = Accent))
        }
    }
}

@Composable fun Keys(c: Client) {
    var text by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Panel {
            Label("TYPE ON HOST"); Spacer(Modifier.height(10.dp))
            OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), minLines = 3, shape = RoundedCornerShape(14.dp),
                placeholder = { Text("Type something…") }, colors = tfColors())
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GradBtn("Send", Modifier.weight(1f)) { c.send("text", "s" to text); text = "" }
                GradBtn("Send + Enter", Modifier.weight(1f), Brush.linearGradient(listOf(Color(0xFF334155), Color(0xFF475569)))) {
                    c.send("text", "s" to text); c.send("key", "k" to "enter"); text = "" }
            }
        }
        Label("SPECIAL KEYS")
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Tile("⌫", "Backspace", Modifier.weight(1f)) { c.send("key", "k" to "backspace") }
            Tile("↵", "Enter", Modifier.weight(1f)) { c.send("key", "k" to "enter") }
            Tile("␣", "Space", Modifier.weight(1f)) { c.send("text", "s" to " ") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Tile("◀", "Back", Modifier.weight(1f)) { c.send("key", "k" to "back") }
            Tile("🏠", "Home", Modifier.weight(1f)) { c.send("key", "k" to "home") }
            Tile("▣", "Recents", Modifier.weight(1f)) { c.send("key", "k" to "recents") }
        }
    }
}
