package com.example.lanremote

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.ActivityInfo
import android.view.KeyEvent
import android.view.WindowManager
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.compose.foundation.text.selection.SelectionContainer
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.util.concurrent.Executors
import kotlin.math.abs
import android.util.Base64
import android.content.SharedPreferences
import android.content.res.Configuration
import java.util.concurrent.atomic.AtomicLong
import javax.crypto.spec.SecretKeySpec
import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlin.math.roundToInt
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.animation.core.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import kotlinx.coroutines.delay

data class PlayState(val title: String = "Not playing", val artist: String = "", val playing: Boolean = false,
    val pos: Long = 0, val dur: Long = 0, val vol: Int = 0, val max: Int = 1, val art: Bitmap? = null, val at: Long = 0,
    val spd: Float = 1f, val access: Boolean = true)

class Client {
    var st by mutableStateOf(PlayState())
    private var sock: Socket? = null
    private var out: PrintWriter? = null
    private var key: SecretKeySpec? = null
    private val seq = AtomicLong(0)
    private val ex = Executors.newSingleThreadExecutor()
    fun connect(host: String, pin: String, cb: (Boolean) -> Unit) = ex.execute {
        try {
            val s = Socket(); s.connect(InetSocketAddress(host, HostService.PORT), 4000); s.soTimeout = 6000; sock = s
            out = PrintWriter(s.getOutputStream(), true)
            val rd = BufferedReader(InputStreamReader(s.getInputStream()))
            key = Crypto.key(pin, Base64.decode(rd.readLine(), Base64.NO_WRAP))
            out!!.println(Crypto.enc(key!!, JSONObject().put("t", "auth").put("n", seq.incrementAndGet()).toString()))
            val r = rd.readLine()
            val ok = r != null && JSONObject(Crypto.dec(key!!, r)).optBoolean("ok")
            if (ok) {
                s.soTimeout = 0
                Thread {
                    try { while (true) { val l = rd.readLine() ?: break
                        val j = JSONObject(Crypto.dec(key!!, l)); if (j.optString("t") == "state") onState(j) } } catch (_: Exception) {}
                }.start()
            }
            cb(ok)
        } catch (e: Exception) { cb(false) }
    }
    fun send(t: String, vararg kv: Pair<String, Any>) = ex.execute {
        try {
            val j = JSONObject().put("t", t).put("n", seq.incrementAndGet()); kv.forEach { j.put(it.first, it.second) }
            out?.println(Crypto.enc(key!!, j.toString()))
        } catch (_: Exception) {}
    }
    /** Play/pause state shown immediately after a tap, until the host confirms it. */
    var optPlay by mutableStateOf<Boolean?>(null)
    fun togglePlay() { optPlay = !(optPlay ?: st.playing); send("media", "k" to "play_pause") }
    /** Volume the bar shows right after a change, before the host reports back. */
    var volOv by mutableStateOf<Float?>(null)
    fun setVol(f: Float) { volOv = f.coerceIn(0f, 1f); send("volset", "f" to f.coerceIn(0f, 1f)) }
    fun nudgeVol(dir: Int) {
        val m = st.max.coerceAtLeast(1)
        setVol((volOv ?: (st.vol.toFloat() / m)) + dir.toFloat() / m)
    }
    private fun onState(j: JSONObject) {
        val art = if (j.has("art")) j.optString("art").let { if (it.isEmpty()) (if (j.optString("title") == st.title) st.art else null) else Base64.decode(it, Base64.NO_WRAP).let { b -> BitmapFactory.decodeByteArray(b, 0, b.size) } } else st.art
        st = PlayState(j.optString("title"), j.optString("artist"), j.optBoolean("playing"), j.optLong("pos"), j.optLong("dur"),
            j.optInt("vol"), j.optInt("max", 1), art, System.currentTimeMillis(), j.optDouble("spd", 1.0).toFloat(), j.optBoolean("access", true))
        if (optPlay != null && optPlay == st.playing) optPlay = null
    }
    fun close() { try { sock?.close() } catch (_: Exception) {}; ex.shutdown() }
}

// ---------- Theme ----------
object Pal { var dark by mutableStateOf(true) }
lateinit var appPrefs: SharedPreferences
fun setDark(v: Boolean) { Pal.dark = v; appPrefs.edit().putBoolean("dark", v).apply() }
val Bg1 get() = if (Pal.dark) Color(0xFF0A0E1A) else Color(0xFFF4F6FF)
val Bg2 get() = if (Pal.dark) Color(0xFF151B33) else Color(0xFFE6EBFB)
val CardC get() = if (Pal.dark) Color(0xFF1A2140) else Color.White
val Muted get() = if (Pal.dark) Color(0xFF94A3B8) else Color(0xFF64748B)
val Edge get() = if (Pal.dark) Color(0x16FFFFFF) else Color(0x1A0F172A)
val Accent = Color(0xFF7C5CFF); val Accent2 = Color(0xFF22D3EE)
val Good = Color(0xFF34D399); val Bad = Color(0xFFF87171)
val Grad = Brush.linearGradient(listOf(Accent, Accent2))

class MainActivity : ComponentActivity() {
    /** While the remote screen is open the controller's volume buttons drive the host's volume bar. */
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val h = volKeyHandler
        if (h != null && (e.keyCode == KeyEvent.KEYCODE_VOLUME_UP || e.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)) {
            if (e.action == KeyEvent.ACTION_DOWN) h(if (e.keyCode == KeyEvent.KEYCODE_VOLUME_UP) 1 else -1)
            return true
        }
        return super.dispatchKeyEvent(e)
    }
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        appPrefs = getSharedPreferences("s", 0)
        AutoGrant.ensure(this)   // no-op unless granted over ADB
        Pal.dark = appPrefs.getBoolean("dark", (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES)
        setContent {
            MaterialTheme(colorScheme = if (Pal.dark) darkColorScheme(primary = Accent, background = Bg1, surface = Bg1) else lightColorScheme(primary = Accent, background = Bg1, surface = Bg1)) {
                Surface(Modifier.fillMaxSize(), color = Bg1) { App() }
            }
        }
    }
}

@Composable fun App() {
    var mode by remember { mutableStateOf<String?>(null) }
    var client by remember { mutableStateOf<Client?>(null) }
    val c = client
    when {
        mode == null -> Home { mode = it }
        mode == "host" -> HostScreen { mode = null }
        c == null -> Connect({ mode = null }) { client = it }
        else -> Remote(c) { c.close(); client = null; mode = null }
    }
}

// ---------- Reusable pieces ----------
@Composable fun Screen(maxW: Dp = 560.dp, content: @Composable ColumnScope.() -> Unit) {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Bg1, Bg2))).statusBarsPadding(),
        contentAlignment = Alignment.TopCenter) {
        Column(Modifier.widthIn(max = maxW).fillMaxSize(), content = content)
    }
}

@Composable fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxWidth().background(CardC, RoundedCornerShape(20.dp))
        .border(1.dp, Edge, RoundedCornerShape(20.dp)).padding(16.dp), content = content)
}

@Composable fun Label(t: String) = Text(t, fontSize = 11.sp, color = Muted, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)

@Composable fun GradBtn(text: String, modifier: Modifier = Modifier, brush: Brush = Grad, onClick: () -> Unit) {
    val h = LocalHapticFeedback.current
    Box(modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(16.dp)).background(brush)
        .clickable { h.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() },
        contentAlignment = Alignment.Center) {
        Text(text, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
    }
}

@Composable fun RoundBtn(glyph: String, size: Dp, filled: Boolean = false, onClick: () -> Unit) {
    val h = LocalHapticFeedback.current
    Box(Modifier.size(size).clip(CircleShape)
        .then(if (filled) Modifier.background(Grad) else Modifier.background(CardC).border(1.dp, Edge, CircleShape))
        .clickable { h.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() },
        contentAlignment = Alignment.Center) { Text(glyph, fontSize = (size.value * 0.38f).sp, color = if (filled) Color.White else LocalContentColor.current) }
}

@Composable fun Tile(glyph: String, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val h = LocalHapticFeedback.current
    Column(modifier.height(76.dp).clip(RoundedCornerShape(18.dp)).background(CardC)
        .border(1.dp, Edge, RoundedCornerShape(18.dp))
        .clickable { h.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() },
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(glyph, fontSize = 22.sp); Text(label, fontSize = 11.sp, color = Muted)
    }
}

@Composable fun Header(title: String, sub: String, onBack: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(20.dp, 16.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) { RoundBtn("←", 44.dp, onClick = onBack); Spacer(Modifier.width(14.dp)) }
        Column { Text(title, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold); Text(sub, color = Muted, fontSize = 13.sp) }
    }
}

@Composable fun tfColors() = OutlinedTextFieldDefaults.colors(focusedBorderColor = Accent2,
    unfocusedBorderColor = Color(0x33FFFFFF), cursorColor = Accent2, focusedLabelColor = Accent2, unfocusedLabelColor = Muted)

fun localIps(): String = NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }
    .filter { it is Inet4Address && !it.isLoopbackAddress }.joinToString { it.hostAddress ?: "" }.ifEmpty { "not on Wi-Fi" }

// ---------- Home ----------
@Composable fun ModeCard(icon: String, title: String, desc: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(CardC)
        .border(1.dp, Edge, RoundedCornerShape(24.dp)).clickable(onClick = onClick).padding(20.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(60.dp).clip(RoundedCornerShape(18.dp)).background(Grad), contentAlignment = Alignment.Center) {
            Text(icon, fontSize = 28.sp) }
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) { Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text(desc, color = Muted, fontSize = 13.sp) }
        Text("›", fontSize = 30.sp, color = Muted)
    }
}

@Composable fun Home(pick: (String) -> Unit) = Screen { Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
    Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.End) {
        RoundBtn(if (Pal.dark) "☀" else "🌙", 44.dp) { setDark(!Pal.dark) }
    }
    Spacer(Modifier.height(12.dp))
    Column(Modifier.padding(horizontal = 24.dp)) {
        Box(Modifier.size(68.dp).clip(RoundedCornerShape(22.dp)).background(Grad), contentAlignment = Alignment.Center) {
            Text("📡", fontSize = 32.sp) }
        Spacer(Modifier.height(18.dp))
        Text("LAN Remote", fontSize = 36.sp, fontWeight = FontWeight.ExtraBold)
        Text("Media, mouse and keyboard control\nover your Wi-Fi.", color = Muted, fontSize = 15.sp)
    }
    Spacer(Modifier.height(36.dp))
    Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        ModeCard("🎮", "Controller", "Use this device as the remote") { pick("controller") }
        ModeCard("📺", "Host", "Let another device control this one") { pick("host") }
    }
    Spacer(Modifier.height(28.dp))
    Text("Both devices must be on the same network", color = Muted, fontSize = 12.sp,
        modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 24.dp))
} }

// ---------- Host ----------
@Composable fun HostScreen(onBack: () -> Unit) = Screen {
    val ctx = LocalContext.current
    var pin by remember { mutableStateOf(HostService.pin) }
    var on by remember { mutableStateOf(HostService.running) }
    var acc by remember { mutableStateOf(false) }
    var nlOn by remember { mutableStateOf(false) }
    var auto by remember { mutableStateOf(false) }
    var native by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { while (true) { acc = RemoteAccess.instance != null; auto = AutoGrant.canWrite(ctx); native = NativeInput.connected
        nlOn = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners")?.contains(ctx.packageName) == true; delay(1000) } }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    val pulse by rememberInfiniteTransition(label = "p").animateFloat(0.3f, 1f,
        infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "a")
    Header("Host", "🔒 Encrypted · this device will be controlled", onBack)
    Column(Modifier.padding(horizontal = 20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(12.dp).clip(CircleShape).background((if (on) Good else Muted).copy(alpha = if (on) pulse else 1f)))
                Spacer(Modifier.width(10.dp))
                Text(if (on) "Host is running" else "Host is stopped", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
            Spacer(Modifier.height(14.dp)); Label("YOUR IP ADDRESS")
            Text(localIps(), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Accent2)
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(pin, { pin = it.filter(Char::isLetterOrDigit).take(16) }, Modifier.fillMaxWidth(),
                label = { Text("Pairing code") }, supportingText = { Text("6–16 letters or digits. Enter the same code on the controller.") }, singleLine = true, shape = RoundedCornerShape(14.dp), colors = tfColors())
        }
        val ip = hostIp()
        if (ip.contains('.')) Panel {
            Label("SCAN TO CONNECT"); Spacer(Modifier.height(10.dp))
            val qr = remember(pin, ip) { qrBitmap("LANREMOTE|$ip|$pin") }
            Image(qr.asImageBitmap(), "QR code", Modifier.size(200.dp).clip(RoundedCornerShape(12.dp)).align(Alignment.CenterHorizontally))
            Text("Open the Controller on the other device and tap Scan QR. The code contains your pairing code, so only show it to people you trust.",
                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
        }
        GradBtn(if (on) "Stop host" else "Start host",
            brush = if (on) Brush.linearGradient(listOf(Color(0xFFEF4444), Color(0xFFF97316))) else Grad) {
            if (!on && pin.length < 6) return@GradBtn
            if (Build.VERSION.SDK_INT >= 33) perm.launch(Manifest.permission.POST_NOTIFICATIONS)
            val i = Intent(ctx, HostService::class.java).putExtra("pin", pin)
            if (on) ctx.stopService(i) else ctx.startForegroundService(i)
            on = !on
        }
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(12.dp).clip(CircleShape).background(if (acc) Good else Bad))
                Spacer(Modifier.width(10.dp))
                Text(if (acc) "Mouse & keyboard: enabled" else "Mouse & keyboard: off", fontWeight = FontWeight.Bold)
            }
            Text("Media and volume work without this. Enable the Accessibility service to allow cursor, taps, scrolling and typing.",
                color = Muted, fontSize = 13.sp, modifier = Modifier.padding(vertical = 10.dp))
            GradBtn("Open Accessibility settings", brush = Brush.linearGradient(listOf(Color(0xFF334155), Color(0xFF475569)))) {
                ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(12.dp).clip(CircleShape).background(if (nlOn) Good else Bad))
                Spacer(Modifier.width(10.dp))
                Text(if (nlOn) "Now-playing info: enabled" else "Now-playing info: off", fontWeight = FontWeight.Bold)
            }
            Text("Lets the controller show the title, artwork and time bar, and seek.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(vertical = 10.dp))
            GradBtn("Open notification access", brush = Brush.linearGradient(listOf(Color(0xFF334155), Color(0xFF475569)))) {
                ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        }
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(12.dp).clip(CircleShape).background(if (native) Good else Bad))
                Spacer(Modifier.width(10.dp))
                Text(if (native) "Native mouse & keyboard: active" else "Native mouse & keyboard: not running", fontWeight = FontWeight.Bold)
            }
            Text("Real system mouse pointer and keyboard input, like a physical mouse/keyboard is plugged in. Start it from a PC with adb_setup " +
                "(re-run after a reboot). Until then the Accessibility fallback is used.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
        }
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(12.dp).clip(CircleShape).background(if (auto) Good else Bad))
                Spacer(Modifier.width(10.dp))
                Text(if (auto) "Permanent access: active" else "Permanent access: needs one ADB command", fontWeight = FontWeight.Bold)
            }
            Text("Connect this device to a PC with USB debugging on and run adb_setup.bat (Windows) or adb_setup.sh (Mac/Linux) from the project folder. " +
                "Or run this single command once:", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(vertical = 10.dp))
            SelectionContainer { Text("adb shell pm grant com.example.lanremote android.permission.WRITE_SECURE_SETTINGS", color = Accent2, fontSize = 12.sp) }
            Text("After that the app turns on and keeps Accessibility (mouse/keyboard) and notification access (media info) by itself, even after a reboot.",
                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 10.dp))
            if (auto) GradBtn("Re-apply now", brush = Brush.linearGradient(listOf(Color(0xFF334155), Color(0xFF475569)))) { AutoGrant.ensure(ctx, true) }
        }
        Spacer(Modifier.height(16.dp))
    }
}

// ---------- Connect ----------
@Composable fun Connect(onBack: () -> Unit, onConnected: (Client) -> Unit) = Screen {
    val ctx = LocalContext.current
    val found = remember { mutableStateListOf<Pair<String, String>>() }
    var ip by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    DisposableEffect(Unit) {
        val nsd = ctx.getSystemService(NsdManager::class.java)
        val l = object : NsdManager.DiscoveryListener {
            override fun onServiceFound(s: NsdServiceInfo) {
                nsd.resolveService(s, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(s: NsdServiceInfo, e: Int) {}
                    override fun onServiceResolved(r: NsdServiceInfo) {
                        val h = r.host?.hostAddress ?: return
                        if (found.none { it.second == h }) found.add(r.serviceName to h)
                    }
                })
            }
            override fun onServiceLost(s: NsdServiceInfo) {}
            override fun onDiscoveryStarted(t: String) {}
            override fun onDiscoveryStopped(t: String) {}
            override fun onStartDiscoveryFailed(t: String, e: Int) {}
            override fun onStopDiscoveryFailed(t: String, e: Int) {}
        }
        nsd.discoverServices("_lanremote._tcp.", NsdManager.PROTOCOL_DNS_SD, l)
        onDispose { try { nsd.stopServiceDiscovery(l) } catch (_: Exception) {} }
    }
    fun go(h: String) {
        busy = true; msg = ""
        val c = Client()
        c.connect(h, pin) { ok -> busy = false; if (ok) onConnected(c) else msg = "Couldn't connect. Check the IP, PIN and that the host is started." }
    }
    val scan = rememberLauncherForActivityResult(ScanContract()) { r ->
        r.contents?.split("|")?.let { p -> if (p.size == 3 && p[0] == "LANREMOTE") { pin = p[2]; go(p[1]) } }
    }
    Header("Controller", "🔒 Encrypted · pick a host to control", onBack)
    Column(Modifier.padding(horizontal = 20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        GradBtn("📷  Scan QR code") { scan.launch(ScanOptions().setBeepEnabled(false).setPrompt("Scan the QR shown on the host").setOrientationLocked(false)) }
        Panel {
            OutlinedTextField(pin, { pin = it.filter(Char::isLetterOrDigit).take(16) }, Modifier.fillMaxWidth(),
                label = { Text("Pairing code") }, singleLine = true, shape = RoundedCornerShape(14.dp), colors = tfColors())
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Label("NEARBY HOSTS"); Spacer(Modifier.width(10.dp))
            if (found.isEmpty()) CircularProgressIndicator(Modifier.size(14.dp), color = Accent2, strokeWidth = 2.dp)
        }
        if (found.isEmpty()) Text("Searching your network…", color = Muted, fontSize = 13.sp)
        found.forEach { (n, h) ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(CardC).border(1.dp, Edge, RoundedCornerShape(18.dp))
                .clickable { go(h) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("📺", fontSize = 26.sp); Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) { Text(n, fontWeight = FontWeight.Bold); Text(h, color = Accent2, fontSize = 13.sp) }
                Text("Connect ›", color = Muted)
            }
        }
        Label("OR ENTER IP MANUALLY")
        OutlinedTextField(ip, { ip = it }, Modifier.fillMaxWidth(), label = { Text("e.g. 192.168.1.20") },
            singleLine = true, shape = RoundedCornerShape(14.dp), colors = tfColors())
        GradBtn(if (busy) "Connecting…" else "Connect") { if (!busy && ip.isNotBlank()) go(ip.trim()) }
        if (msg.isNotEmpty()) Text(msg, color = Bad, fontSize = 13.sp)
        Spacer(Modifier.height(16.dp))
    }
}

// ---------- Remote (controller home screen) ----------
/** Hardware volume buttons of the controller are routed here while the remote screen is open. */
var volKeyHandler: ((Int) -> Unit)? = null

tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

@Composable fun Remote(c: Client, onExit: () -> Unit) {
    var fold by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    val toggleFull: () -> Unit = { c.send("fs"); fold = !fold }
    DisposableEffect(c) { volKeyHandler = { c.nudgeVol(it) }; onDispose { volKeyHandler = null } }
    // Full screen: landscape + hide status / navigation bars (swipe from the edge to peek at them).
    DisposableEffect(fold) {
        val act = ctx.findActivity()
        if (act != null) {
            val w = act.window
            val ic = WindowCompat.getInsetsController(w, w.decorView)
            if (fold) {
                act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                WindowCompat.setDecorFitsSystemWindows(w, false)
                w.attributes = w.attributes.apply { layoutInDisplayCutoutMode =
                    if (Build.VERSION.SDK_INT >= 30) WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                    else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES }
                ic.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                ic.hide(WindowInsetsCompat.Type.systemBars())
                w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            } else {
                act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                ic.show(WindowInsetsCompat.Type.systemBars())
                WindowCompat.setDecorFitsSystemWindows(w, true)
                w.attributes = w.attributes.apply { layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT }
                w.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }
        onDispose {}
    }
    DisposableEffect(Unit) { onDispose {
        ctx.findActivity()?.let { a ->
            a.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            WindowCompat.getInsetsController(a.window, a.window.decorView).show(WindowInsetsCompat.Type.systemBars())
            a.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    } }
    // Volume overlay disappears 1.5 s after the last change; optimistic play state is dropped if the host never confirms.
    LaunchedEffect(c.volOv) { if (c.volOv != null) { delay(1500); c.volOv = null } }
    LaunchedEffect(c.optPlay) { if (c.optPlay != null) { delay(1500); c.optPlay = null } }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        // landscape phones, tablets and unfolded foldables get the two-pane layout
        val wide = maxWidth > maxHeight || maxWidth >= 840.dp
        val compact = wide && maxHeight < 480.dp           // landscape phone
        val availH = maxHeight
        if (fold) FullMedia(c, toggleFull)
        else Screen(if (wide) 1600.dp else 640.dp) { HomeController(c, onExit, toggleFull, wide, compact, availH) }
    }
}

fun fmt(ms: Long): String {
    val s = ms / 1000; val h = s / 3600; val m = (s % 3600) / 60; val x = s % 60
    return "%02d:%02d:%02d".format(h, m, x)
}

// ----- icons (drawn, so they look the same on every device) -----
@Composable fun FullIcon(expand: Boolean, onClick: () -> Unit) {
    val col = LocalContentColor.current
    Box(Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onClick), Alignment.Center) {
        Canvas(Modifier.size(18.dp)) {
            val w = size.width; val k = w * 0.38f; val sw = 2.2.dp.toPx()
            fun l(x1: Float, y1: Float, x2: Float, y2: Float) = drawLine(col, Offset(x1, y1), Offset(x2, y2), sw, StrokeCap.Round)
            if (expand) {
                l(0f, 0f, k, 0f); l(0f, 0f, 0f, k); l(w, 0f, w - k, 0f); l(w, 0f, w, k)
                l(0f, w, k, w); l(0f, w, 0f, w - k); l(w, w, w - k, w); l(w, w, w, w - k)
            } else {
                l(k, 0f, k, k); l(0f, k, k, k); l(w - k, 0f, w - k, k); l(w, k, w - k, k)
                l(k, w, k, w - k); l(0f, w - k, k, w - k); l(w - k, w, w - k, w - k); l(w, w - k, w - k, w - k)
            }
        }
    }
}

/** Circular "skip 10 s" arrow. forward = clockwise (↻), otherwise counter-clockwise (↺). */
@Composable fun SkipIcon(forward: Boolean, size: Dp) {
    val col = LocalContentColor.current
    Box(Modifier.size(size), Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = this.size.width * 0.075f
            val pad = sw * 2f
            val r = (this.size.width - pad * 2) / 2f
            val c = center
            val startA = -50f; val sweep = 280f
            val flip = if (forward) 1f else -1f
            scale(flip, 1f, pivot = c) {
                drawArc(col, startA, sweep, false, Offset(pad, pad), Size(r * 2, r * 2), style = Stroke(sw, cap = StrokeCap.Round))
                val a = Math.toRadians((startA + sweep).toDouble())
                val px = c.x + r * cos(a).toFloat(); val py = c.y + r * sin(a).toFloat()
                val tx = -sin(a).toFloat(); val ty = cos(a).toFloat()      // clockwise tangent
                val nx = cos(a).toFloat(); val ny = sin(a).toFloat()       // outward normal
                val hl = sw * 3.2f; val hw = sw * 2.2f
                val head = Path().apply {
                    moveTo(px + tx * hl, py + ty * hl)
                    lineTo(px + nx * hw, py + ny * hw)
                    lineTo(px - nx * hw, py - ny * hw); close()
                }
                drawPath(head, col)
            }
        }
        Text("10", fontSize = (size.value * 0.30f).sp, fontWeight = FontWeight.Bold)
    }
}

@Composable fun PlayPauseIcon(playing: Boolean, size: Dp, tint: Color) {
    Canvas(Modifier.size(size)) {
        val w = this.size.width; val h = this.size.height
        if (playing) {
            val bw = w * 0.26f
            drawRoundRect(tint, Offset(w * 0.18f, h * 0.12f), Size(bw, h * 0.76f), CornerRadius(bw / 3))
            drawRoundRect(tint, Offset(w * 0.82f - bw, h * 0.12f), Size(bw, h * 0.76f), CornerRadius(bw / 3))
        } else {
            drawPath(Path().apply { moveTo(w * 0.22f, h * 0.10f); lineTo(w * 0.90f, h * 0.5f); lineTo(w * 0.22f, h * 0.90f); close() }, tint)
        }
    }
}

@Composable fun NavIcon(kind: Int, size: Dp = 22.dp) {
    val col = LocalContentColor.current
    Canvas(Modifier.size(size)) {
        val w = this.size.width; val sw = 2.2.dp.toPx()
        fun l(x1: Float, y1: Float, x2: Float, y2: Float) = drawLine(col, Offset(x1 * w, y1 * w), Offset(x2 * w, y2 * w), sw, StrokeCap.Round)
        when (kind) {
            0 -> { l(.12f, .5f, .88f, .5f); l(.12f, .5f, .42f, .2f); l(.12f, .5f, .42f, .8f) }          // back
            1 -> drawPath(Path().apply {                                                                    // home
                moveTo(.5f * w, .12f * w); lineTo(.1f * w, .48f * w); lineTo(.2f * w, .48f * w); lineTo(.2f * w, .86f * w)
                lineTo(.8f * w, .86f * w); lineTo(.8f * w, .48f * w); lineTo(.9f * w, .48f * w); close()
            }, col, style = Stroke(sw, join = StrokeJoin.Round))
            2 -> { l(.15f, .25f, .85f, .25f); l(.15f, .5f, .85f, .5f); l(.15f, .75f, .85f, .75f) }       // menu / recents
            else -> for (i in 0..2) for (j in 0..2) drawCircle(col, sw * 0.8f, Offset((.2f + .3f * i) * w, (.2f + .3f * j) * w)) // app drawer
        }
    }
}

@Composable fun PadBtn(modifier: Modifier = Modifier, onClick: () -> Unit, content: @Composable BoxScope.() -> Unit) {
    val h = LocalHapticFeedback.current
    Box(modifier.clip(RoundedCornerShape(14.dp)).background(CardC).border(1.dp, Edge, RoundedCornerShape(14.dp))
        .clickable { h.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() },
        contentAlignment = Alignment.Center, content = content)
}

// ----- media pieces -----
@Composable fun Seek(c: Client) {
    val st = c.st
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(100) } }
    var drag by remember { mutableStateOf<Float?>(null) }
    var release by remember { mutableIntStateOf(0) }
    LaunchedEffect(release) { if (release > 0) { delay(800); drag = null } }
    val playing = c.optPlay ?: st.playing
    val pos = if (playing) minOf(st.pos + ((now - st.at) * st.spd).toLong(), if (st.dur > 0) st.dur else Long.MAX_VALUE) else st.pos
    val frac = if (st.dur > 0) (pos.toFloat() / st.dur).coerceIn(0f, 1f) else 0f
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(fmt(if (drag != null) (drag!! * st.dur).toLong() else pos), fontSize = 12.sp, color = Muted)
            Text(fmt(st.dur), fontSize = 12.sp, color = Muted)
        }
        Slider(drag ?: frac, { drag = it }, Modifier.fillMaxWidth().height(28.dp), enabled = st.dur > 0,
            onValueChangeFinished = { drag?.let { c.send("seek", "ms" to (it * st.dur).toLong()) }; release++ },
            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Accent2))
    }
}

@Composable fun SkipTile(c: Client, forward: Boolean, size: Dp) {
    PadBtn(Modifier.size(size), { c.send("skip", "ms" to (if (forward) 10000L else -10000L)) }) { SkipIcon(forward, size * 0.62f) }
}

@Composable fun PlayCircle(c: Client, size: Dp) {
    val h = LocalHapticFeedback.current
    Box(Modifier.size(size).clip(CircleShape).background(Grad)
        .clickable { h.performHapticFeedback(HapticFeedbackType.TextHandleMove); c.togglePlay() },
        contentAlignment = Alignment.Center) { PlayPauseIcon(c.optPlay ?: c.st.playing, size * 0.46f, Color.White) }
}

@Composable fun VolumeBar(c: Client) {
    val st = c.st
    val frac = c.volOv ?: if (st.max > 0) st.vol.toFloat() / st.max else 0f
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("🔈", fontSize = 16.sp)
        Slider(frac, { c.setVol(it) }, Modifier.weight(1f).padding(horizontal = 8.dp).height(28.dp),
            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Accent))
        Text("🔊", fontSize = 16.sp)
    }
}

/** Media panel whose background is the thumbnail / cover art of whatever is playing on the host. */
@Composable fun MediaCard(c: Client, shape: RoundedCornerShape, modifier: Modifier, pad: PaddingValues,
                          arr: Arrangement.Vertical = Arrangement.Top, fillHeight: Boolean = false, clear: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    val art = c.st.art
    Box(modifier.clip(shape).background(CardC).border(1.dp, Edge, shape)) {
        if (art != null) {
            Image(art.asImageBitmap(), null, Modifier.matchParentSize().blur(if (clear) 3.dp else 10.dp), contentScale = ContentScale.Crop)
            Box(Modifier.matchParentSize().then(if (clear) Modifier.background(Brush.verticalGradient(listOf(Color(0x22000000), Color(0xAA000000))))
            else Modifier.background(Color(0x99000000))))   // scrim keeps controls readable; fullscreen keeps the thumbnail brighter at the top
        }
        CompositionLocalProvider(LocalContentColor provides (if (art != null) Color.White else LocalContentColor.current)) {
            Column(Modifier.fillMaxWidth().then(if (fillHeight) Modifier.fillMaxHeight() else Modifier).padding(pad),
                verticalArrangement = arr, content = content)
        }
    }
}

/** Full-screen media controls (landscape). The volume bar follows the controller's hardware volume buttons. */
@Composable fun FullMedia(c: Client, onExit: () -> Unit) {
    val ld = LocalLayoutDirection.current
    val cut = WindowInsets.displayCutout.asPaddingValues()
    val cs = cut.calculateStartPadding(ld); val ce = cut.calculateEndPadding(ld)
    BoxWithConstraints(Modifier.fillMaxSize()) {
        // button sizes follow the available height so it fits from small phones to tablets
        val tile = (maxHeight * 0.26f).coerceIn(44.dp, 110.dp)
        val vPad = if (maxHeight < 300.dp) 6.dp else 12.dp
        Box(Modifier.fillMaxSize()) {
            MediaCard(c, RoundedCornerShape(0.dp), Modifier.fillMaxSize(),
                PaddingValues(start = 24.dp + cs, end = 24.dp + ce, top = vPad, bottom = vPad), Arrangement.SpaceEvenly, true, clear = true) {
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly, Alignment.CenterVertically) {
                    SkipTile(c, true, tile); PlayCircle(c, tile * 1.2f); SkipTile(c, false, tile)
                }
                Seek(c)
                HorizontalDivider(color = Edge)
                VolumeBar(c)
            }
            Box(Modifier.align(Alignment.TopEnd).padding(top = 4.dp, end = 4.dp + ce)) {
                CompositionLocalProvider(LocalContentColor provides (if (c.st.art != null) Color.White else LocalContentColor.current)) { FullIcon(false, onExit) }
            }
        }
    }
}

// ----- mouse helpers -----
fun mMove(c: Client, dx: Float, dy: Float) = c.send("move", "dx" to dx, "dy" to dy)
fun mClick(c: Client, right: Boolean) = c.send(if (right) "rclick" else "click")
fun mScroll(c: Client, a: Float) = c.send("scroll", "dy" to a)

/** The controller's home screen: touchpad, buttons, media controls and text input. Adapts to phone / landscape / tablet. */
@SuppressLint("MissingPermission")
@Composable fun HomeController(c: Client, onExit: () -> Unit, onFull: () -> Unit, wide: Boolean, compact: Boolean, availH: Dp) {
    val ctx = LocalContext.current
    var speed by remember { mutableFloatStateOf(appPrefs.getFloat("speed", 1.6f)) }
    val gain by rememberUpdatedState(speed)
    var text by remember { mutableStateOf("") }
    val padShape = RoundedCornerShape(if (compact) 16.dp else 22.dp)
    val mShape = RoundedCornerShape(if (compact) 16.dp else 22.dp)
    val sendText = { if (text.isNotEmpty()) { c.send("text", "s" to text); text = "" } }
    val rowH = if (compact) 42.dp else 44.dp

    val statusBar: @Composable () -> Unit = {
        Row(Modifier.fillMaxWidth().padding(top = if (compact) 2.dp else 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.clip(RoundedCornerShape(50)).background(Good.copy(alpha = 0.15f)).padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).clip(CircleShape).background(Good)); Spacer(Modifier.width(6.dp))
                Text("Connected", color = Good, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.weight(1f))
            Text("Disconnect", color = Bad, fontSize = 13.sp, fontWeight = FontWeight.Medium,
                modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onExit).padding(horizontal = 10.dp, vertical = 6.dp))
        }
    }

    val padArea: @Composable (Modifier) -> Unit = { m ->
        Row(m, horizontalArrangement = Arrangement.spacedBy(if (compact) 8.dp else 10.dp)) {
            Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(if (compact) 6.dp else 8.dp)) {
                Box(Modifier.weight(1f).fillMaxWidth().clip(padShape)
                    .background(Brush.linearGradient(if (Pal.dark) listOf(Color(0xFF1E2750), Color(0xFF131A33)) else listOf(Color(0xFFEEF0FF), Color(0xFFDCE3FA))))
                    .border(1.5.dp, Grad, padShape)
                    .pointerInput(Unit) { detectTapGestures(onTap = { mClick(c, false) }, onLongPress = { mClick(c, true) }) }
                    .pointerInput(Unit) { detectDragGestures { ch, d -> ch.consume(); mMove(c, d.x * gain, d.y * gain) } },
                    contentAlignment = Alignment.Center) {
                    Text("Touchpad", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Muted)
                    c.volOv?.let {
                        Text("🔊 ${(it * 100).roundToInt()}%", Modifier.align(Alignment.TopCenter).padding(top = 10.dp)
                            .clip(RoundedCornerShape(50)).background(Color(0xCC000000)).padding(horizontal = 12.dp, vertical = 4.dp),
                            color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
                // sensitivity, right below the touchpad
                Row(Modifier.fillMaxWidth().height(28.dp), verticalAlignment = Alignment.CenterVertically) {
                    Label("SENSITIVITY")
                    Slider(speed, { speed = it }, Modifier.weight(1f).padding(start = 10.dp).height(28.dp), valueRange = 0.8f..3.5f,
                        onValueChangeFinished = { appPrefs.edit().putFloat("speed", speed).apply() },
                        colors = SliderDefaults.colors(thumbColor = Accent2, activeTrackColor = Accent))
                }
                if (compact) {
                    // landscape phone: L, R and the nav buttons share one row to save height
                    Row(Modifier.fillMaxWidth().height(rowH), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        PadBtn(Modifier.weight(1f).fillMaxHeight(), { mClick(c, false) }) { Text("L", fontWeight = FontWeight.Bold, fontSize = 17.sp) }
                        PadBtn(Modifier.weight(1f).fillMaxHeight(), { mClick(c, true) }) { Text("R", fontWeight = FontWeight.Bold, fontSize = 17.sp) }
                        PadBtn(Modifier.weight(1f).fillMaxHeight(), { c.send("key", "k" to "back") }) { NavIcon(0, 20.dp) }
                        PadBtn(Modifier.weight(1f).fillMaxHeight(), { c.send("key", "k" to "home") }) { NavIcon(1, 20.dp) }
                        PadBtn(Modifier.weight(1f).fillMaxHeight(), { c.send("key", "k" to "recents") }) { NavIcon(2, 20.dp) }
                    }
                } else {
                    Row(Modifier.fillMaxWidth().height(46.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PadBtn(Modifier.weight(1f).fillMaxHeight(), { mClick(c, false) }) { Text("L", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
                        PadBtn(Modifier.weight(1f).fillMaxHeight(), { mClick(c, true) }) { Text("R", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
                    }
                    Row(Modifier.fillMaxWidth().height(rowH), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PadBtn(Modifier.weight(1f).fillMaxHeight(), { c.send("key", "k" to "back") }) { NavIcon(0) }
                        PadBtn(Modifier.weight(1f).fillMaxHeight(), { c.send("key", "k" to "home") }) { NavIcon(1) }
                        PadBtn(Modifier.weight(1f).fillMaxHeight(), { c.send("key", "k" to "recents") }) { NavIcon(2) }
                    }
                }
            }
            Column(Modifier.width(if (compact) 46.dp else 52.dp).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(if (compact) 6.dp else 8.dp)) {
                // scroll strip: every finger movement is sent straight away so the host scrolls continuously
                Box(Modifier.weight(1f).fillMaxWidth().clip(padShape).background(CardC).border(1.dp, Edge, padShape)
                    .pointerInput(Unit) {
                        var a = 0f
                        detectVerticalDragGestures(onDragEnd = { a = 0f }, onDragCancel = { a = 0f }) { ch, d ->
                            ch.consume(); a += d
                            if (abs(a) >= 2f) { mScroll(c, a); a = 0f }
                        }
                    }, contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(if (compact) 4.dp else 10.dp)) {
                        Text("▲", color = Accent2, fontSize = 12.sp)
                        Text("S\nC\nR\nO\nL\nL", fontSize = 10.sp, color = Muted, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, lineHeight = 13.sp)
                        Text("▼", color = Accent2, fontSize = 12.sp)
                    }
                }
                // opens the app drawer on the controlled device
                PadBtn(Modifier.fillMaxWidth().height(rowH), { c.send("key", "k" to "drawer") }) { NavIcon(3, if (compact) 20.dp else 22.dp) }
            }
        }
    }

    val tile = if (compact) 46.dp else if (wide && availH >= 700.dp) 72.dp else 60.dp
    val media: @Composable (Modifier) -> Unit = { m ->
        val st = c.st
        MediaCard(c, mShape, m.fillMaxWidth(), PaddingValues(start = 12.dp, end = 12.dp, top = 0.dp, bottom = if (compact) 6.dp else 8.dp)) {
            Row(Modifier.fillMaxWidth().height(if (compact) 28.dp else 32.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(if (!st.access) "Host needs notification access (see Host screen / ADB setup)"
                     else st.title + (if (st.artist.isNotBlank()) " · " + st.artist else ""),
                    Modifier.weight(1f).padding(start = 4.dp), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = if (st.access) Muted else Bad)
                FullIcon(true, onFull)
            }
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly, Alignment.CenterVertically) {
                SkipTile(c, true, tile); PlayCircle(c, tile + 8.dp); SkipTile(c, false, tile)
            }
            Spacer(Modifier.height(4.dp))
            Seek(c)
        }
    }

    val input: @Composable () -> Unit = {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(text, { text = it }, Modifier.weight(1f), singleLine = true, shape = RoundedCornerShape(28.dp),
                placeholder = { Text("Input here") }, colors = tfColors(),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { sendText(); c.send("key", "k" to "enter") }))
            PadBtn(Modifier.size(48.dp), { c.send("key", "k" to "backspace") }) { Text("⌫", fontSize = 18.sp) }
            PadBtn(Modifier.size(48.dp), { sendText() }) { Text("➤", fontSize = 18.sp, color = Accent2) }
        }
    }

    val outer = Modifier.fillMaxSize().padding(horizontal = if (compact) 10.dp else 14.dp).padding(bottom = if (compact) 6.dp else 10.dp)
    when {
        // landscape phone / tablet / unfolded foldable: touchpad left, media + input right
        wide -> Column(outer, verticalArrangement = Arrangement.spacedBy(4.dp)) {
            statusBar()
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(if (compact) 10.dp else 14.dp)) {
                padArea(Modifier.weight(1.2f).fillMaxHeight())
                Box(Modifier.weight(1f).fillMaxHeight(), Alignment.Center) {
                    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(if (compact) 6.dp else 10.dp)) {
                        media(Modifier); input()
                    }
                }
            }
        }
        // short portrait screens: everything keeps a usable size and the page scrolls
        availH < 640.dp -> Column(outer.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            statusBar(); padArea(Modifier.fillMaxWidth().height(320.dp)); media(Modifier); input()
        }
        // normal portrait phone
        else -> Column(outer, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            statusBar(); padArea(Modifier.weight(1f).fillMaxWidth()); media(Modifier); input()
        }
    }
}

fun hostIp(): String = localIps().split(", ").first()

fun qrBitmap(text: String): Bitmap {
    val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 512, 512)
    val bmp = Bitmap.createBitmap(512, 512, Bitmap.Config.RGB_565)
    for (x in 0 until 512) for (y in 0 until 512) bmp.setPixel(x, y, if (m.get(x, y)) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
    return bmp
}

