package com.example.lanremote

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONObject

/** Mouse + keyboard injection. Needs the user to enable it in Accessibility settings. */
class RemoteAccess : AccessibilityService() {
    companion object {
        @Volatile var instance: RemoteAccess? = null
        fun handle(j: JSONObject) { instance?.run(j) }
    }
    private val ui = Handler(Looper.getMainLooper())
    private var x = 0f; private var y = 0f
    private var cursor: View? = null
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams

    override fun onServiceConnected() {
        instance = this
        val dm = resources.displayMetrics
        x = dm.widthPixels / 2f; y = dm.heightPixels / 2f
        wm = getSystemService(WindowManager::class.java)
        cursor = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xCCFF5252.toInt()); setStroke(3, Color.WHITE) }
        }
        lp = WindowManager.LayoutParams(40, 40, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START }
        place(); wm.addView(cursor, lp)
    }

    private fun place() { lp.x = x.toInt() - 20; lp.y = y.toInt() - 20; if (cursor?.isAttachedToWindow == true) wm.updateViewLayout(cursor, lp) }

    private fun run(j: JSONObject) = ui.post {
        val dm = resources.displayMetrics
        when (j.getString("t")) {
            "move" -> { x = (x + j.getDouble("dx").toFloat()).coerceIn(0f, dm.widthPixels - 1f)
                        y = (y + j.getDouble("dy").toFloat()).coerceIn(0f, dm.heightPixels - 1f); place() }
            "click" -> gesture(x, y, x, y, 50)
            "rclick" -> gesture(x, y, x, y, 700)
            "scroll" -> { val d = j.getDouble("dy").toFloat().coerceIn(-400f, 400f)
                          gesture(x, y, x, (y - d * 2).coerceIn(0f, dm.heightPixels - 1f), 250) }
            "text" -> edit { it + j.getString("s") }
            "key" -> when (j.getString("k")) {
                "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
                "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
                "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
                "backspace" -> edit { it.dropLast(1) }
                "enter" -> enter()
            }
        }
    }

    private fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long) {
        val p = Path().apply { moveTo(x1, y1); if (x1 != x2 || y1 != y2) lineTo(x2, y2) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, ms)).build(), null, null)
    }

    private fun edit(f: (String) -> String) {
        val n = findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return
        val cur = if (n.isShowingHintText) "" else n.text?.toString() ?: ""
        n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, f(cur)) })
    }

    private fun enter() {
        val n = findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return
        if (Build.VERSION.SDK_INT >= 30) n.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        else edit { it + "\n" }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: android.content.Intent?): Boolean {
        instance = null
        try { wm.removeView(cursor) } catch (_: Exception) {}
        return super.onUnbind(i)
    }
}
