package com.example.lanremote

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.exp
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONObject

/** Mouse + keyboard injection. Needs the user to enable it in Accessibility settings. */
class RemoteAccess : AccessibilityService() {
    companion object {
        @Volatile var instance: RemoteAccess? = null
        fun handle(j: JSONObject) { instance?.run(j) }
        /** Native server moved/clicked the real pointer: only mirror it with the overlay cursor (no gestures). */
        fun mirror(j: JSONObject) { instance?.mirrorMove(j) }
        /** 0 = no ad · 1 = ad playing, not skippable yet · 2 = a "Skip ad" button is on screen. */
        fun adState(): Int = instance?.adStateNow() ?: 0
    }
    private val ui = Handler(Looper.getMainLooper())
    private var x = 0f; private var y = 0f
    private var cursor: PointerView? = null
    private val hideCursor = Runnable { cursor?.visibility = View.GONE }
    private val IDLE_MS = 30_000L
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WindowManager::class.java)
        val rb = wm.currentWindowMetrics.bounds
        x = rb.width() / 2f; y = rb.height() / 2f
        val pv = PointerView(this); cursor = pv
        // One full-screen, touch-transparent window. The pointer is only *drawn* at a new place every frame (cheap and
        // eased), instead of asking the window manager to move a tiny window on every single touch event.
        lp = WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= 30) WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                                        else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        pv.target(x, y); pv.snap(); wm.addView(pv, lp); wake()
    }

    private fun realSize(): Pair<Int, Int> {
        val b = wm.currentWindowMetrics.bounds
        return Pair(b.width(), b.height())
    }

    private fun mirrorMove(j: JSONObject) = ui.post {
        if (j.optString("t") != "move") { wake(); return@post }
        val (w, h) = realSize()
        x = (x + j.getDouble("dx").toFloat()).coerceIn(0f, w - 1f)
        y = (y + j.getDouble("dy").toFloat()).coerceIn(0f, h - 1f); place(); wake()
    }

    private fun place() { cursor?.target(x, y) }

    /** Show the pointer and (re)start the 30 s idle timer. */
    private fun wake() {
        cursor?.let { if (it.visibility != View.VISIBLE) { it.visibility = View.VISIBLE; it.snap() } }
        ui.removeCallbacks(hideCursor); ui.postDelayed(hideCursor, IDLE_MS)
    }

    private fun run(j: JSONObject) = ui.post {
        val (rw, rh) = realSize()
        when (j.getString("t")) {
            "move" -> { x = (x + j.getDouble("dx").toFloat()).coerceIn(0f, rw - 1f)
                        y = (y + j.getDouble("dy").toFloat()).coerceIn(0f, rh - 1f); place(); wake(); if (dDrag) pumpDrag() }
            "down" -> { wake(); dDrag = true; dx0 = x; dy0 = y; dStroke = null; pumpDrag() }
            "up" -> { dDrag = false; pumpDrag() }
            "hscroll" -> hscroll(j.getDouble("dx").toFloat())
            "zoom" -> zoom(j.getDouble("f").toFloat())
            "click" -> { wake(); gesture(x, y, x, y, 50) }
            "rclick" -> { wake(); gesture(x, y, x, y, 700) }
            "scroll" -> scroll(j.getDouble("dy").toFloat())
            "fs" -> fullscreen()
            "skipad" -> skipAd()
            "text" -> edit { it + j.getString("s") }
            "key" -> when (j.getString("k")) {
                "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
                "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
                "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
                "drawer" -> openDrawer()
                "notif" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
                "quick" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
                "backspace" -> edit { it.dropLast(1) }
                "enter" -> enter()
            }
        }
    }

    // ---------- smooth, continuous scrolling ----------
    // One long finger-drag is kept alive (continueStroke) and extended with every incoming delta, so scrolling follows
    // the controller's finger without the stop/start stutter of many separate swipes.
    private var scrollStroke: GestureDescription.StrokeDescription? = null
    private var scrollX = 0f; private var scrollY = 0f
    private var pendingDy = 0f
    private var scrolling = false
    private val endScroll = Runnable { finishScroll() }

    private fun scroll(dy: Float) {
        wake()
        val accel = 2.5f + minOf(Math.abs(dy), 40f) / 10f          // faster drag = faster scroll
        pendingDy += -dy * accel
        ui.removeCallbacks(endScroll)
        if (!scrolling) pumpScroll()
    }

    private fun pumpScroll() {
        if (Math.abs(pendingDy) < 1f) { if (scrollStroke != null) ui.postDelayed(endScroll, 120); return }
        val h = resources.displayMetrics.heightPixels
        val top = h * 0.08f; val bot = h * 0.92f
        val d = pendingDy.coerceIn(-500f, 500f)
        if (scrollStroke == null) {
            scrollX = x; scrollY = y.coerceIn(top, bot)
            if (d < 0 && scrollY - top < 120f) scrollY = bot - 20f else if (d > 0 && bot - scrollY < 120f) scrollY = top + 20f
        }
        val ny = (scrollY + d).coerceIn(top, bot)
        val hitEdge = scrollY + d != ny
        val moved = ny - scrollY
        pendingDy -= if (hitEdge) pendingDy else moved            // at an edge: restart the drag from a fresh place
        val dur = (Math.abs(moved) / 4f).toLong().coerceIn(10L, 80L)
        val path = Path().apply { moveTo(scrollX, scrollY); lineTo(scrollX, ny) }
        val cont = !hitEdge
        val sd = scrollStroke?.continueStroke(path, 0, dur, cont) ?: GestureDescription.StrokeDescription(path, 0, dur, cont)
        scrolling = true
        val ok = dispatchGesture(GestureDescription.Builder().addStroke(sd).build(), object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { ui.post { scrolling = false; scrollY = ny; scrollStroke = if (cont) sd else null; pumpScroll() } }
            override fun onCancelled(g: GestureDescription?) { ui.post { scrolling = false; scrollStroke = null; pendingDy = 0f } }
        }, ui)
        if (!ok) { scrolling = false; scrollStroke = null; pendingDy = 0f }
    }

    private fun finishScroll() {
        val st = scrollStroke ?: return
        if (scrolling) return
        val path = Path().apply { moveTo(scrollX, scrollY); lineTo(scrollX, scrollY) }
        scrolling = true
        val ok = dispatchGesture(GestureDescription.Builder().addStroke(st.continueStroke(path, 0, 10, false)).build(), object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { ui.post { scrolling = false; scrollStroke = null; pumpScroll() } }
            override fun onCancelled(g: GestureDescription?) { ui.post { scrolling = false; scrollStroke = null } }
        }, ui)
        if (!ok) { scrolling = false; scrollStroke = null }
    }

    // ---------- drag (tap-tap-hold-move): one long stroke that is extended with every pointer move ----------
    private var dStroke: GestureDescription.StrokeDescription? = null
    private var dDrag = false; private var dBusy = false
    private var dx0 = 0f; private var dy0 = 0f

    private fun pumpDrag() {
        if (dBusy) return
        val ending = !dDrag
        if (ending && dStroke == null) return
        val tx = x; val ty = y
        if (!ending && dStroke != null && tx == dx0 && ty == dy0) return
        val path = Path().apply { moveTo(dx0, dy0); if (tx != dx0 || ty != dy0) lineTo(tx, ty) }
        val cont = !ending
        val dur = if (dStroke == null) 400L else if (ending) 20L else 30L   // first stroke = the long-press hold
        val sd = dStroke?.continueStroke(path, 0, dur, cont) ?: GestureDescription.StrokeDescription(path, 0, dur, cont)
        dBusy = true
        val ok = dispatchGesture(GestureDescription.Builder().addStroke(sd).build(), object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { ui.post { dBusy = false; dx0 = tx; dy0 = ty; dStroke = if (cont) sd else null; pumpDrag() } }
            override fun onCancelled(g: GestureDescription?) { ui.post { dBusy = false; dStroke = null; dDrag = false } }
        }, ui)
        if (!ok) { dBusy = false; dStroke = null; dDrag = false }
    }

    // ---------- horizontal scroll and pinch zoom (fallback when the native server is not running) ----------
    private var hAcc = 0f
    private fun hscroll(dx: Float) {
        wake(); hAcc += -dx * 3f
        if (Math.abs(hAcc) < 60f) return
        val (w, _) = realSize()
        val d = hAcc.coerceIn(-400f, 400f); hAcc = 0f
        val sx = x.coerceIn(60f, w - 60f)
        gesture(sx, y, (sx + d).coerceIn(10f, w - 10f), y, 90)
    }

    private var zAcc = 1f; private var zBusy = false
    private fun zoom(f: Float) {
        wake(); zAcc = (zAcc * f).coerceIn(0.4f, 2.5f)
        if (zBusy || Math.abs(zAcc - 1f) < 0.08f) return
        val (w, _) = realSize()
        val r0 = 110f * resources.displayMetrics.density; val r1 = r0 * zAcc; zAcc = 1f
        val m = maxOf(r0, r1) + 10f
        val cx = if (w > 2 * m) x.coerceIn(m, w - m) else w / 2f
        fun line(sign: Float) = GestureDescription.StrokeDescription(Path().apply { moveTo(cx + sign * r0, y); lineTo(cx + sign * r1, y) }, 0, 140)
        zBusy = true
        val ok = dispatchGesture(GestureDescription.Builder().addStroke(line(-1f)).addStroke(line(1f)).build(), object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { ui.post { zBusy = false } }
            override fun onCancelled(g: GestureDescription?) { ui.post { zBusy = false } }
        }, ui)
        if (!ok) zBusy = false
    }

    /** Opens the app drawer: system "all apps" action on Android 12L+, else Home + swipe up. */
    private fun openDrawer() {
        if (Build.VERSION.SDK_INT >= 32 && performGlobalAction(GLOBAL_ACTION_ACCESSIBILITY_ALL_APPS)) return
        performGlobalAction(GLOBAL_ACTION_HOME)
        ui.postDelayed({
            val dm = resources.displayMetrics
            val cx = dm.widthPixels / 2f
            gesture(cx, dm.heightPixels * 0.92f, cx, dm.heightPixels * 0.35f, 250)
        }, 400)
    }

    private fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long) {
        val p = Path().apply { moveTo(x1, y1); if (x1 != x2 || y1 != y2) lineTo(x2, y2) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, ms)).build(), null, null)
    }

    private fun edit(f: (String) -> String) {
        val n = findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return
        val cur = if (n.isShowingHintText) "" else n.text?.toString() ?: ""
        n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, f(cur)) })
    }

    /** Clicks any on-screen button whose text/description says "full screen" (toggles enter/exit). */
    private fun fullscreen() {
        val root = rootInActiveWindow ?: return
        for (w in listOf("full screen", "fullscreen", "full-screen")) {
            val n = root.findAccessibilityNodeInfosByText(w).firstOrNull() ?: continue
            var t: AccessibilityNodeInfo? = n
            while (t != null && !t.isClickable) t = t.parent
            if (t != null) { t.performAction(AccessibilityNodeInfo.ACTION_CLICK); return }
        }
    }

    // ---------- ad detection (YouTube and others): lets the controller show a "Skip ad" button ----------
    @Volatile private var adCache = 0
    @Volatile private var adAt = 0L

    /** Cached for 350 ms, called from the host's state thread. */
    fun adStateNow(): Int {
        val now = SystemClock.elapsedRealtime()
        if (now - adAt < 350) return adCache
        adAt = now
        adCache = try { scanAd() } catch (_: Exception) { 0 }
        return adCache
    }

    private fun scanAd(): Int {
        val root = rootInActiveWindow ?: return 0
        val skip = findSkip(root)
        if (skip != null) {
            val label = (skip.text ?: skip.contentDescription)?.toString() ?: ""
            return if (label.any { it.isDigit() }) 1 else 2          // "Skip in 5" = counting down, not skippable yet
        }
        val pkg = root.packageName?.toString() ?: return 0
        if (pkg.contains("youtube")) {
            if (root.findAccessibilityNodeInfosByViewId("$pkg:id/ad_progress_text").isNotEmpty()) return 1
            for (t in listOf("Visit advertiser", "My Ad Center", "Why this ad"))
                if (root.findAccessibilityNodeInfosByText(t).isNotEmpty()) return 1
        }
        return 0
    }

    private fun findSkip(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val pkg = root.packageName?.toString() ?: ""
        val yt = pkg.contains("youtube")
        if (yt) for (id in listOf("skip_ad_button", "skip_ad_button_container", "modern_skip_button", "skip_ad_text"))
            root.findAccessibilityNodeInfosByViewId("$pkg:id/$id").firstOrNull { it.isVisibleToUser }?.let { return it }
        for (t in listOf("Skip ad", "Skip ads"))
            root.findAccessibilityNodeInfosByText(t).firstOrNull { it.isVisibleToUser }?.let { return it }
        if (yt) root.findAccessibilityNodeInfosByText("Skip").firstOrNull {
            it.isVisibleToUser && ((it.text ?: it.contentDescription)?.toString()?.trim().equals("Skip", true)) }?.let { return it }
        return null
    }

    /** Presses the on-screen "Skip ad" button of the app in front. */
    private fun skipAd() {
        val root = rootInActiveWindow ?: return
        val n = findSkip(root) ?: return
        var t: AccessibilityNodeInfo? = n
        while (t != null && !t.isClickable) t = t.parent
        if (t != null && t.performAction(AccessibilityNodeInfo.ACTION_CLICK)) { adAt = 0L; return }
        val b = android.graphics.Rect(); n.getBoundsInScreen(b)          // not exposed as clickable: tap its centre
        if (!b.isEmpty) gesture(b.exactCenterX(), b.exactCenterY(), b.exactCenterX(), b.exactCenterY(), 50)
        adAt = 0L
    }

    private fun enter() {
        val n = findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return
        if (Build.VERSION.SDK_INT >= 30) n.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        else edit { it + "\n" }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: android.content.Intent?): Boolean {
        instance = null
        ui.removeCallbacks(hideCursor); ui.removeCallbacks(endScroll)
        try { wm.removeView(cursor) } catch (_: Exception) {}
        return super.onUnbind(i)
    }
}

/**
 * Classic arrow mouse pointer, drawn inside a full-screen overlay. The tip (hotspot) is at (x, y) in screen coordinates.
 * The drawn position eases towards the target every frame (≈20 ms time constant), so the pointer glides even though
 * touch events arrive in small, uneven steps over Wi-Fi.
 */
class PointerView(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val k = 1.5f * d
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 1.3f * d; strokeJoin = Paint.Join.ROUND }
    private val path = android.graphics.Path().apply {
        moveTo(1f * k, 1f * k); lineTo(1f * k, 17.5f * k); lineTo(5f * k, 13.5f * k); lineTo(8f * k, 20f * k)
        lineTo(10.5f * k, 19f * k); lineTo(7.5f * k, 12.5f * k); lineTo(13f * k, 12.5f * k); close()
    }
    private var tx = 0f; private var ty = 0f      // where the pointer should be
    private var cx = 0f; private var cy = 0f      // where it is drawn
    private var lastFrame = 0L
    private val loc = IntArray(2)

    fun target(x: Float, y: Float) { tx = x; ty = y; invalidate() }
    fun snap() { cx = tx; cy = ty; lastFrame = 0L; invalidate() }

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = if (lastFrame == 0L) 8L else (now - lastFrame).coerceIn(1L, 50L)
        lastFrame = now
        val a = 1f - exp(-dt / 20f)
        cx += (tx - cx) * a; cy += (ty - cy) * a
        val moving = abs(tx - cx) > 0.4f || abs(ty - cy) > 0.4f
        if (!moving) { cx = tx; cy = ty }
        getLocationOnScreen(loc)
        c.save(); c.translate(cx - loc[0], cy - loc[1]); c.drawPath(path, fill); c.drawPath(path, line); c.restore()
        if (moving) postInvalidateOnAnimation() else lastFrame = 0L
    }
}
