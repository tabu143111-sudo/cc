package com.example.lanremote

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONObject

/** Mouse + keyboard injection. Needs the user to enable it in Accessibility settings. */
class RemoteAccess : AccessibilityService() {
    companion object {
        @Volatile var instance: RemoteAccess? = null
        fun handle(j: JSONObject) { instance?.run(j) }
        /** Native server moved/clicked the real pointer: only mirror it with the overlay cursor (no gestures). */
        fun mirror(j: JSONObject) { instance?.mirrorMove(j) }
    }
    private val ui = Handler(Looper.getMainLooper())
    private var x = 0f; private var y = 0f
    private var cursor: PointerView? = null
    private val hideCursor = Runnable { cursor?.visibility = View.GONE }
    private val IDLE_MS = 30_000L
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WindowManager::class.java)
        val rb = wm.currentWindowMetrics.bounds
        x = rb.width() / 2f; y = rb.height() / 2f
        val pv = PointerView(this); cursor = pv
        lp = WindowManager.LayoutParams(pv.w, pv.h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START }
        place(); wm.addView(cursor, lp); wake()
    }

    private fun realSize(): Pair<Int, Int> {
        val b = wm.currentWindowMetrics.bounds
        return Pair(b.width(), b.height())
    }

    private fun mirrorMove(j: JSONObject) = ui.post {
        if (j.optString("t") != "move") { wake(); return@post }
        val (w, h) = realSize()
        x = (x + j.getDouble("dx").toFloat()).coerceIn(0f, w - 1f)
        y = (y + j.getDouble("dy").toFloat()).coerceIn(0f, h - 1f); place(); wake()
    }

    private fun place() { lp.x = x.toInt(); lp.y = y.toInt(); if (cursor?.isAttachedToWindow == true) wm.updateViewLayout(cursor, lp) }

    /** Show the pointer and (re)start the 30 s idle timer. */
    private fun wake() {
        cursor?.visibility = View.VISIBLE
        ui.removeCallbacks(hideCursor); ui.postDelayed(hideCursor, IDLE_MS)
    }

    private fun run(j: JSONObject) = ui.post {
        val (rw, rh) = realSize()
        when (j.getString("t")) {
            "move" -> { x = (x + j.getDouble("dx").toFloat()).coerceIn(0f, rw - 1f)
                        y = (y + j.getDouble("dy").toFloat()).coerceIn(0f, rh - 1f); place(); wake(); if (dDrag) pumpDrag() }
            "down" -> { wake(); dDrag = true; dx0 = x; dy0 = y; dStroke = null; pumpDrag() }
            "up" -> { dDrag = false; pumpDrag() }
            "hscroll" -> hscroll(j.getDouble("dx").toFloat())
            "zoom" -> zoom(j.getDouble("f").toFloat())
            "click" -> { wake(); gesture(x, y, x, y, 50) }
            "rclick" -> { wake(); gesture(x, y, x, y, 700) }
            "scroll" -> scroll(j.getDouble("dy").toFloat())
            "fs" -> fullscreen()
            "text" -> edit { it + j.getString("s") }
            "key" -> when (j.getString("k")) {
                "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
                "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
                "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
                "drawer" -> openDrawer()
                "notif" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
                "quick" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
                "backspace" -> edit { it.dropLast(1) }
                "enter" -> enter()
            }
        }
    }

    // ---------- smooth, continuous scrolling ----------
    // One long finger-drag is kept alive (continueStroke) and extended with every incoming delta, so scrolling follows
    // the controller's finger without the stop/start stutter of many separate swipes.
    private var scrollStroke: GestureDescription.StrokeDescription? = null
    private var scrollX = 0f; private var scrollY = 0f
    private var pendingDy = 0f
    private var scrolling = false
    private val endScroll = Runnable { finishScroll() }

    private fun scroll(dy: Float) {
        wake()
        val accel = 2.5f + minOf(Math.abs(dy), 40f) / 10f          // faster drag = faster scroll
        pendingDy += -dy * accel
        ui.removeCallbacks(endScroll)
        if (!scrolling) pumpScroll()
    }

    private fun pumpScroll() {
        if (Math.abs(pendingDy) < 1f) { if (scrollStroke != null) ui.postDelayed(endScroll, 120); return }
        val h = resources.displayMetrics.heightPixels
        val top = h * 0.08f; val bot = h * 0.92f
        val d = pendingDy.coerceIn(-500f, 500f)
        if (scrollStroke == null) {
            scrollX = x; scrollY = y.coerceIn(top, bot)
            if (d < 0 && scrollY - top < 120f) scrollY = bot - 20f else if (d > 0 && bot - scrollY < 120f) scrollY = top + 20f
        }
        val ny = (scrollY + d).coerceIn(top, bot)
        val hitEdge = scrollY + d != ny
        val moved = ny - scrollY
        pendingDy -= if (hitEdge) pendingDy else moved            // at an edge: restart the drag from a fresh place
        val dur = (Math.abs(moved) / 4f).toLong().coerceIn(10L, 80L)
        val path = Path().apply { moveTo(scrollX, scrollY); lineTo(scrollX, ny) }
        val cont = !hitEdge
        val sd = scrollStroke?.continueStroke(path, 0, dur, cont) ?: GestureDescription.StrokeDescription(path, 0, dur, cont)
        scrolling = true
        val ok = dispatchGesture(GestureDescription.Builder().addStroke(sd).build(), object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { ui.post { scrolling = false; scrollY = ny; scrollStroke = if (cont) sd else null; pumpScroll() } }
            override fun onCancelled(g: GestureDescription?) { ui.post { scrolling = false; scrollStroke = null; pendingDy = 0f } }
        }, ui)
        if (!ok) { scrolling = false; scrollStroke = null; pendingDy = 0f }
    }

    private fun finishScroll() {
        val st = scrollStroke ?: return
        if (scrolling) return
        val path = Path().apply { moveTo(scrollX, scrollY); lineTo(scrollX, scrollY) }
        scrolling = true
        val ok = dispatchGesture(GestureDescription.Builder().addStroke(st.continueStroke(path, 0, 10, false)).build(), object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { ui.post { scrolling = false; scrollStroke = null; pumpScroll() } }
            override fun onCancelled(g: GestureDescription?) { ui.post { scrolling = false; scrollStroke = null } }
        }, ui)
        if (!ok) { scrolling = false; scrollStroke = null }
    }

    // ---------- drag (tap-tap-hold-move): one long stroke that is extended with every pointer move ----------
    private var dStroke: GestureDescription.StrokeDescription? = null
    private var dDrag = false; private var dBusy = false
    private var dx0 = 0f; private var dy0 = 0f

    private fun pumpDrag() {
        if (dBusy) return
        val ending = !dDrag
        if (ending && dStroke == null) return
        val tx = x; val ty = y
        if (!ending && dStroke != null && tx == dx0 && ty == dy0) return
        val path = Path().apply { moveTo(dx0, dy0); if (tx != dx0 || ty != dy0) lineTo(tx, ty) }
        val cont = !ending
        val dur = if (dStroke == null) 400L else if (ending) 20L else 30L   // first stroke = the long-press hold
        val sd = dStroke?.continueStroke(path, 0, dur, cont) ?: GestureDescription.StrokeDescription(path, 0, dur, cont)
        dBusy = true
        val ok = dispatchGesture(GestureDescription.Builder().addStroke(sd).build(), object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { ui.post { dBusy = false; dx0 = tx; dy0 = ty; dStroke = if (cont) sd else null; pumpDrag() } }
            override fun onCancelled(g: GestureDescription?) { ui.post { dBusy = false; dStroke = null; dDrag = false } }
        }, ui)
        if (!ok) { dBusy = false; dStroke = null; dDrag = false }
    }

    // ---------- horizontal scroll and pinch zoom (fallback when the native server is not running) ----------
    private var hAcc = 0f
    private fun hscroll(dx: Float) {
        wake(); hAcc += -dx * 3f
        if (Math.abs(hAcc) < 60f) return
        val (w, _) = realSize()
        val d = hAcc.coerceIn(-400f, 400f); hAcc = 0f
        val sx = x.coerceIn(60f, w - 60f)
        gesture(sx, y, (sx + d).coerceIn(10f, w - 10f), y, 90)
    }

    private var zAcc = 1f; private var zBusy = false
    private fun zoom(f: Float) {
        wake(); zAcc = (zAcc * f).coerceIn(0.4f, 2.5f)
        if (zBusy || Math.abs(zAcc - 1f) < 0.08f) return
        val (w, _) = realSize()
        val r0 = 110f * resources.displayMetrics.density; val r1 = r0 * zAcc; zAcc = 1f
        val m = maxOf(r0, r1) + 10f
        val cx = if (w > 2 * m) x.coerceIn(m, w - m) else w / 2f
        fun line(sign: Float) = GestureDescription.StrokeDescription(Path().apply { moveTo(cx + sign * r0, y); lineTo(cx + sign * r1, y) }, 0, 140)
        zBusy = true
        val ok = dispatchGesture(GestureDescription.Builder().addStroke(line(-1f)).addStroke(line(1f)).build(), object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { ui.post { zBusy = false } }
            override fun onCancelled(g: GestureDescription?) { ui.post { zBusy = false } }
        }, ui)
        if (!ok) zBusy = false
    }

    /** Opens the app drawer: system "all apps" action on Android 12L+, else Home + swipe up. */
    private fun openDrawer() {
        if (Build.VERSION.SDK_INT >= 32 && performGlobalAction(GLOBAL_ACTION_ACCESSIBILITY_ALL_APPS)) return
        performGlobalAction(GLOBAL_ACTION_HOME)
        ui.postDelayed({
            val dm = resources.displayMetrics
            val cx = dm.widthPixels / 2f
            gesture(cx, dm.heightPixels * 0.92f, cx, dm.heightPixels * 0.35f, 250)
        }, 400)
    }

    private fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long) {
        val p = Path().apply { moveTo(x1, y1); if (x1 != x2 || y1 != y2) lineTo(x2, y2) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, ms)).build(), null, null)
    }

    private fun edit(f: (String) -> String) {
        val n = findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return
        val cur = if (n.isShowingHintText) "" else n.text?.toString() ?: ""
        n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, f(cur)) })
    }

    /** Clicks any on-screen button whose text/description says "full screen" (toggles enter/exit). */
    private fun fullscreen() {
        val root = rootInActiveWindow ?: return
        for (w in listOf("full screen", "fullscreen", "full-screen")) {
            val n = root.findAccessibilityNodeInfosByText(w).firstOrNull() ?: continue
            var t: AccessibilityNodeInfo? = n
            while (t != null && !t.isClickable) t = t.parent
            if (t != null) { t.performAction(AccessibilityNodeInfo.ACTION_CLICK); return }
        }
    }

    private fun enter() {
        val n = findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return
        if (Build.VERSION.SDK_INT >= 30) n.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        else edit { it + "\n" }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: android.content.Intent?): Boolean {
        instance = null
        ui.removeCallbacks(hideCursor); ui.removeCallbacks(endScroll)
        try { wm.removeView(cursor) } catch (_: Exception) {}
        return super.onUnbind(i)
    }
}

/** Classic arrow mouse pointer. The tip (hotspot) is the top-left corner of the view. */
class PointerView(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val k = 1.5f * d
    val w = (14 * k).toInt(); val h = (21 * k).toInt()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 1.3f * d; strokeJoin = Paint.Join.ROUND }
    private val path = android.graphics.Path().apply {
        moveTo(1f * k, 1f * k); lineTo(1f * k, 17.5f * k); lineTo(5f * k, 13.5f * k); lineTo(8f * k, 20f * k)
        lineTo(10.5f * k, 19f * k); lineTo(7.5f * k, 12.5f * k); lineTo(13f * k, 12.5f * k); close()
    }
    override fun onDraw(c: Canvas) { c.drawPath(path, fill); c.drawPath(path, line) }
}
