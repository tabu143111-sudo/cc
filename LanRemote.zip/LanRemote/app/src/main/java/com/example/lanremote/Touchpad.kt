package com.example.lanremote

import android.os.SystemClock
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.math.abs
import kotlin.math.hypot

/**
 * Laptop-style multi-touch touchpad.
 *  1 finger : move · tap = click · double-tap = double click · tap, then touch and drag = drag / select · hold = right click
 *  2 fingers: drag = scroll (vertical + horizontal, with momentum) · pinch = zoom · tap = right click
 *  3 fingers: swipe up = Recents · down = Home · left = Back · right = App drawer
 *  4 fingers: swipe down = Notifications · up = Quick settings · left = Back · right = Recents
 */
fun Modifier.touchpad(c: Client, scope: CoroutineScope, gain: () -> Float, natural: () -> Boolean, hint: (String) -> Unit): Modifier =
    pointerInput(Unit) {
        val slop = viewConfiguration.touchSlop
        val swipeDist = 64.dp.toPx()
        var lastTapUp = 0L
        var fling: Job? = null

        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false)
            fling?.cancel()
            val t0 = down.uptimeMillis
            val secondTap = lastTapUp != 0L && t0 - lastTapUp < 220
            var prevN = 1; var maxF = 1
            var last = down.position
            var lastDist = 0f
            var oneTravel = 0f                 // total single-finger movement
            var multiTravel = 0f               // total centroid movement with 2+ fingers
            var distTravel = 0f                // total pinch distance change
            var ax = 0f; var ay = 0f           // accumulated centroid movement (axis lock / swipe distance)
            var mode = 0                       // 2-finger gestures: 0 undecided · 1 scroll · 2 pinch
            var dragging = false; var longPressed = false; var fired = false; var scrolled = false
            var upT = t0
            val vt = VelocityTracker()
            val sgn = if (natural()) -1f else 1f

            while (true) {
                val canLong = maxF == 1 && !longPressed && !dragging && !secondTap && oneTravel <= slop
                val ev = if (canLong) {
                    val rem = t0 + 500L - SystemClock.uptimeMillis()
                    if (rem <= 0L) null else withTimeoutOrNull(rem) { awaitPointerEvent(PointerEventPass.Main) }
                } else awaitPointerEvent(PointerEventPass.Main)
                if (ev == null) { longPressed = true; c.send("rclick"); hint("Right click"); continue }

                val pressed = ev.changes.filter { it.pressed }
                if (pressed.isEmpty()) { upT = ev.changes.maxOf { it.uptimeMillis }; ev.changes.forEach { it.consume() }; break }
                val n = pressed.size
                maxF = maxOf(maxF, n)
                val cen = pressed.fold(Offset.Zero) { acc, p -> acc + p.position } / n.toFloat()
                val dist = if (n >= 2) hypot(pressed[0].position.x - pressed[1].position.x, pressed[0].position.y - pressed[1].position.y) else 0f
                ev.changes.forEach { it.consume() }
                if (n != prevN) { prevN = n; last = cen; lastDist = dist; continue }   // finger count changed: avoid a jump
                val d = cen - last

                when (n) {
                    1 -> if (maxF == 1) {
                        oneTravel += hypot(d.x, d.y)
                        if (oneTravel > slop) {
                            if (secondTap && !dragging) { dragging = true; c.send("down"); hint("Drag") }
                            val g = gain(); c.send("move", "dx" to d.x * g, "dy" to d.y * g)
                        }
                    }
                    2 -> {
                        multiTravel += hypot(d.x, d.y); distTravel += abs(dist - lastDist)
                        ax += d.x; ay += d.y
                        if (mode == 0 && maxOf(multiTravel, distTravel) > slop * 1.5f) mode = if (distTravel > multiTravel) 2 else 1
                        if (mode == 1) {
                            vt.addPosition(pressed[0].uptimeMillis, Offset(ax, ay))
                            val axis = if (abs(ax) > 2f * abs(ay)) 1 else if (abs(ay) > 2f * abs(ax)) 2 else 0   // 1 horizontal · 2 vertical · 0 free
                            if (axis != 1 && d.y != 0f) c.send("scroll", "dy" to sgn * d.y)
                            if (axis != 2 && d.x != 0f) c.send("hscroll", "dx" to sgn * d.x)
                            scrolled = true
                        } else if (mode == 2 && lastDist > 0f && dist > 0f) {
                            val f = dist / lastDist
                            if (abs(f - 1f) > 0.01f) c.send("zoom", "f" to f)
                        }
                    }
                    else -> {
                        multiTravel += hypot(d.x, d.y); ax += d.x; ay += d.y
                        if (!fired && hypot(ax, ay) > swipeDist) {
                            fired = true
                            val horiz = abs(ax) > abs(ay)
                            val (key, label) = if (n == 3) when {
                                !horiz && ay < 0 -> "recents" to "Recents"
                                !horiz -> "home" to "Home"
                                ax < 0 -> "back" to "Back"
                                else -> "drawer" to "App drawer"
                            } else when {
                                !horiz && ay > 0 -> "notif" to "Notifications"
                                !horiz -> "quick" to "Quick settings"
                                ax < 0 -> "back" to "Back"
                                else -> "recents" to "Recents"
                            }
                            c.send("key", "k" to key); hint(label)
                        }
                    }
                }
                last = cen; lastDist = dist
            }

            // ----- finger(s) lifted -----
            if (dragging) { c.send("up"); lastTapUp = 0L }
            else if (maxF == 1 && !longPressed && oneTravel <= slop) {
                c.send("click")                                     // tap; a quick second tap makes it a double click
                if (secondTap) { lastTapUp = 0L; hint("Double click") } else lastTapUp = upT
            }
            else if (maxF == 2 && mode == 0 && upT - t0 < 350 && multiTravel <= slop * 2 && distTravel <= slop * 2) {
                c.send("rclick"); hint("Right click"); lastTapUp = 0L
            }
            else if (maxF == 2 && mode == 1 && scrolled) {
                val v = vt.calculateVelocity()
                var vx = v.x; var vy = v.y
                val horizOnly = abs(vx) > 2f * abs(vy); val vertOnly = abs(vy) > 2f * abs(vx)
                if (hypot(vx, vy) > 600f) {
                    fling = scope.launch {
                        while (isActive && hypot(vx, vy) > 120f) {
                            delay(16)
                            if (!horizOnly) c.send("scroll", "dy" to sgn * vy * 0.016f)
                            if (!vertOnly) c.send("hscroll", "dx" to sgn * vx * 0.016f)
                            vx *= 0.93f; vy *= 0.93f
                        }
                    }
                }
            }
            if (maxF > 1) lastTapUp = 0L
        }
    }

/** Short-lived label shown on the touchpad (e.g. "Recents"). */
@Composable fun rememberHint(): Pair<String?, (String) -> Unit> {
    var text by remember { mutableStateOf<String?>(null) }
    var stamp by remember { mutableIntStateOf(0) }
    LaunchedEffect(stamp) { if (stamp > 0) { delay(900); text = null } }
    return text to { s: String -> text = s; stamp++ }
}

@Composable fun GestureHelp(onClose: () -> Unit) {
    AlertDialog(onDismissRequest = onClose, confirmButton = { TextButton(onClose) { Text("Got it") } },
        title = { Text("Touchpad gestures", fontWeight = FontWeight.Bold) },
        text = {
            Text("1 finger\n" +
                "• Move: move the cursor\n• Tap: click\n• Double-tap: double click\n• Tap, then touch and drag: drag / select\n• Hold: right click\n\n" +
                "2 fingers\n• Drag: scroll up/down/left/right (with momentum)\n• Pinch: zoom\n• Tap: right click\n\n" +
                "3 fingers\n• Swipe up: Recents\n• Swipe down: Home\n• Swipe left: Back\n• Swipe right: App drawer\n\n" +
                "4 fingers\n• Swipe down: Notifications\n• Swipe up: Quick settings\n• Swipe left: Back\n• Swipe right: Recents\n\n" +
                "Tip: tap \"Natural\" under the pad to flip scroll direction.", fontSize = 13.sp, lineHeight = 19.sp)
        })
}
