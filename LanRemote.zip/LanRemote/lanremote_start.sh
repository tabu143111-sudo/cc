#!/system/bin/sh
# Runs ON the phone (pushed by adb_setup). Starts the native mouse/keyboard injection server with shell privileges.
PKG=com.example.lanremote
APK=$(pm path $PKG | head -n 1 | cut -d: -f2)
CLASSPATH=$APK exec app_process /system/bin com.example.lanremote.InputServer
