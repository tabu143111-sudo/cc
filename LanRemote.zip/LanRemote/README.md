# LAN Remote
Open this folder in Android Studio -> Run (or Build > Build APK) -> install on both devices.

Host: start host, set PIN. Controller: pick host from list (or type IP) + PIN.

## Native mouse + keyboard and permanent permissions (ADB)
On the host device: enable USB debugging, connect to the PC, run `adb_setup.bat` (Windows) or `./adb_setup.sh` (Mac/Linux).
- Grants WRITE_SECURE_SETTINGS + notification access and exempts the app from battery optimisation. The app then keeps
  Accessibility and notification access switched on by itself (also after reboot).
- Starts `InputServer` with shell privileges. It injects real mouse and keyboard events (system pointer, hover, scroll wheel,
  hardware key events) – the host behaves as if a physical mouse/keyboard were attached. Re-run the script after a reboot.
- If the server is not running, the app falls back to the Accessibility-based pointer/keyboard.
Manual alternative for permissions only: `adb shell pm grant com.example.lanremote android.permission.WRITE_SECURE_SETTINGS`.
