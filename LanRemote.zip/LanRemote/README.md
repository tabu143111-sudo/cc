# LAN Remote
Open this folder in Android Studio -> Run (or Build > Build APK) -> install on both devices.

Host: start host, set PIN. Controller: pick host from list (or type IP) + PIN.

## Native mouse + keyboard and permanent permissions (ADB)
On the host device: enable USB debugging, connect to the PC, run `adb_setup.bat` (Windows) or `./adb_setup.sh` (Mac/Linux).
- Grants WRITE_SECURE_SETTINGS + notification access and exempts the app from battery optimisation. The app then keeps
  Accessibility and notification access switched on by itself (also after reboot).
- Starts `InputServer` with shell privileges. It injects real mouse and keyboard events (system pointer, hover, scroll wheel,
  hardware key events) – the host behaves as if a physical mouse/keyboard were attached. Re-run the script after a reboot.
- If the server is not running, the app falls back to the Accessibility-based pointer/keyboard.
Manual alternative for permissions only: `adb shell pm grant com.example.lanremote android.permission.WRITE_SECURE_SETTINGS`.

## In-app setup guide
Open the app -> **Setup guide** (home screen, or from the Host screen). It walks through Wireless debugging + Termux/ADB,
with copy buttons for every command, live status, and the optional native-pointer command (no PC or script file needed).

## Touchpad gestures
1 finger: move, tap = click, double-tap = double click, tap then touch-and-drag = drag/select, hold = right click.
2 fingers: drag = scroll (vertical + horizontal, with momentum), pinch = zoom, tap = right click.
3 fingers: swipe up = Recents, down = Home, left = Back, right = App drawer (short swipe, ~1 cm, is enough).
4 fingers: swipe down = Notifications, up = Quick settings, left = Back, right = Recents.
"Natural/Classic" under the pad flips the scroll direction; "?" shows this list in the app.
Drag and horizontal scroll use the native server when it runs; pinch zoom, notifications and quick settings always use Accessibility.

## Controller screen
- Always full screen (status + navigation bars hidden; swipe from the edge to peek). Landscape uses the whole screen:
  touchpad on the left, status + media card (stretches to the full height) + text input on the right.
- Media card: previous / -10 s / play-pause / +10 s / next, seek bar and a volume bar. The expand button opens a full-bleed
  cover-art view (no frame or borders).
- **Skip ad**: while an ad runs on the host (YouTube etc., found through the Accessibility service) a "Skip ad" pill appears;
  it is greyed out ("Ad playing...") until the host shows its Skip button, then tapping it presses that button.
- Smooth cursor: moves are merged on the controller, TCP_NODELAY on both ends, the overlay pointer eases towards its target
  every frame and the native input server injects movement in 8 ms steps.

## Typing, backspace, brightness, ad skipping (latest changes)
- **Live typing**: the input box now behaves like a keyboard of the host. Every character you type (and every deletion) appears
  immediately in the focused field on the host; "LIVE" next to the box switches back to the old type-then-send mode.
  ➤ = Enter (and clears the box). Backspace with an empty box still deletes on the host.
- **Backspace**: hold the ⌫ button to keep deleting (accelerates). Deleting and typing now happen **at the caret** of the host
  field (with the native server through real DEL key events, with Accessibility through the field's selection), not at the end.
- **Media full screen**: drag up/down on the **left half** = host brightness, on the **right half** = host volume (level bar shown).
  Brightness needs either the native server running or WRITE_SETTINGS (adb_setup grants it; or Host screen > Allow brightness control).
- **Skip ad** now scans every on-screen app window and recognises skip buttons of YouTube / YouTube Music, Hotstar, JioCinema,
  SonyLIV, ZEE5, Prime Video, Disney+, Hulu, Peacock, Paramount+, Max, Tubi, Pluto, Twitch, Dailymotion, Vimeo, MX Player,
  Facebook/Instagram/TikTok, Spotify, Pandora, SoundCloud, Deezer, JioSaavn, Gaana, Wynk and more, and inside Chrome, Firefox,
  Edge, Brave, Opera, Samsung Internet, Vivaldi, DuckDuckGo, Kiwi, UC, Yandex, Mi Browser (web pages such as m.youtube.com).
  Ads that the service itself makes unskippable (e.g. Spotify free audio ads) only show "Ad playing...".

## After updating the app
Re-install on both devices, then **re-run adb_setup / "Start native server"** (the native server keeps running the old code until
restarted). If Skip ad is not detected, switch the Accessibility service off and on once (its flags changed).
Some phones (Xiaomi/HyperOS, OPPO, Samsung) have their own 3-finger system gestures; turn them off in system settings if they cancel touches.
