# LAN Remote
Open this folder in Android Studio -> Run (or Build > Build APK) -> install on both devices.

Host: start host, set PIN. Controller: pick host from list (or type IP) + PIN.

## Native mouse + keyboard and permanent permissions (ADB)
On the host device: enable USB debugging, connect to the PC, run `adb_setup.bat` (Windows) or `./adb_setup.sh` (Mac/Linux).
- Grants WRITE_SECURE_SETTINGS + notification access and exempts the app from battery optimisation. The app then keeps
  Accessibility and notification access switched on by itself (also after reboot).
- Starts `InputServer` with shell privileges. It injects real mouse and keyboard events (system pointer, hover, scroll wheel,
  hardware key events) – the host behaves as if a physical mouse/keyboard were attached. Re-run the script after a reboot.
- If the server is not running, the app falls back to the Accessibility-based pointer/keyboard.
Manual alternative for permissions only: `adb shell pm grant com.example.lanremote android.permission.WRITE_SECURE_SETTINGS`.

## In-app setup guide
Open the app -> **Setup guide** (home screen, or from the Host screen). It walks through Wireless debugging + Termux/ADB,
with copy buttons for every command, live status, and the optional native-pointer command (no PC or script file needed).

## Touchpad gestures
1 finger: move, tap = click, double-tap = double click, tap then touch-and-drag = drag/select, hold = right click.
2 fingers: drag = scroll (vertical + horizontal, with momentum), pinch = zoom, tap = right click.
3 fingers: swipe up = Recents, down = Home, left = Back, right = App drawer.
4 fingers: swipe down = Notifications, up = Quick settings, left = Back, right = Recents.
"Natural/Classic" under the pad flips the scroll direction; "?" shows this list in the app.
Drag and horizontal scroll use the native server when it runs; pinch zoom, notifications and quick settings always use Accessibility.
