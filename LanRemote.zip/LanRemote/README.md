# LAN Remote
Open this folder in Android Studio -> Run (or Build > Build APK) -> install on both devices.
Host: start host, set PIN, enable Accessibility (for mouse/keyboard).
Controller: pick host from list (or type IP) + PIN.
