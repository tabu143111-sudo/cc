@echo off
rem Setup for the HOST device (the one that gets controlled).
rem 1. Install the app on the host  2. Enable USB debugging  3. Plug in USB  4. Double-click this file.
rem Re-run it after every reboot of the host (it restarts the native input server).
rem Needs adb (Android platform-tools) in PATH or in this folder.
set PKG=com.example.lanremote
adb start-server >nul 2>&1
adb get-state >nul 2>&1 || (echo No device found. Enable USB debugging and accept the prompt on the phone. & pause & exit /b 1)

echo Granting permissions...
adb shell pm grant %PKG% android.permission.WRITE_SECURE_SETTINGS || (echo Grant failed. On Xiaomi/Poco also enable "USB debugging - Security settings". & pause & exit /b 1)
adb shell pm grant %PKG% android.permission.POST_NOTIFICATIONS >nul 2>&1

echo Enabling media (notification) access...
adb shell cmd notification allow_listener %PKG%/%PKG%.MediaListener

echo Excluding the app from battery optimisation...
adb shell dumpsys deviceidle whitelist +%PKG% >nul 2>&1
adb shell cmd appops set %PKG% RUN_IN_BACKGROUND allow >nul 2>&1

echo Starting native mouse + keyboard server...
adb shell "pkill -f com.example.lanremote.InputServer" >nul 2>&1
adb shell "mkdir -p /sdcard/Android/data/%PKG%/files" >nul 2>&1
adb push "%~dp0lanremote_start.sh" /data/local/tmp/lanremote_start.sh >nul
adb shell "nohup sh /data/local/tmp/lanremote_start.sh > /data/local/tmp/lanremote.log 2>&1 &"
timeout /t 2 >nul
adb shell cat /data/local/tmp/lanremote.log

echo Opening the app (it enables Accessibility by itself)...
adb shell am start -n %PKG%/.MainActivity >nul
echo.
echo Done. Open the app ^> Host ^> Start host. The Host screen should show "Native mouse ^& keyboard: active".
pause
