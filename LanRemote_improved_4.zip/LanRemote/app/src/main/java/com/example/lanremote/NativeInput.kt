package com.example.lanremote

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.io.PrintWriter
import java.net.InetSocketAddress
import java.net.Socket

/** Bridge from the host app to the ADB-started [InputServer]. If it is not running, input falls back to Accessibility. */
object NativeInput {
    @Volatile var connected = false
    /** Protocol version of the running native server (1 = old build without brightness, 2 = current). */
    @Volatile var ver = 0
    private var sock: Socket? = null
    private var out: PrintWriter? = null

    @Synchronized fun connect(ctx: Context) {
        if (connected) return
        try {
            val f = File(ctx.getExternalFilesDir(null), "native_token")
            if (!f.exists()) return
            val s = Socket(); s.tcpNoDelay = true; s.connect(InetSocketAddress("127.0.0.1", 8766), 600); s.soTimeout = 2000
            val o = PrintWriter(s.getOutputStream(), true)
            o.println(f.readText().trim())
            val rd = s.getInputStream().bufferedReader()
            val hello = rd.readLine()
            if (hello != null && hello.startsWith("ok")) {
                ver = hello.removePrefix("ok").toIntOrNull() ?: 1; s.soTimeout = 0; sock = s; out = o; connected = true
                // v4+ server: it reports the real pointer position; the overlay cursor follows it exactly
                Thread {
                    try { while (true) { val l = rd.readLine() ?: break
                        if (l.startsWith("p ")) l.split(' ').let { p -> if (p.size == 5) RemoteAccess.syncPos(p[1].toFloat(), p[2].toFloat(), p[3].toInt(), p[4].toInt()) } } }
                    catch (_: Exception) {}
                    synchronized(this) { if (sock === s) drop() }
                }.apply { isDaemon = true; start() }
            } else s.close()
        } catch (_: Exception) {}
    }

    /** Oldest server version this app needs (v5: reports the real pointer position, Ctrl combos). */
    const val NEED_VER = 5
    val upToDate get() = connected && ver >= NEED_VER
    @Synchronized fun disconnect() = drop()

    @Synchronized private fun drop() { connected = false; try { sock?.close() } catch (_: Exception) {}; sock = null; out = null }

    /** @return true when the native server handled the command. */
    @Synchronized fun forward(j: JSONObject): Boolean {
        if (!connected) return false
        val ok = when (j.optString("t")) {
            "move", "click", "rclick", "scroll", "hscroll", "down", "up", "bright", "launch", "url" -> true
            "key" -> j.optString("k") in listOf("back", "home", "recents", "backspace", "enter", "del", "tab", "esc", "left", "right", "up", "down", "home_line", "end_line") ||
                     (j.optString("k") == "ctrl" && ver >= 5 && j.optString("ch").length == 1 && j.optString("ch")[0].isLetterOrDigit())
            "text" -> j.optString("s").all { it.code in 32..126 || it == '\n' }   // other characters: Accessibility fallback
            else -> false
        }
        if (!ok) return false
        val o = out ?: return false
        o.println(j.toString())
        if (o.checkError()) { drop(); return false }
        return true
    }
}
