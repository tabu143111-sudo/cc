package com.example.lanremote

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.net.NetworkInterface
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Starts the native [InputServer] with ONE tap and no PC.
 *
 * Requirements (the in-app guide walks through each one, in order):
 *  1. Termux with android-tools, `allow-external-apps = true` in ~/.termux/termux.properties
 *  2. this app has the "Run commands in Termux environment" permission
 *  3. Wireless debugging is on and Termux was paired once (`adb pair`)
 *
 * The app finds the wireless-debugging port through mDNS and asks Termux to run assets/lanremote_setup.sh, which connects,
 * grants WRITE_SECURE_SETTINGS (this is what lets the app switch Accessibility on by itself), starts the server and
 * opens the app. Termux sends the script's output back, so the guide can show exactly what happened.
 */
object NativeStarter {
    private const val PKG = "com.example.lanremote"
    const val TERMUX_PERM = "com.termux.permission.RUN_COMMAND"

    var status by mutableStateOf("")
    /** Output of the last Termux run (setup script or link test). */
    var log by mutableStateOf("")
    var testResult by mutableStateOf("")
    @Volatile var busy = false
        private set

    fun termuxInstalled(ctx: Context) = try { ctx.packageManager.getPackageInfo("com.termux", 0); true } catch (_: Exception) { false }
    fun termuxAllowed(ctx: Context) = ctx.checkSelfPermission(TERMUX_PERM) == PackageManager.PERMISSION_GRANTED
    /** Wireless debugging switch (readable without special permission). -1 = unknown on this ROM. */
    fun wirelessDebugging(ctx: Context): Int = try { Settings.Global.getInt(ctx.contentResolver, "adb_wifi_enabled", -1) } catch (_: Exception) { -1 }

    fun start(ctx0: Context) {
        val ctx = ctx0.applicationContext
        synchronized(this) { if (busy) return; busy = true }
        Thread {
            try { run(ctx) } catch (e: Exception) { status = "Failed: ${e.message}" } finally { busy = false }
        }.start()
    }

    private fun run(ctx: Context) {
        log = ""
        NativeInput.connect(ctx)
        if (NativeInput.upToDate) { status = "✔ Native server is already running"; return }
        if (NativeInput.connected) { status = "Updating the native server to the new version…"; NativeInput.disconnect() }   // an old server is replaced by the script
        if (!termuxInstalled(ctx)) { status = "✖ Termux is not installed on this device (guide step 1)"; return }
        if (!termuxAllowed(ctx)) { status = "✖ Allow \"Run commands in Termux\" for this app (guide step 2)"; return }
        when (wirelessDebugging(ctx)) {
            0 -> {
                if (AutoGrant.canWrite(ctx)) {
                    try { Settings.Global.putInt(ctx.contentResolver, "adb_wifi_enabled", 1) } catch (_: Exception) {}
                } else { status = "✖ Turn on Wireless debugging in Developer options (guide step 3)"; return }
            }
        }
        status = "Looking for the Wireless debugging port…"
        var port = discover(ctx, "_adb-tls-connect._tcp", 12)
        if (port <= 0) port = manualPort(ctx)
        if (port <= 0) { status = "✖ Port not found. Is Wi-Fi connected and Wireless debugging on? You can type the port in guide step 5."; return }
        status = "Asking Termux to run the setup script (port $port)…"
        if (!runTermux(ctx, "setup", ctx.assets.open("lanremote_setup.sh").bufferedReader().readText(), arrayOf("lanremote", port.toString()))) return
        status = "Script running… (connecting, granting access, starting server)"
        repeat(40) {
            Thread.sleep(1000)
            NativeInput.connect(ctx)
            if (NativeInput.upToDate) {
                ctx.getSharedPreferences("s", 0).edit().putBoolean("auto_native", true).apply()   // from now on it starts by itself
                AutoGrant.ensure(ctx, true)                                                         // Accessibility + notification access
                status = "✔ Done: app activated, native mouse & keyboard running"; return
            }
        }
        val lastLine = log.lineSequence().map { it.trim() }.lastOrNull { it.isNotEmpty() }
        status = "✖ Server did not start" + (lastLine?.let { ": $it" } ?: ". Check that Termux is paired (guide step 4) and allow-external-apps is set (step 2).")
    }

    /** Quick check of the app → Termux link (guide step 2). */
    fun testTermux(ctx0: Context) {
        val ctx = ctx0.applicationContext
        testResult = "Testing…"
        if (!termuxInstalled(ctx)) { testResult = "✖ Termux is not installed"; return }
        if (!termuxAllowed(ctx)) { testResult = "✖ Permission \"Run commands in Termux\" is not granted yet"; return }
        runTermux(ctx, "test", "echo LANREMOTE_OK; if command -v adb >/dev/null 2>&1; then adb version | head -n 1; else echo 'adb: NOT INSTALLED (run: pkg install android-tools)'; fi", arrayOf("lanremote"))
    }

    /** Called by [TermuxResult] when Termux reports back. */
    fun onResult(tag: String, code: Int, out: String, err: String, errmsg: String?) {
        val text = (out + (if (err.isNotBlank()) "\n$err" else "") + (if (!errmsg.isNullOrBlank()) "\n$errmsg" else "")).trim()
        if (tag == "test") {
            testResult = when {
                out.contains("LANREMOTE_OK") && !out.contains("NOT INSTALLED") -> "✔ Termux answered. " + out.lineSequence().firstOrNull { it.startsWith("Android Debug Bridge") }.orEmpty()
                out.contains("NOT INSTALLED") -> "✔ Termux answered, but adb is missing: run  pkg install android-tools"
                else -> "✖ " + text.ifEmpty { "No answer (exit $code)" }
            }
        } else log = text
    }

    private fun manualPort(ctx: Context) = ctx.getSharedPreferences("s", 0).getString("adb_port", "")?.trim()?.toIntOrNull() ?: 0

    private fun localAddrs(): Set<String> = try {
        NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }.mapNotNull { it.hostAddress?.substringBefore('%') }.toSet()
    } catch (_: Exception) { emptySet() }

    /** mDNS lookup of a service that THIS device advertises (_adb-tls-connect._tcp or _adb-tls-pairing._tcp). Returns its port or 0. */
    fun discover(ctx: Context, type: String, seconds: Long): Int {
        val nsd = ctx.getSystemService(NsdManager::class.java)
        val local = localAddrs()
        val latch = CountDownLatch(1)
        val port = java.util.concurrent.atomic.AtomicInteger(0)
        fun resolve(s: NsdServiceInfo, tries: Int) {
            @Suppress("DEPRECATION")
            nsd.resolveService(s, object : NsdManager.ResolveListener {
                override fun onResolveFailed(s2: NsdServiceInfo, e: Int) {
                    // only one resolve may run at a time on many Android versions: try again shortly
                    if (tries > 0) Thread { try { Thread.sleep(300) } catch (_: Exception) {}; resolve(s, tries - 1) }.start()
                }
                override fun onServiceResolved(r: NsdServiceInfo) {
                    val h = r.host
                    if (h != null && (h.isLoopbackAddress || local.contains(h.hostAddress?.substringBefore('%')))) { port.set(r.port); latch.countDown() }
                }
            })
        }
        val dl = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(t: String) {}
            override fun onStartDiscoveryFailed(t: String, e: Int) { latch.countDown() }
            override fun onStopDiscoveryFailed(t: String, e: Int) {}
            override fun onDiscoveryStopped(t: String) {}
            override fun onServiceLost(s: NsdServiceInfo) {}
            override fun onServiceFound(s: NsdServiceInfo) { resolve(s, 6) }
        }
        try { nsd.discoverServices(type, NsdManager.PROTOCOL_DNS_SD, dl) } catch (_: Exception) { return 0 }
        latch.await(seconds, TimeUnit.SECONDS)
        try { nsd.stopServiceDiscovery(dl) } catch (_: Exception) {}
        return port.get()
    }

    /** Runs [script] with bash inside Termux; the output comes back through [TermuxResult]. */
    private fun runTermux(ctx: Context, tag: String, script: String, args: Array<String>): Boolean {
        return try {
            val back = PendingIntent.getBroadcast(ctx, if (tag == "test") 11 else 10,
                Intent(ctx, TermuxResult::class.java).putExtra("tag", tag),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
            val i = Intent("com.termux.RUN_COMMAND")
                .setClassName("com.termux", "com.termux.app.RunCommandService")
                .putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash")
                .putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-c", script) + args)
                .putExtra("com.termux.RUN_COMMAND_WORKDIR", "/data/data/com.termux/files/home")
                .putExtra("com.termux.RUN_COMMAND_BACKGROUND", true)
                .putExtra("com.termux.RUN_COMMAND_PENDING_INTENT", back)
            ctx.startForegroundService(i)
            true
        } catch (e: Exception) {
            val m = if (e is SecurityException) "✖ Termux refused: set  allow-external-apps = true  and restart Termux (guide step 2)" else "✖ Could not reach Termux: ${e.message}"
            if (tag == "test") testResult = m else status = m
            false
        }
    }
}
